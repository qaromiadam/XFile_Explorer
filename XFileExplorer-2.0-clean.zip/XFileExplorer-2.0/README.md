# XFile Explorer

Android file manager and terminal (Kotlin + Jetpack Compose).

## Build a debug APK
- Android Studio: open this folder, let Gradle sync, then Build > Build APK(s).
- Command line (JDK 17+, Android SDK installed, ANDROID_HOME set):
  - Linux/Mac: `./gradlew assembleDebug`
  - Windows: `gradlew.bat assembleDebug`

Output: `app/build/outputs/apk/debug/app-debug.apk`

## Release build
Set `KEYSTORE_PATH`, `STORE_PASSWORD`, `KEY_PASSWORD` (key alias `upload`), then `./gradlew assembleRelease`.
