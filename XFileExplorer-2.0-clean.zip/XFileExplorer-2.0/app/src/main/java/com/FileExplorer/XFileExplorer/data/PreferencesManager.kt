package com.FileExplorer.XFileExplorer.data

import android.content.Context
import android.content.SharedPreferences
import com.FileExplorer.XFileExplorer.model.AppSettings
import com.FileExplorer.XFileExplorer.model.BackgroundEngineMode
import com.FileExplorer.XFileExplorer.model.SortBy
import com.FileExplorer.XFileExplorer.model.ThemeMode

/**
 * Persistent preferences storage engine using Android SharedPreferences.
 * Stores and restores theme mode, accent, wallpaper URI, opacity, sorting, and UI toggles.
 */
class PreferencesManager(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("xfile_explorer_prefs", Context.MODE_PRIVATE)

    fun loadSettings(): AppSettings {
        val themeModeStr = prefs.getString("theme_mode", ThemeMode.DARK.name) ?: ThemeMode.DARK.name
        val themeMode = try {
            val parsed = ThemeMode.valueOf(themeModeStr)
            if (parsed == ThemeMode.LIGHT) ThemeMode.DARK else parsed
        } catch (_: Exception) {
            ThemeMode.DARK
        }

        val accentIndex = prefs.getInt("accent_index", 0)

        val bgModeStr = prefs.getString("bg_mode", BackgroundEngineMode.DEFAULT_GRADIENT.name)
            ?: BackgroundEngineMode.DEFAULT_GRADIENT.name
        val bgMode = try {
            BackgroundEngineMode.valueOf(bgModeStr)
        } catch (_: Exception) {
            BackgroundEngineMode.DEFAULT_GRADIENT
        }

        val wallpaperUri = prefs.getString("custom_wallpaper_uri", null)
        val bgOpacity = prefs.getFloat("bg_opacity", 0.85f)
        val bgBlur = prefs.getFloat("bg_blur", 0f)
        val cardOpacity = prefs.getFloat("card_opacity", 0.82f)

        val showThumbnails = prefs.getBoolean("show_thumbnails", true)
        val useApkMascot = prefs.getBoolean("use_apk_mascot", true)
        val useArchiveIcons = prefs.getBoolean("use_archive_icons", true)
        val showHidden = prefs.getBoolean("show_hidden", true)

        val sortByStr = prefs.getString("sort_by", SortBy.DATE.name) ?: SortBy.DATE.name
        val sortBy = try {
            SortBy.valueOf(sortByStr)
        } catch (_: Exception) {
            SortBy.DATE
        }

        val sortAscending = prefs.getBoolean("sort_ascending", false)
        val compressionLevel = prefs.getInt("compression_level", 60)

        val storageModeStr = prefs.getString("storage_label_mode", com.FileExplorer.XFileExplorer.model.StorageLabelMode.PHONE_MODEL.name)
            ?: com.FileExplorer.XFileExplorer.model.StorageLabelMode.PHONE_MODEL.name
        val storageLabelMode = try {
            com.FileExplorer.XFileExplorer.model.StorageLabelMode.valueOf(storageModeStr)
        } catch (_: Exception) {
            com.FileExplorer.XFileExplorer.model.StorageLabelMode.PHONE_MODEL
        }
        val customStorageLabel = prefs.getString("custom_storage_label", "") ?: ""

        return AppSettings(
            themeMode = themeMode,
            accentIndex = accentIndex,
            backgroundEngineMode = bgMode,
            customWallpaperUri = wallpaperUri,
            backgroundOpacity = bgOpacity,
            backgroundBlur = bgBlur,
            cardOpacity = cardOpacity,
            showImageThumbnails = showThumbnails,
            useStylizedApkMascot = useApkMascot,
            useCustomArchiveIcons = useArchiveIcons,
            showHiddenFiles = showHidden,
            sortBy = sortBy,
            sortAscending = sortAscending,
            compressionLevel = compressionLevel,
            storageLabelMode = storageLabelMode,
            customStorageLabel = customStorageLabel
        )
    }

    fun saveSettings(settings: AppSettings) {
        prefs.edit()
            .putString("theme_mode", settings.themeMode.name)
            .putInt("accent_index", settings.accentIndex)
            .putString("bg_mode", settings.backgroundEngineMode.name)
            .putString("custom_wallpaper_uri", settings.customWallpaperUri)
            .putFloat("bg_opacity", settings.backgroundOpacity)
            .putFloat("bg_blur", settings.backgroundBlur)
            .putFloat("card_opacity", settings.cardOpacity)
            .putBoolean("show_thumbnails", settings.showImageThumbnails)
            .putBoolean("use_apk_mascot", settings.useStylizedApkMascot)
            .putBoolean("use_archive_icons", settings.useCustomArchiveIcons)
            .putBoolean("show_hidden", settings.showHiddenFiles)
            .putString("sort_by", settings.sortBy.name)
            .putBoolean("sort_ascending", settings.sortAscending)
            .putInt("compression_level", settings.compressionLevel)
            .putString("storage_label_mode", settings.storageLabelMode.name)
            .putString("custom_storage_label", settings.customStorageLabel)
            .apply()
    }
}
