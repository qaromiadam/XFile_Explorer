package com.FileExplorer.XFileExplorer.ui.screens

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Launch
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.FileExplorer.XFileExplorer.model.AppSettings
import com.FileExplorer.XFileExplorer.ui.components.CornerHamburgerButton
import com.FileExplorer.XFileExplorer.ui.theme.DarkSurface
import com.FileExplorer.XFileExplorer.ui.theme.DarkSurfaceBorder
import com.FileExplorer.XFileExplorer.ui.theme.DarkSurfaceElevated
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Representation of an installed app with pre-rendered ImageBitmap for optimal scroll performance.
 */
data class UiAppInfo(
    val packageName: String,
    val appName: String,
    val iconBitmap: ImageBitmap?,
    val isSystemApp: Boolean,
    val versionName: String,
    val hasLaunchIntent: Boolean
)

@Composable
fun AppsScreen(
    settings: AppSettings,
    onOpenHamburger: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var installedApps by remember { mutableStateOf<List<UiAppInfo>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var searchQuery by remember { mutableStateOf("") }
    var showSystemApps by remember { mutableStateOf(false) }

    fun scanInstalledApps() {
        coroutineScope.launch {
            isLoading = true
            val apps = withContext(Dispatchers.IO) {
                loadInstalledApplications(context)
            }
            installedApps = apps
            isLoading = false
        }
    }

    LaunchedEffect(Unit) {
        scanInstalledApps()
    }

    // Hidden services (!hasLaunchIntent) only appear when showSystemApps is true
    val filteredApps = remember(installedApps, searchQuery, showSystemApps) {
        installedApps.filter { app ->
            val matchesVisibility = if (showSystemApps) {
                true // Show all packages including hidden services
            } else {
                // When OFF: Only show launchable applications; hide background services / unlaunchable packages
                app.hasLaunchIntent
            }
            val matchesQuery = if (searchQuery.isBlank()) {
                true
            } else {
                val q = searchQuery.trim().lowercase()
                app.appName.lowercase().contains(q) || app.packageName.lowercase().contains(q)
            }
            matchesVisibility && matchesQuery
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
    ) {
        // Top Header Bar matching XFile Explorer style
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = DarkSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                CornerHamburgerButton(
                    onClick = onOpenHamburger,
                    accent = settings.currentAccent
                )

                Spacer(modifier = Modifier.width(10.dp))

                Icon(
                    imageVector = Icons.Default.Apps,
                    contentDescription = null,
                    tint = settings.currentAccent,
                    modifier = Modifier.size(22.dp)
                )

                Spacer(modifier = Modifier.width(8.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Installed Applications",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = if (isLoading) "Scanning packages..." else "${filteredApps.size} apps available",
                        fontSize = 12.sp,
                        color = Color(0xFF90A4CE)
                    )
                }

                IconButton(
                    onClick = { scanInstalledApps() },
                    modifier = Modifier
                        .size(40.dp)
                        .testTag("apps_refresh_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Refresh Applications List",
                        tint = settings.currentAccent
                    )
                }
            }
        }

        // Search Bar & Filter Controls
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = DarkSurface.copy(alpha = 0.95f),
            border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder.copy(alpha = 0.5f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = {
                        Text(
                            text = "Search apps by name or package...",
                            color = Color(0xFF5F759E),
                            fontSize = 13.sp
                        )
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = null,
                            tint = settings.currentAccent,
                            modifier = Modifier.size(20.dp)
                        )
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(
                                    imageVector = Icons.Default.Clear,
                                    contentDescription = "Clear search",
                                    tint = Color(0xFF90A4CE),
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedContainerColor = DarkSurfaceElevated,
                        unfocusedContainerColor = DarkSurfaceElevated,
                        focusedBorderColor = settings.currentAccent,
                        unfocusedBorderColor = DarkSurfaceBorder
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("apps_search_input")
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    val normalCount = remember(installedApps) { installedApps.count { it.hasLaunchIntent || !it.isSystemApp } }
                    val hiddenCount = remember(installedApps) { installedApps.count { it.isSystemApp && !it.hasLaunchIntent } }

                    FilterChip(
                        selected = showSystemApps,
                        onClick = { showSystemApps = !showSystemApps },
                        label = {
                            Text(
                                text = if (showSystemApps) "Show Hidden Packages: ON" else "Show Hidden Packages: OFF",
                                fontSize = 12.sp,
                                fontWeight = if (showSystemApps) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.FilterList,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            containerColor = DarkSurfaceElevated,
                            selectedContainerColor = settings.currentAccent.copy(alpha = 0.25f),
                            selectedLabelColor = settings.currentAccent,
                            selectedLeadingIconColor = settings.currentAccent,
                            labelColor = Color(0xFF90A4CE),
                            iconColor = Color(0xFF90A4CE)
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = showSystemApps,
                            borderColor = DarkSurfaceBorder,
                            selectedBorderColor = settings.currentAccent
                        ),
                        modifier = Modifier.testTag("toggle_system_apps")
                    )

                    Text(
                        text = "Normal: $normalCount | Hidden: $hiddenCount",
                        fontSize = 11.sp,
                        color = Color(0xFF5F759E)
                    )
                }
            }
        }

        // App List or Loading State
        Box(
            modifier = Modifier
                .fillMaxSize()
                .navigationBarsPadding()
        ) {
            when {
                isLoading -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        CircularProgressIndicator(
                            color = settings.currentAccent,
                            modifier = Modifier.size(42.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Loading installed packages...",
                            color = Color(0xFF90A4CE),
                            fontSize = 14.sp
                        )
                    }
                }

                filteredApps.isEmpty() -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(32.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.Apps,
                            contentDescription = null,
                            tint = Color(0xFF5F759E),
                            modifier = Modifier.size(56.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "No applications found",
                            color = Color.White,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = if (searchQuery.isNotEmpty()) {
                                "No app matches \"$searchQuery\"."
                            } else {
                                "No user-installed apps found. Toggle 'System Apps' to view device system apps."
                            },
                            color = Color(0xFF90A4CE),
                            fontSize = 13.sp,
                            modifier = Modifier.padding(horizontal = 16.dp),
                            lineHeight = 18.sp
                        )
                    }
                }

                else -> {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .testTag("installed_apps_list")
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(
                            items = filteredApps,
                            key = { it.packageName }
                        ) { app ->
                            AppItemCard(
                                app = app,
                                accent = settings.currentAccent,
                                onOpenSettings = {
                                    openAppDetailsSettings(context, app.packageName)
                                },
                                onLaunchApp = {
                                    launchApplication(context, app.packageName)
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AppItemCard(
    app: UiAppInfo,
    accent: Color,
    onOpenSettings: () -> Unit,
    onLaunchApp: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable(enabled = app.hasLaunchIntent) { onLaunchApp() }
            .testTag("app_item_${app.packageName}"),
        color = DarkSurfaceElevated,
        border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // App Icon: Crisp square with rounded edges
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFF1B2333))
                    .border(1.dp, Color(0xFF2A364F), RoundedCornerShape(10.dp)),
                contentAlignment = Alignment.Center
            ) {
                if (app.iconBitmap != null) {
                    Image(
                        bitmap = app.iconBitmap,
                        contentDescription = "Icon of ${app.appName}",
                        modifier = Modifier
                            .size(44.dp)
                            .clip(RoundedCornerShape(10.dp))
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.Apps,
                        contentDescription = null,
                        tint = accent,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            // App Label, Package Name, and System/User Tag
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(end = 8.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = app.appName,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )

                    if (!app.hasLaunchIntent) {
                        Box(
                            modifier = Modifier
                                .background(Color(0xFF3E2C1A), RoundedCornerShape(4.dp))
                                .padding(horizontal = 5.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "HIDDEN SERVICE",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFFFB74D)
                            )
                        }
                    } else if (app.isSystemApp) {
                        Box(
                            modifier = Modifier
                                .background(Color(0xFF2C394F), RoundedCornerShape(4.dp))
                                .padding(horizontal = 5.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "SYSTEM",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF8FA7DF)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(2.dp))

                Text(
                    text = app.packageName,
                    fontSize = 11.sp,
                    color = Color(0xFF90A4CE),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                if (app.versionName.isNotEmpty()) {
                    Text(
                        text = "v${app.versionName}",
                        fontSize = 10.sp,
                        color = Color(0xFF5F759E),
                        maxLines = 1
                    )
                }
            }

            // Compact, non-overlapping circular action buttons with distinct spacing
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.wrapContentWidth()
            ) {
                if (app.hasLaunchIntent) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF1E2638))
                            .border(1.dp, Color(0xFF364763), CircleShape)
                            .clickable(onClick = onLaunchApp)
                            .testTag("app_launch_btn_${app.packageName}"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Launch,
                            contentDescription = "Open ${app.appName}",
                            tint = Color(0xFFB0C4DE),
                            modifier = Modifier.size(17.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(10.dp))
                }

                // Dedicated Circular button with "i" icon to launch App Info in phone settings
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(accent.copy(alpha = 0.15f))
                        .border(1.dp, accent.copy(alpha = 0.7f), CircleShape)
                        .clickable(onClick = onOpenSettings)
                        .testTag("app_info_btn_${app.packageName}"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = "App Settings for ${app.appName}",
                        tint = accent,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

/**
 * Loads and extracts installed application info safely in IO dispatcher.
 */
private fun loadInstalledApplications(context: Context): List<UiAppInfo> {
    val pm = context.packageManager
    val packages: List<PackageInfo> = try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.getInstalledPackages(PackageManager.PackageInfoFlags.of(0))
        } else {
            @Suppress("DEPRECATION")
            pm.getInstalledPackages(0)
        }
    } catch (_: Exception) {
        emptyList()
    }

    val result = ArrayList<UiAppInfo>(packages.size)
    for (pkg in packages) {
        val appInfo = pkg.applicationInfo ?: continue
        val packageName = pkg.packageName ?: continue
        val isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0 ||
                (appInfo.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0

        val appName = try {
            pm.getApplicationLabel(appInfo).toString()
        } catch (_: Exception) {
            packageName
        }

        val iconBitmap: ImageBitmap? = try {
            val drawable = pm.getApplicationIcon(appInfo)
            drawableToImageBitmap(drawable)
        } catch (_: Exception) {
            null
        }

        val hasLaunch = try {
            pm.getLaunchIntentForPackage(packageName) != null
        } catch (_: Exception) {
            false
        }

        val versionName = pkg.versionName ?: ""

        result.add(
            UiAppInfo(
                packageName = packageName,
                appName = appName,
                iconBitmap = iconBitmap,
                isSystemApp = isSystem,
                versionName = versionName,
                hasLaunchIntent = hasLaunch
            )
        )
    }

    // Sort alphabetically by app name
    result.sortBy { it.appName.lowercase() }
    return result
}

/**
 * Converts any Android Drawable (Bitmap, Vector, Adaptive) safely into an ImageBitmap.
 */
private fun drawableToImageBitmap(drawable: Drawable): ImageBitmap? {
    return try {
        if (drawable is BitmapDrawable && drawable.bitmap != null) {
            return drawable.bitmap.asImageBitmap()
        }
        val width = if (drawable.intrinsicWidth > 0) drawable.intrinsicWidth.coerceAtMost(128) else 72
        val height = if (drawable.intrinsicHeight > 0) drawable.intrinsicHeight.coerceAtMost(128) else 72
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        drawable.setBounds(0, 0, canvas.width, canvas.height)
        drawable.draw(canvas)
        bitmap.asImageBitmap()
    } catch (_: Exception) {
        null
    }
}

/**
 * Launches the phone's native App Info details settings page for the target package.
 */
private fun openAppDetailsSettings(context: Context, packageName: String) {
    try {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.fromParts("package", packageName, null)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
    } catch (e: Exception) {
        Toast.makeText(context, "Unable to open app settings: ${e.message}", Toast.LENGTH_SHORT).show()
    }
}

/**
 * Launches the app if a launch intent exists.
 */
private fun launchApplication(context: Context, packageName: String) {
    try {
        val launchIntent = context.packageManager.getLaunchIntentForPackage(packageName)
        if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launchIntent)
        } else {
            // If no launch intent, fallback to opening App Details Settings
            openAppDetailsSettings(context, packageName)
        }
    } catch (e: Exception) {
        Toast.makeText(context, "Unable to open app: ${e.message}", Toast.LENGTH_SHORT).show()
    }
}
