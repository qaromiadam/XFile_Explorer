package com.FileExplorer.XFileExplorer.model

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color

enum class PdfViewMode {
    READING,
    EDITOR
}

enum class PdfScrollLayout {
    HORIZONTAL_PAGER,
    VERTICAL_CONTINUOUS
}

enum class PdfEditTool {
    NONE,
    DRAW_INK,
    HIGHLIGHT,
    UNDERLINE,
    STRIKETHROUGH,
    SHAPE_RECTANGLE,
    SHAPE_CIRCLE,
    SHAPE_LINE,
    ADD_TEXT,
    STICKY_NOTE,
    SIGNATURE,
    WATERMARK,
    INSERT_IMAGE,
    PAGE_MANAGEMENT
}

data class PdfInkStroke(
    val points: List<Offset>,
    val color: Color,
    val strokeWidth: Float,
    val alpha: Float = 1f
)

data class PdfShapeAnnotation(
    val tool: PdfEditTool, // SHAPE_RECTANGLE, SHAPE_CIRCLE, SHAPE_LINE
    val startOffset: Offset,
    val endOffset: Offset,
    val color: Color,
    val strokeWidth: Float,
    val isFilled: Boolean = false
)

data class PdfTextAnnotation(
    val id: String = java.util.UUID.randomUUID().toString(),
    val text: String,
    val position: Offset,
    val fontSize: Float = 16f,
    val color: Color = Color.Black,
    val isBold: Boolean = false,
    val isItalic: Boolean = false
)

data class PdfStickyNote(
    val id: String = java.util.UUID.randomUUID().toString(),
    val text: String,
    val position: Offset,
    val color: Color = Color(0xFFFFD54F) // Classic yellow note
)

data class PdfWatermarkConfig(
    val text: String = "CONFIDENTIAL",
    val color: Color = Color.Red,
    val alpha: Float = 0.25f,
    val rotationAngle: Float = 45f,
    val fontSize: Float = 48f
)

data class PdfSignatureAnnotation(
    val id: String = java.util.UUID.randomUUID().toString(),
    val strokes: List<List<Offset>>,
    val position: Offset,
    val width: Float,
    val height: Float,
    val color: Color = Color(0xFF0D47A1)
)

data class PdfImageAnnotation(
    val id: String = java.util.UUID.randomUUID().toString(),
    val imageUri: String,
    val position: Offset,
    val width: Float = 160f,
    val height: Float = 160f
)

data class PageAnnotationData(
    val pageIndex: Int,
    val rotationDegrees: Int = 0,
    var canvasWidth: Float = 0f,
    var canvasHeight: Float = 0f,
    val inkStrokes: MutableList<PdfInkStroke> = mutableListOf(),
    val shapes: MutableList<PdfShapeAnnotation> = mutableListOf(),
    val textAnnotations: MutableList<PdfTextAnnotation> = mutableListOf(),
    val stickyNotes: MutableList<PdfStickyNote> = mutableListOf(),
    val signatures: MutableList<PdfSignatureAnnotation> = mutableListOf(),
    val insertedImages: MutableList<PdfImageAnnotation> = mutableListOf()
)
