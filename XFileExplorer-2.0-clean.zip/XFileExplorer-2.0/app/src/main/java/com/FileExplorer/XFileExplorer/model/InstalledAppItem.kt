package com.FileExplorer.XFileExplorer.model

import android.graphics.drawable.Drawable

data class InstalledAppItem(
    val packageName: String,
    val appName: String,
    val icon: Drawable?,
    val isSystemApp: Boolean,
    val versionName: String? = null,
    val firstInstallTime: Long = 0L,
    val lastUpdateTime: Long = 0L,
    val hasLaunchIntent: Boolean = false
)
