package com.FileExplorer.XFileExplorer.ui.viewers

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Unarchive
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.FileExplorer.XFileExplorer.data.FileManager
import com.FileExplorer.XFileExplorer.model.ArchiveEntryItem
import com.FileExplorer.XFileExplorer.model.FileItem
import com.FileExplorer.XFileExplorer.ui.theme.DarkBackground
import com.FileExplorer.XFileExplorer.ui.theme.DarkSurface
import com.FileExplorer.XFileExplorer.ui.theme.DarkSurfaceBorder
import com.FileExplorer.XFileExplorer.ui.theme.DarkSurfaceElevated
import com.FileExplorer.XFileExplorer.ui.theme.TechAmber
import com.FileExplorer.XFileExplorer.ui.theme.TechCyan
import com.FileExplorer.XFileExplorer.ui.theme.TechRed

/**
 * Requirement 1: Archive Browser
 * Allows browsing the file hierarchy inside .zip archives.
 * Enforces strict restriction: files inside archives cannot be opened, viewed, or executed directly.
 */
@Composable
fun ArchiveViewerDialog(
    item: FileItem,
    fileManager: FileManager,
    accent: Color,
    onDismiss: () -> Unit,
    onExtractArchive: (FileItem) -> Unit
) {
    var isLoading by remember { mutableStateOf(true) }
    var allEntries by remember { mutableStateOf<List<ArchiveEntryItem>>(emptyList()) }
    var currentSubPath by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var blockedFileNotice by remember { mutableStateOf<ArchiveEntryItem?>(null) }

    LaunchedEffect(item.path) {
        isLoading = true
        errorMessage = null
        val result = fileManager.listArchiveEntries(item.file)
        if (result.isSuccess) {
            allEntries = result.getOrThrow()
        } else {
            errorMessage = result.exceptionOrNull()?.message ?: "Failed to read archive entries"
        }
        isLoading = false
    }

    // Filter entries for the current virtual subdirectory in the archive
    val displayedEntries = remember(allEntries, currentSubPath) {
        val directItems = mutableMapOf<String, ArchiveEntryItem>()
        for (entry in allEntries) {
            val relPath = if (currentSubPath.isEmpty()) {
                entry.path
            } else if (entry.path.startsWith("$currentSubPath/")) {
                entry.path.removePrefix("$currentSubPath/")
            } else {
                continue
            }

            if (relPath.isEmpty()) continue

            val slashIdx = relPath.indexOf('/')
            if (slashIdx == -1) {
                // Direct file or folder at this level
                directItems[entry.name] = entry
            } else {
                // Nested item in subfolder - create virtual directory entry if not present
                val dirName = relPath.substring(0, slashIdx)
                if (!directItems.containsKey(dirName)) {
                    val fullDirPath = if (currentSubPath.isEmpty()) dirName else "$currentSubPath/$dirName"
                    directItems[dirName] = ArchiveEntryItem(
                        path = fullDirPath,
                        name = dirName,
                        isDirectory = true,
                        size = 0L,
                        compressedSize = 0L,
                        lastModified = entry.lastModified,
                        parentPath = currentSubPath
                    )
                }
            }
        }
        directItems.values.sortedWith { a, b ->
            if (a.isDirectory != b.isDirectory) {
                if (a.isDirectory) -1 else 1
            } else {
                a.name.compareTo(b.name, ignoreCase = true)
            }
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .testTag("archive_viewer_dialog"),
            color = DarkBackground
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Top Action Bar
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = DarkSurface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(
                                    onClick = onDismiss,
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "Close Archive Viewer",
                                        tint = Color.White
                                    )
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = item.name,
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White,
                                            maxLines = 1
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(4.dp))
                                                .background(TechAmber.copy(alpha = 0.2f))
                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Text(
                                                text = item.extension.uppercase(),
                                                color = TechAmber,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                    Text(
                                        text = "${allEntries.size} items inside archive",
                                        fontSize = 11.sp,
                                        color = Color(0xFF90A4CE)
                                    )
                                }
                            }

                            // Extract Archive Button
                            Button(
                                onClick = {
                                    onExtractArchive(item)
                                    onDismiss()
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = accent),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.testTag("extract_archive_btn")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Unarchive,
                                    contentDescription = null,
                                    tint = Color.Black,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Extract All",
                                    color = Color.Black,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Archive Path Breadcrumbs
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = item.name,
                                fontSize = 11.sp,
                                fontWeight = if (currentSubPath.isEmpty()) FontWeight.Bold else FontWeight.Medium,
                                color = if (currentSubPath.isEmpty()) accent else Color(0xFF90A4CE),
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .clickable { currentSubPath = "" }
                                    .padding(horizontal = 4.dp, vertical = 2.dp)
                            )

                            if (currentSubPath.isNotEmpty()) {
                                val parts = currentSubPath.split('/')
                                var accumulated = ""
                                parts.forEachIndexed { idx, part ->
                                    Icon(
                                        imageVector = Icons.Default.ChevronRight,
                                        contentDescription = null,
                                        tint = Color(0xFF42567D),
                                        modifier = Modifier.size(12.dp)
                                    )
                                    accumulated = if (accumulated.isEmpty()) part else "$accumulated/$part"
                                    val targetPath = accumulated
                                    val isLast = idx == parts.size - 1
                                    Text(
                                        text = part,
                                        fontSize = 11.sp,
                                        fontWeight = if (isLast) FontWeight.Bold else FontWeight.Medium,
                                        color = if (isLast) accent else Color(0xFF90A4CE),
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .clickable { currentSubPath = targetPath }
                                            .padding(horizontal = 4.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                // Security Policy Banner
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = Color(0xFF1E1428),
                    border = androidx.compose.foundation.BorderStroke(1.dp, TechAmber.copy(alpha = 0.3f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = null,
                            tint = TechAmber,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Browsing archive contents. Files inside archives cannot be opened directly—extract first.",
                            fontSize = 11.sp,
                            color = Color(0xFFDFC6F5)
                        )
                    }
                }

                // Content List
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f)
                ) {
                    when {
                        isLoading -> {
                            Box(
                                modifier = Modifier.fillMaxSize(),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    CircularProgressIndicator(color = accent)
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Text("Reading archive structure...", color = Color.White, fontSize = 12.sp)
                                }
                            }
                        }

                        errorMessage != null -> {
                            Box(
                                modifier = Modifier.fillMaxSize(),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    modifier = Modifier.padding(24.dp)
                                ) {
                                    Text("Error Reading Archive", color = TechRed, fontWeight = FontWeight.Bold)
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(errorMessage ?: "", color = Color.White, fontSize = 12.sp)
                                }
                            }
                        }

                        displayedEntries.isEmpty() -> {
                            Box(
                                modifier = Modifier.fillMaxSize(),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "This archive directory is empty",
                                    color = Color(0xFF90A4CE),
                                    fontSize = 13.sp
                                )
                            }
                        }

                        else -> {
                            LazyColumn(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(horizontal = 12.dp, vertical = 8.dp)
                            ) {
                                // Up directory row if in subfolder
                                if (currentSubPath.isNotEmpty()) {
                                    item {
                                        Surface(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clip(RoundedCornerShape(8.dp))
                                                .clickable {
                                                    val lastSlash = currentSubPath.lastIndexOf('/')
                                                    currentSubPath = if (lastSlash != -1) {
                                                        currentSubPath.substring(0, lastSlash)
                                                    } else {
                                                        ""
                                                    }
                                                }
                                                .padding(vertical = 4.dp),
                                            color = DarkSurfaceElevated,
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(12.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Icon(
                                                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                                    contentDescription = "Up Directory",
                                                    tint = accent,
                                                    modifier = Modifier.size(20.dp)
                                                )
                                                Spacer(modifier = Modifier.width(10.dp))
                                                Text(
                                                    text = ".. (Parent Directory)",
                                                    color = Color.White,
                                                    fontSize = 13.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                        }
                                        Spacer(modifier = Modifier.height(4.dp))
                                    }
                                }

                                items(displayedEntries, key = { it.path }) { entry ->
                                    ArchiveItemRow(
                                        entry = entry,
                                        accent = accent,
                                        onClick = {
                                            if (entry.isDirectory) {
                                                currentSubPath = entry.path
                                            } else {
                                                // STRICT RESTRICTION RULE: Cannot open/view/execute directly
                                                blockedFileNotice = entry
                                            }
                                        }
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Strict Restriction Warning Dialog
    blockedFileNotice?.let { blocked ->
        AlertDialog(
            onDismissRequest = { blockedFileNotice = null },
            icon = {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = null,
                    tint = TechAmber,
                    modifier = Modifier.size(32.dp)
                )
            },
            title = {
                Text(
                    text = "Archive Direct Access Restricted",
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            },
            text = {
                Column {
                    Text(
                        text = "File: ${blocked.name}",
                        color = Color(0xFF90A4CE),
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Files inside archives cannot be opened, viewed, or executed directly under any circumstances. You must extract the archive first to view or use this file.",
                        color = Color.White,
                        fontSize = 13.sp
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        blockedFileNotice = null
                        onExtractArchive(item)
                        onDismiss()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = accent),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Extract Archive", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { blockedFileNotice = null },
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("OK", color = Color(0xFF90A4CE))
                }
            },
            containerColor = DarkSurface,
            shape = RoundedCornerShape(16.dp)
        )
    }
}

@Composable
private fun ArchiveItemRow(
    entry: ArchiveEntryItem,
    accent: Color,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .border(1.dp, DarkSurfaceBorder, RoundedCornerShape(10.dp)),
        color = DarkSurfaceElevated,
        shape = RoundedCornerShape(10.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(
                        if (entry.isDirectory) accent.copy(alpha = 0.15f) else Color(0xFF1E293B)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (entry.isDirectory) Icons.Default.Folder else Icons.Default.Description,
                    contentDescription = null,
                    tint = if (entry.isDirectory) accent else Color(0xFF90A4CE),
                    modifier = Modifier.size(18.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = entry.name,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = if (entry.isDirectory) FontWeight.Bold else FontWeight.Medium,
                    color = Color.White,
                    maxLines = 1
                )
                Spacer(modifier = Modifier.height(2.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = if (entry.isDirectory) "Folder" else entry.formattedSize,
                        fontSize = 11.sp,
                        color = Color(0xFF90A4CE)
                    )
                    Text(
                        text = " • ",
                        fontSize = 11.sp,
                        color = Color(0xFF4A5F82)
                    )
                    Text(
                        text = entry.formattedDate,
                        fontSize = 11.sp,
                        color = Color(0xFF6F85AE)
                    )
                }
            }

            if (entry.isDirectory) {
                Icon(
                    imageVector = Icons.Default.ChevronRight,
                    contentDescription = "Open directory",
                    tint = Color(0xFF6F85AE),
                    modifier = Modifier.size(16.dp)
                )
            } else {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = "Encapsulated in archive",
                    tint = Color(0xFF5A6E94),
                    modifier = Modifier.size(14.dp)
                )
            }
        }
    }
}
