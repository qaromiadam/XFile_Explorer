package com.FileExplorer.XFileExplorer.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material3.Badge
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.FileExplorer.XFileExplorer.model.AppSettings
import com.FileExplorer.XFileExplorer.model.FileItem
import com.FileExplorer.XFileExplorer.model.SortBy
import com.FileExplorer.XFileExplorer.ui.components.BatchSelectionToolbar
import com.FileExplorer.XFileExplorer.ui.components.CornerHamburgerButton
import com.FileExplorer.XFileExplorer.ui.components.FileIconView
import com.FileExplorer.XFileExplorer.ui.theme.DarkSurface
import com.FileExplorer.XFileExplorer.ui.theme.DarkSurfaceBorder
import com.FileExplorer.XFileExplorer.ui.theme.DarkSurfaceElevated
import com.FileExplorer.XFileExplorer.ui.theme.TechCyan
import java.io.File

@Composable
fun ExplorerScreen(
    currentDirectory: File,
    files: List<FileItem>,
    isLoading: Boolean,
    settings: AppSettings,
    selectedFilePaths: Set<String>,
    isBatchMode: Boolean,
    clipboardFiles: List<File>,
    isClipboardCut: Boolean,
    onOpenHamburger: () -> Unit,
    onNavigateDirectory: (File) -> Unit,
    onFileClick: (FileItem) -> Unit,
    onFileLongClick: (FileItem) -> Unit,
    onToggleSelectFile: (FileItem) -> Unit,
    onSelectAll: () -> Unit,
    onDeselectAll: () -> Unit,
    onBatchDelete: () -> Unit,
    onBatchCopy: () -> Unit,
    onBatchCut: () -> Unit,
    onBatchZip: () -> Unit,
    onCancelBatch: () -> Unit,
    onPasteClipboard: () -> Unit,
    onRefresh: () -> Unit,
    onOpenCreateDialog: () -> Unit,
    onSortChange: (SortBy, Boolean) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var isSearching by remember { mutableStateOf(false) }
    var showSortMenu by remember { mutableStateOf(false) }

    val displayedFiles = remember(files, searchQuery) {
        if (searchQuery.isBlank()) files
        else files.filter { it.name.contains(searchQuery.trim(), ignoreCase = true) }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
    ) {
        // Top App Bar
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = DarkSurface.copy(alpha = settings.cardOpacity),
            border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // Requirement 2: Corner hamburger icon trigger
                        CornerHamburgerButton(
                            onClick = onOpenHamburger,
                            accent = settings.currentAccent
                        )

                        Spacer(modifier = Modifier.width(10.dp))

                        val canGoUp = com.FileExplorer.XFileExplorer.data.FileManager.canNavigateUp(currentDirectory)
                        if (canGoUp && currentDirectory.parentFile != null) {
                            IconButton(
                                onClick = { onNavigateDirectory(currentDirectory.parentFile!!) },
                                modifier = Modifier
                                    .size(36.dp)
                                    .testTag("nav_up_dir_btn")
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                    contentDescription = "Up Directory",
                                    tint = Color.White
                                )
                            }
                        }

                        Text(
                            text = com.FileExplorer.XFileExplorer.data.FileManager.getDirectoryDisplayName(currentDirectory, settings),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            maxLines = 1
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = { isSearching = !isSearching },
                            modifier = Modifier
                                .size(36.dp)
                                .testTag("toggle_search_btn")
                        ) {
                            Icon(
                                imageVector = if (isSearching) Icons.Default.Close else Icons.Default.Search,
                                contentDescription = "Search",
                                tint = if (isSearching) settings.currentAccent else Color.White
                            )
                        }

                        IconButton(
                            onClick = { showSortMenu = true },
                            modifier = Modifier
                                .size(36.dp)
                                .testTag("sort_menu_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Sort,
                                contentDescription = "Sort",
                                tint = Color.White
                            )
                        }

                        DropdownMenu(
                            expanded = showSortMenu,
                            onDismissRequest = { showSortMenu = false }
                        ) {
                            val isDate = settings.sortBy == SortBy.DATE
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        text = if (isDate) "Date (${if (settings.sortAscending) "Oldest First" else "Newest First"}) ✓" else "Date (Newest First)",
                                        fontWeight = if (isDate) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isDate) settings.currentAccent else Color.White
                                    )
                                },
                                onClick = {
                                    val nextAsc = if (isDate) !settings.sortAscending else false
                                    onSortChange(SortBy.DATE, nextAsc)
                                    showSortMenu = false
                                }
                            )

                            val isName = settings.sortBy == SortBy.NAME
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        text = if (isName) "Name (${if (settings.sortAscending) "A - Z" else "Z - A"}) ✓" else "Name (A - Z)",
                                        fontWeight = if (isName) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isName) settings.currentAccent else Color.White
                                    )
                                },
                                onClick = {
                                    val nextAsc = if (isName) !settings.sortAscending else true
                                    onSortChange(SortBy.NAME, nextAsc)
                                    showSortMenu = false
                                }
                            )

                            val isSize = settings.sortBy == SortBy.SIZE
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        text = if (isSize) "Size (${if (settings.sortAscending) "Smallest First" else "Largest First"}) ✓" else "Size (Largest First)",
                                        fontWeight = if (isSize) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isSize) settings.currentAccent else Color.White
                                    )
                                },
                                onClick = {
                                    val nextAsc = if (isSize) !settings.sortAscending else false
                                    onSortChange(SortBy.SIZE, nextAsc)
                                    showSortMenu = false
                                }
                            )

                            val isType = settings.sortBy == SortBy.TYPE
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        text = if (isType) "Type (${if (settings.sortAscending) "A - Z" else "Z - A"}) ✓" else "Type (A - Z)",
                                        fontWeight = if (isType) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isType) settings.currentAccent else Color.White
                                    )
                                },
                                onClick = {
                                    val nextAsc = if (isType) !settings.sortAscending else true
                                    onSortChange(SortBy.TYPE, nextAsc)
                                    showSortMenu = false
                                }
                            )
                        }

                        IconButton(
                            onClick = onRefresh,
                            modifier = Modifier
                                .size(36.dp)
                                .testTag("refresh_files_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Refresh",
                                tint = settings.currentAccent
                            )
                        }
                    }
                }

                // Search field when active
                AnimatedVisibility(visible = isSearching) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text("Filter files in current folder...", fontSize = 12.sp) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = settings.currentAccent,
                            unfocusedBorderColor = DarkSurfaceBorder,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp)
                            .testTag("search_files_input")
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Breadcrumb path navigation
                BreadcrumbPathRow(
                    currentDirectory = currentDirectory,
                    settings = settings,
                    accent = settings.currentAccent,
                    onNavigate = onNavigateDirectory
                )
            }
        }

        // Batch selection bar if active
        if (isBatchMode) {
            BatchSelectionToolbar(
                selectedCount = selectedFilePaths.size,
                totalCount = files.size,
                accent = settings.currentAccent,
                onSelectAll = onSelectAll,
                onDeselectAll = onDeselectAll,
                onBatchDelete = onBatchDelete,
                onBatchCopy = onBatchCopy,
                onBatchCut = onBatchCut,
                onBatchZip = onBatchZip,
                onCancelBatch = onCancelBatch
            )
        }

        // Main Files View
        Box(modifier = Modifier.fillMaxSize()) {
            if (isLoading) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(color = settings.currentAccent)
                }
            } else if (displayedFiles.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.Folder,
                            contentDescription = null,
                            tint = Color(0xFF5F759E),
                            modifier = Modifier.size(54.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = if (searchQuery.isNotEmpty()) "No matching files found" else "Directory is empty",
                            color = Color(0xFF90A4CE),
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                        .testTag("files_list")
                ) {
                    items(
                        items = displayedFiles,
                        key = { it.path },
                        contentType = { if (it.isDirectory) 0 else 1 }
                    ) { item ->
                        val isSelected = selectedFilePaths.contains(item.path)

                        FileItemRow(
                            item = item,
                            settings = settings,
                            isBatchMode = isBatchMode,
                            isSelected = isSelected,
                            onClick = {
                                if (isBatchMode) {
                                    onToggleSelectFile(item)
                                } else {
                                    onFileClick(item)
                                }
                            },
                            onLongClick = {
                                onFileLongClick(item)
                            }
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                    }
                    // Bottom padding for FAB and system navigation insets
                    item {
                        Spacer(
                            modifier = Modifier
                                .height(84.dp)
                                .navigationBarsPadding()
                        )
                    }
                }
            }

            // Floating Action Buttons (Create & Paste)
            Column(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .navigationBarsPadding()
                    .padding(16.dp),
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Clipboard paste button
                if (clipboardFiles.isNotEmpty()) {
                    FloatingActionButton(
                        onClick = onPasteClipboard,
                        containerColor = TechCyan,
                        contentColor = Color.Black,
                        modifier = Modifier.testTag("paste_clipboard_fab")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.ContentPaste,
                                contentDescription = "Paste items"
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Paste (${clipboardFiles.size})",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                    }
                }

                // Add item FAB
                FloatingActionButton(
                    onClick = onOpenCreateDialog,
                    containerColor = settings.currentAccent,
                    contentColor = Color.Black,
                    modifier = Modifier.testTag("create_item_fab")
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Create File or Folder",
                        modifier = Modifier.size(28.dp)
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun BreadcrumbPathRow(
    currentDirectory: File,
    settings: AppSettings,
    accent: Color,
    onNavigate: (File) -> Unit
) {
    val pathSegments = remember(currentDirectory) {
        val list = mutableListOf<File>()
        var curr: File? = currentDirectory
        val boundaryPath = com.FileExplorer.XFileExplorer.data.FileManager.NAVIGATION_BOUNDARY_PATH
        while (curr != null) {
            val currClean = curr.absolutePath.trimEnd('/')
            if (currClean == "/storage/emulated" || currClean == "/storage" || currClean == "") {
                break
            }
            list.add(0, curr)
            if (currClean == boundaryPath) {
                break
            }
            curr = curr.parentFile
        }
        if (list.isEmpty()) {
            list.add(File(boundaryPath))
        }
        list
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        verticalAlignment = Alignment.CenterVertically
    ) {
        pathSegments.forEachIndexed { index, seg ->
            val isLast = index == pathSegments.size - 1
            val label = com.FileExplorer.XFileExplorer.data.FileManager.getDirectoryDisplayName(seg, settings)

            Text(
                text = label,
                fontSize = 11.sp,
                fontWeight = if (isLast) FontWeight.Bold else FontWeight.Medium,
                color = if (isLast) accent else Color(0xFF90A4CE),
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .combinedClickable(
                        onClick = { onNavigate(seg) }
                    )
                    .padding(horizontal = 4.dp, vertical = 2.dp)
            )

            if (!isLast) {
                Icon(
                    imageVector = Icons.Default.ChevronRight,
                    contentDescription = null,
                    tint = Color(0xFF42567D),
                    modifier = Modifier.size(12.dp)
                )
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun FileItemRow(
    item: FileItem,
    settings: AppSettings,
    isBatchMode: Boolean,
    isSelected: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick
            )
            .border(
                1.dp,
                if (isSelected) settings.currentAccent else DarkSurfaceBorder,
                RoundedCornerShape(12.dp)
            )
            .testTag("file_item_${item.name}"),
        color = if (isSelected) settings.currentAccent.copy(alpha = 0.16f) else DarkSurfaceElevated.copy(alpha = settings.cardOpacity),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Batch selection check box
            if (isBatchMode) {
                Icon(
                    imageVector = if (isSelected) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                    contentDescription = if (isSelected) "Selected" else "Not selected",
                    tint = if (isSelected) settings.currentAccent else Color(0xFF5F759E),
                    modifier = Modifier
                        .size(22.dp)
                        .testTag("batch_check_${item.name}")
                )
                Spacer(modifier = Modifier.width(10.dp))
            }

            // Dynamic File Icon Engine
            FileIconView(
                item = item,
                settings = settings,
                sizeDp = 42
            )

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = item.name,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.White,
                    maxLines = 1
                )
                Spacer(modifier = Modifier.height(2.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = item.formattedSize,
                        fontSize = 11.sp,
                        color = Color(0xFF90A4CE)
                    )
                    Text(
                        text = " • ",
                        fontSize = 11.sp,
                        color = Color(0xFF4A5F82)
                    )
                    Text(
                        text = item.formattedDate,
                        fontSize = 11.sp,
                        color = Color(0xFF90A4CE)
                    )
                }
            }
        }
    }
}
