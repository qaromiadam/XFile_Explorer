package com.FileExplorer.XFileExplorer.model

import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class FileType {
    DIRECTORY,
    IMAGE,
    VIDEO,
    AUDIO,
    DOCUMENT,
    ARCHIVE_ZIP,
    ARCHIVE_OTHER,
    APK,
    CODE,
    TEXT,
    UNKNOWN;

    companion object {
        fun fromFile(file: File): FileType {
            if (file.isDirectory) return DIRECTORY
            val ext = file.extension.lowercase()
            return when (ext) {
                "jpg", "jpeg", "png", "webp", "gif", "bmp", "heic", "svg" -> IMAGE
                "mp4", "mkv", "avi", "mov", "webm", "3gp", "flv", "wmv" -> VIDEO
                "mp3", "wav", "ogg", "flac", "m4a", "aac", "opus" -> AUDIO
                "pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx" -> DOCUMENT
                "zip" -> ARCHIVE_ZIP
                "7z", "tar", "gz", "bz2", "xz", "rar", "tgz" -> ARCHIVE_OTHER
                "apk", "apks", "xapk" -> APK
                "kt", "java", "py", "js", "ts", "html", "css", "c", "cpp", "h", "hpp", "rs", "go",
                "sh", "bash", "json", "xml", "yml", "yaml", "sql", "md", "gradle", "kts" -> CODE
                "txt", "log", "conf", "prop", "properties", "ini", "env" -> TEXT
                else -> UNKNOWN
            }
        }
    }
}

data class FileItem(
    val file: File,
    val name: String = file.name.ifEmpty { "/" },
    val path: String = file.absolutePath,
    val isDirectory: Boolean = file.isDirectory,
    val size: Long = calculateRecursiveSize(file),
    val formattedSize: String = formatBytes(size),
    val lastModified: Long = file.lastModified(),
    val formattedDate: String = formatDate(file.lastModified()),
    val extension: String = file.extension.lowercase(),
    val type: FileType = FileType.fromFile(file),
    val canRead: Boolean = file.canRead(),
    val canWrite: Boolean = file.canWrite(),
    val isHidden: Boolean = file.isHidden || file.name.startsWith("."),
    val isSystemProtected: Boolean = isPathSystemProtected(file)
) {
    companion object {
        fun formatDate(timestamp: Long): String {
            if (timestamp <= 0) return "Unknown"
            val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
            return sdf.format(Date(timestamp))
        }

        fun formatBytes(bytes: Long): String {
            if (bytes <= 0) return "0 B"
            val units = arrayOf("B", "KB", "MB", "GB", "TB")
            var digitGroups = 0
            var temp = bytes.toDouble()
            while (temp >= 1024.0 && digitGroups < units.size - 1) {
                temp /= 1024.0
                digitGroups++
            }
            return if (digitGroups == 0) "$bytes B" else String.format(Locale.US, "%.1f %s", temp, units[digitGroups])
        }

        fun calculateRecursiveSize(file: File): Long {
            if (!file.exists()) return 0L
            if (!file.isDirectory) return file.length()
            if (!file.canRead()) return 0L
            var total = 0L
            val visited = HashSet<String>()
            val stack = ArrayDeque<File>()
            stack.add(file)
            while (!stack.isEmpty()) {
                val current = stack.removeFirst()
                val canonical = try { current.canonicalPath } catch (_: Exception) { current.absolutePath }
                if (!visited.add(canonical)) continue

                val children = current.listFiles() ?: continue
                for (child in children) {
                    if (child.isDirectory) {
                        if (child.canRead()) {
                            stack.add(child)
                        }
                    } else {
                        total += child.length()
                    }
                }
            }
            return total
        }

        fun isPathSystemProtected(file: File): Boolean {
            val path = file.absolutePath
            return path.startsWith("/data") && !path.startsWith("/data/user/0") && !path.startsWith("/data/data") ||
                   path == "/system" || path.startsWith("/system/bin") ||
                   path == "/vendor" || path == "/apex"
        }
    }
}

data class ArchiveEntryItem(
    val path: String,
    val name: String,
    val isDirectory: Boolean,
    val size: Long,
    val compressedSize: Long,
    val lastModified: Long,
    val parentPath: String
) {
    val formattedSize: String
        get() = when {
            isDirectory -> "--"
            size <= 0L -> "?B"
            else -> FileItem.formatBytes(size)
        }
    val formattedDate: String
        get() = FileItem.formatDate(lastModified)
}

