package com.FileExplorer.XFileExplorer.ui

import android.app.Application
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.FileExplorer.XFileExplorer.data.AndroidSecurityBlockedException
import com.FileExplorer.XFileExplorer.data.FileManager
import com.FileExplorer.XFileExplorer.data.FileWatcher
import com.FileExplorer.XFileExplorer.data.PreferencesManager
import com.FileExplorer.XFileExplorer.data.TerminalEngine
import com.FileExplorer.XFileExplorer.model.AppSettings
import com.FileExplorer.XFileExplorer.model.FileItem
import com.FileExplorer.XFileExplorer.model.FileType
import com.FileExplorer.XFileExplorer.model.LineType
import com.FileExplorer.XFileExplorer.model.SortBy
import com.FileExplorer.XFileExplorer.model.TerminalLine
import com.FileExplorer.XFileExplorer.ui.components.ScreenDestination
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import androidx.core.content.ContextCompat
import com.FileExplorer.XFileExplorer.model.AppPermissionInfo
import java.io.File

data class FileOperationProgress(
    val title: String,
    val currentFileName: String,
    val bytesProcessed: Long,
    val totalBytes: Long,
    val percentage: Int
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    val fileManager = FileManager(application)
    val preferencesManager = PreferencesManager(application)
    val terminalEngine = TerminalEngine(
        fileManager = fileManager,
        initialDirectory = fileManager.rootStorageDirectory,
        permissionProvider = { getLiveAppPermissions() }
    )

    // Current Directory and Files
    private val _currentDirectory = MutableStateFlow<File>(fileManager.rootStorageDirectory)
    val currentDirectory: StateFlow<File> = _currentDirectory.asStateFlow()

    private val _files = MutableStateFlow<List<FileItem>>(emptyList())
    val files: StateFlow<List<FileItem>> = _files.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    // Navigation and Panels
    private val _currentDestination = MutableStateFlow(ScreenDestination.EXPLORER)
    val currentDestination: StateFlow<ScreenDestination> = _currentDestination.asStateFlow()

    private val _isHamburgerOpen = MutableStateFlow(false)
    val isHamburgerOpen: StateFlow<Boolean> = _isHamburgerOpen.asStateFlow()

    // Settings (Persistent preferences storage)
    private val _settings = MutableStateFlow(preferencesManager.loadSettings())
    val settings: StateFlow<AppSettings> = _settings.asStateFlow()

    // Batch Selection Mode
    private val _selectedFilePaths = MutableStateFlow<Set<String>>(emptySet())
    val selectedFilePaths: StateFlow<Set<String>> = _selectedFilePaths.asStateFlow()

    private val _isBatchMode = MutableStateFlow(false)
    val isBatchMode: StateFlow<Boolean> = _isBatchMode.asStateFlow()

    // Clipboard (Copy/Cut)
    private val _clipboardFiles = MutableStateFlow<List<File>>(emptyList())
    val clipboardFiles: StateFlow<List<File>> = _clipboardFiles.asStateFlow()

    private val _isClipboardCut = MutableStateFlow(false)
    val isClipboardCut: StateFlow<Boolean> = _isClipboardCut.asStateFlow()

    // Context Menu & Active Viewers
    private val _contextMenuItem = MutableStateFlow<FileItem?>(null)
    val contextMenuItem: StateFlow<FileItem?> = _contextMenuItem.asStateFlow()

    private val _activeImageViewerItem = MutableStateFlow<FileItem?>(null)
    val activeImageViewerItem: StateFlow<FileItem?> = _activeImageViewerItem.asStateFlow()

    private val _activeFileReaderItem = MutableStateFlow<FileItem?>(null)
    val activeFileReaderItem: StateFlow<FileItem?> = _activeFileReaderItem.asStateFlow()

    private val _activeVideoPlayerItem = MutableStateFlow<FileItem?>(null)
    val activeVideoPlayerItem: StateFlow<FileItem?> = _activeVideoPlayerItem.asStateFlow()

    private val _activeAudioPlayerItem = MutableStateFlow<FileItem?>(null)
    val activeAudioPlayerItem: StateFlow<FileItem?> = _activeAudioPlayerItem.asStateFlow()

    private val _activeArchiveViewerItem = MutableStateFlow<FileItem?>(null)
    val activeArchiveViewerItem: StateFlow<FileItem?> = _activeArchiveViewerItem.asStateFlow()

    private val _activePdfViewerItem = MutableStateFlow<FileItem?>(null)
    val activePdfViewerItem: StateFlow<FileItem?> = _activePdfViewerItem.asStateFlow()

    // Extension Guard Dialog state: Pair<fromExt, toExt>
    private val _extensionGuardWarning = MutableStateFlow<Pair<String, String>?>(null)
    val extensionGuardWarning: StateFlow<Pair<String, String>?> = _extensionGuardWarning.asStateFlow()

    // Compression Dialog state
    data class CompressDialogState(
        val items: List<FileItem>,
        val defaultName: String
    )

    private val _compressDialogState = MutableStateFlow<CompressDialogState?>(null)
    val compressDialogState: StateFlow<CompressDialogState?> = _compressDialogState.asStateFlow()

    // Dialog states
    private val _deviceRoots = MutableStateFlow<List<File>>(emptyList())
    val deviceRoots: StateFlow<List<File>> = _deviceRoots.asStateFlow()

    private val _showCreateDialog = MutableStateFlow(false)
    val showCreateDialog: StateFlow<Boolean> = _showCreateDialog.asStateFlow()

    private val _showRenameItem = MutableStateFlow<FileItem?>(null)
    val showRenameItem: StateFlow<FileItem?> = _showRenameItem.asStateFlow()

    private val _showPropertiesItem = MutableStateFlow<FileItem?>(null)
    val showPropertiesItem: StateFlow<FileItem?> = _showPropertiesItem.asStateFlow()

    private val _showDeleteConfirmItems = MutableStateFlow<List<FileItem>?>(null)
    val showDeleteConfirmItems: StateFlow<List<FileItem>?> = _showDeleteConfirmItems.asStateFlow()

    // Security Exception Dialog state
    private val _securityBlockedPath = MutableStateFlow<String?>(null)
    val securityBlockedPath: StateFlow<String?> = _securityBlockedPath.asStateFlow()

    // Terminal Emulator State
    private val _terminalLines = MutableStateFlow<List<TerminalLine>>(emptyList())
    val terminalLines: StateFlow<List<TerminalLine>> = _terminalLines.asStateFlow()

    private val _isWaitingForHelpPagination = MutableStateFlow(false)
    val isWaitingForHelpPagination: StateFlow<Boolean> = _isWaitingForHelpPagination.asStateFlow()

    // Permissions Command Trigger Event
    private val _requestUngrantedPermissions = MutableStateFlow<List<String>?>(null)
    val requestUngrantedPermissions: StateFlow<List<String>?> = _requestUngrantedPermissions.asStateFlow()

    private val _requestSinglePermission = MutableStateFlow<String?>(null)
    val requestSinglePermission: StateFlow<String?> = _requestSinglePermission.asStateFlow()

    fun clearPermissionRequest() {
        _requestUngrantedPermissions.value = null
    }

    fun onSinglePermissionHandled() {
        _requestSinglePermission.value = null
    }

    // File Operation Progress State
    private val _operationProgress = MutableStateFlow<FileOperationProgress?>(null)
    val operationProgress: StateFlow<FileOperationProgress?> = _operationProgress.asStateFlow()

    fun updateOperationProgress(progress: FileOperationProgress?) {
        _operationProgress.value = progress
    }

    fun dismissOperationProgress() {
        _operationProgress.value = null
    }

    fun getLiveAppPermissions(): List<AppPermissionInfo> {
        val context = getApplication<Application>()
        val sdk = Build.VERSION.SDK_INT
        val isDumpGranted = ContextCompat.checkSelfPermission(context, Manifest.permission.DUMP) == PackageManager.PERMISSION_GRANTED
        val isManageGranted = if (sdk >= Build.VERSION_CODES.R) {
            Environment.isExternalStorageManager()
        } else {
            ContextCompat.checkSelfPermission(context, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
        }
        val isReadApplicable = sdk <= 32
        val isReadGranted = if (isReadApplicable) {
            ContextCompat.checkSelfPermission(context, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
        } else {
            isManageGranted
        }
        val isWriteApplicable = sdk <= 29
        val isWriteGranted = if (isWriteApplicable) {
            ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
        } else {
            isManageGranted
        }

        return listOf(
            AppPermissionInfo(
                key = "internet",
                manifestName = "android.permission.INTERNET",
                isGranted = true,
                isApplicable = true,
                isInstallTime = true
            ),
            AppPermissionInfo(
                key = "network_state",
                manifestName = "android.permission.ACCESS_NETWORK_STATE",
                isGranted = true,
                isApplicable = true,
                isInstallTime = true
            ),
            AppPermissionInfo(
                key = "read_storage",
                manifestName = "android.permission.READ_EXTERNAL_STORAGE",
                isGranted = isReadGranted,
                isApplicable = isReadApplicable,
                ungrantedReason = if (!isReadApplicable) "Superseded by Scoped Storage (API > 32)" else "Required for reading device files"
            ),
            AppPermissionInfo(
                key = "write_storage",
                manifestName = "android.permission.WRITE_EXTERNAL_STORAGE",
                isGranted = isWriteGranted,
                isApplicable = isWriteApplicable,
                ungrantedReason = if (!isWriteApplicable) "Superseded by Scoped Storage (API > 29)" else "Required for saving/modifying files"
            ),
            AppPermissionInfo(
                key = "manage_external_storage",
                manifestName = "android.permission.MANAGE_EXTERNAL_STORAGE",
                isGranted = isManageGranted,
                isApplicable = sdk >= Build.VERSION_CODES.R,
                ungrantedReason = "All files access needed to manage device storage"
            ),
            AppPermissionInfo(
                key = "dump",
                manifestName = "android.permission.DUMP",
                isGranted = isDumpGranted,
                isApplicable = true,
                ungrantedReason = "System signature/privileged permission for diagnostics"
            ),
            AppPermissionInfo(
                key = "install_packages",
                manifestName = "android.permission.REQUEST_INSTALL_PACKAGES",
                isGranted = if (sdk >= Build.VERSION_CODES.O) context.packageManager.canRequestPackageInstalls() else true,
                isApplicable = sdk >= Build.VERSION_CODES.O,
                ungrantedReason = "Required to install and update APK applications from explorer"
            )
        )
    }

    // Cache Synchronization Loop
    private val fileWatcher = FileWatcher(
        scope = viewModelScope,
        pollIntervalMs = 2000L,
        onDirectoryChanged = {
            refreshDirectoryInternal()
        }
    )

    init {
        // Initial welcome lines in terminal
        _terminalLines.value = listOf(
            TerminalLine("XFile Explorer Terminal System [Android Toybox]", LineType.INFO),
            TerminalLine("Linux localhost aarch64 - Type 'help' to browse Toybox commands (10/page).", LineType.SUCCESS),
            TerminalLine("Tip: Run 'permissions' to inspect and request required app storage/network access.", LineType.WARNING),
            TerminalLine("Directory context: ${_currentDirectory.value.absolutePath}", LineType.OUTPUT)
        )

        _deviceRoots.value = fileManager.getDeviceRoots()
        loadDirectory(_currentDirectory.value)
    }

    fun refreshRoots() {
        _deviceRoots.value = fileManager.getDeviceRoots()
    }

    fun openHamburger() { _isHamburgerOpen.value = true }
    fun closeHamburger() { _isHamburgerOpen.value = false }

    fun navigateTo(destination: ScreenDestination) {
        _currentDestination.value = destination
        _isHamburgerOpen.value = false
    }

    fun updateSettings(newSettings: AppSettings) {
        val oldSettings = _settings.value
        _settings.value = newSettings
        preferencesManager.saveSettings(newSettings)
        if (oldSettings.showHiddenFiles != newSettings.showHiddenFiles) {
            viewModelScope.launch {
                refreshDirectoryInternal()
            }
        } else {
            sortFilesList()
        }
    }

    fun loadDirectory(directory: File) {
        val path = directory.absolutePath.trimEnd('/')
        val canonical = try { directory.canonicalPath.trimEnd('/') } catch (_: Exception) { path }
        if (canonical == "/storage/emulated" || canonical == "/storage" || canonical == "" || canonical == "/") {
            loadDirectory(fileManager.rootStorageDirectory)
            return
        }

        viewModelScope.launch {
            _isLoading.value = true
            _currentDirectory.value = directory
            terminalEngine.setWorkingDirectory(directory)
            fileWatcher.startWatching(directory)

            val result = fileManager.listFiles(directory, showHidden = _settings.value.showHiddenFiles)
            if (result.isSuccess) {
                _files.value = result.getOrThrow()
                sortFilesList()
            } else {
                val ex = result.exceptionOrNull()
                if (ex is AndroidSecurityBlockedException) {
                    _securityBlockedPath.value = ex.blockedPath
                } else {
                    _securityBlockedPath.value = directory.absolutePath
                }
            }
            _isLoading.value = false
            // Clear batch selections on folder change
            _selectedFilePaths.value = emptySet()
            _isBatchMode.value = false
        }
    }

    fun refreshCurrentDirectory() {
        loadDirectory(_currentDirectory.value)
    }

    private suspend fun refreshDirectoryInternal() {
        val dir = _currentDirectory.value
        val result = fileManager.listFiles(dir, showHidden = _settings.value.showHiddenFiles)
        if (result.isSuccess) {
            _files.value = result.getOrThrow()
            sortFilesList()
        }
    }

    fun sortFiles(sortBy: SortBy, ascending: Boolean) {
        val updated = _settings.value.copy(sortBy = sortBy, sortAscending = ascending)
        _settings.value = updated
        preferencesManager.saveSettings(updated)
        sortFilesList()
    }

    private fun sortFilesList() {
        val currentList = _files.value
        val ascending = _settings.value.sortAscending
        val sorted = currentList.sortedWith { a, b ->
            // Folders ALWAYS on top
            if (a.isDirectory != b.isDirectory) {
                return@sortedWith if (a.isDirectory) -1 else 1
            }
            val comp = when (_settings.value.sortBy) {
                SortBy.NAME -> a.name.compareTo(b.name, ignoreCase = true)
                SortBy.SIZE -> a.size.compareTo(b.size)
                SortBy.DATE -> a.lastModified.compareTo(b.lastModified)
                SortBy.TYPE -> {
                    val extComp = a.extension.compareTo(b.extension, ignoreCase = true)
                    if (extComp != 0) extComp else a.name.compareTo(b.name, ignoreCase = true)
                }
            }
            val dir = if (ascending) 1 else -1
            val res = comp * dir
            if (res != 0) res else a.name.compareTo(b.name, ignoreCase = true)
        }
        _files.value = sorted
    }

    // File Click handler (Opens viewer or navigates directory)
    fun onFileClicked(item: FileItem) {
        if (item.isDirectory) {
            if (fileManager.isSystemBlocked(item.file)) {
                _securityBlockedPath.value = item.path
            } else {
                loadDirectory(item.file)
            }
        } else {
            openFileViewer(item)
        }
    }

    fun openFileViewer(item: FileItem) {
        if (item.file.extension.equals("pdf", ignoreCase = true)) {
            _activePdfViewerItem.value = item
            return
        }
        when (item.type) {
            FileType.IMAGE -> _activeImageViewerItem.value = item
            FileType.VIDEO -> _activeVideoPlayerItem.value = item
            FileType.AUDIO -> _activeAudioPlayerItem.value = item
            FileType.ARCHIVE_ZIP, FileType.ARCHIVE_OTHER -> _activeArchiveViewerItem.value = item
            FileType.APK -> tryOpenApk(item)
            else -> _activeFileReaderItem.value = item
        }
    }

    fun closePdfViewer() {
        _activePdfViewerItem.value = null
    }

    private fun tryOpenApk(item: FileItem) {
        try {
            val app = getApplication<Application>()
            val uri = androidx.core.content.FileProvider.getUriForFile(
                app,
                "${app.packageName}.provider",
                item.file
            )
            val intent = android.content.Intent(android.content.Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/vnd.android.package-archive")
                addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            app.startActivity(intent)
        } catch (_: Exception) {
            _activeFileReaderItem.value = item
        }
    }

    fun closeImageViewer() { _activeImageViewerItem.value = null }
    fun closeFileReader() { _activeFileReaderItem.value = null }
    fun closeVideoPlayer() { _activeVideoPlayerItem.value = null }
    fun closeAudioPlayer() { _activeAudioPlayerItem.value = null }
    fun closeArchiveViewer() { _activeArchiveViewerItem.value = null }

    // Context Menu & Long-Press
    fun onFileLongClicked(item: FileItem) {
        _contextMenuItem.value = item
    }

    fun dismissContextMenu() {
        _contextMenuItem.value = null
    }

    // Batch Selection Mode
    fun enterBatchMode(initialItem: FileItem? = null) {
        _isBatchMode.value = true
        _selectedFilePaths.value = if (initialItem != null) setOf(initialItem.path) else emptySet()
    }

    fun exitBatchMode() {
        _isBatchMode.value = false
        _selectedFilePaths.value = emptySet()
    }

    fun toggleFileSelection(item: FileItem) {
        val current = _selectedFilePaths.value.toMutableSet()
        if (current.contains(item.path)) {
            current.remove(item.path)
        } else {
            current.add(item.path)
        }
        _selectedFilePaths.value = current
    }

    fun selectAllFiles() {
        _selectedFilePaths.value = _files.value.map { it.path }.toSet()
    }

    fun deselectAllFiles() {
        _selectedFilePaths.value = emptySet()
    }

    // Actions
    fun openCreateDialog() { _showCreateDialog.value = true }
    fun closeCreateDialog() { _showCreateDialog.value = false }

    fun createFolder(name: String) {
        viewModelScope.launch {
            val res = fileManager.createFolder(_currentDirectory.value, name)
            if (res.isSuccess) {
                refreshCurrentDirectory()
            } else {
                val ex = res.exceptionOrNull()
                if (ex is AndroidSecurityBlockedException) {
                    _securityBlockedPath.value = ex.blockedPath
                }
            }
        }
    }

    fun createFile(name: String) {
        viewModelScope.launch {
            val res = fileManager.createFile(_currentDirectory.value, name)
            if (res.isSuccess) {
                refreshCurrentDirectory()
            } else {
                val ex = res.exceptionOrNull()
                if (ex is AndroidSecurityBlockedException) {
                    _securityBlockedPath.value = ex.blockedPath
                }
            }
        }
    }

    fun openRenameDialog(item: FileItem) { _showRenameItem.value = item }
    fun closeRenameDialog() { _showRenameItem.value = null }
    fun dismissExtensionGuard() { _extensionGuardWarning.value = null }

    fun renameItem(item: FileItem, newName: String) {
        val extChange = FileManager.checkExtensionChange(item.file, newName)
        if (extChange != null) {
            _extensionGuardWarning.value = extChange
            return
        }
        viewModelScope.launch {
            val res = fileManager.rename(item.file, newName)
            if (res.isSuccess) {
                refreshCurrentDirectory()
            } else {
                val ex = res.exceptionOrNull()
                if (ex is AndroidSecurityBlockedException) {
                    _securityBlockedPath.value = ex.blockedPath
                }
            }
        }
    }

    fun openPropertiesDialog(item: FileItem) { _showPropertiesItem.value = item }
    fun closePropertiesDialog() { _showPropertiesItem.value = null }

    fun confirmDelete(items: List<FileItem>) {
        _showDeleteConfirmItems.value = items
    }

    fun closeDeleteConfirm() {
        _showDeleteConfirmItems.value = null
    }

    fun executeDelete(items: List<FileItem>) {
        viewModelScope.launch {
            for (item in items) {
                fileManager.delete(item.file)
            }
            refreshCurrentDirectory()
            exitBatchMode()
        }
    }

    // Clipboard
    fun copyToClipboard(items: List<FileItem>, isCut: Boolean = false) {
        _clipboardFiles.value = items.map { it.file }
        _isClipboardCut.value = isCut
        exitBatchMode()
    }

    fun pasteClipboard() {
        val targets = _clipboardFiles.value
        val isCut = _isClipboardCut.value
        val dest = _currentDirectory.value

        viewModelScope.launch {
            for (target in targets) {
                if (isCut) {
                    fileManager.move(target, dest)
                } else {
                    fileManager.copy(target, dest)
                }
            }
            _clipboardFiles.value = emptyList()
            _isClipboardCut.value = false
            refreshCurrentDirectory()
        }
    }

    // Archiving: Zip Dialog & Execution
    fun openCompressDialog(items: List<FileItem>) {
        val first = items.firstOrNull() ?: return
        val baseName = if (items.size == 1) first.file.nameWithoutExtension else "archive_${System.currentTimeMillis()}"
        _compressDialogState.value = CompressDialogState(items, baseName)
    }

    fun dismissCompressDialog() {
        _compressDialogState.value = null
    }

    fun executeCompression(archiveName: String, compressionLevel: Int) {
        val req = _compressDialogState.value ?: return
        dismissCompressDialog()
        viewModelScope.launch {
            val destExt = ".zip"
            val cleanName = if (archiveName.endsWith(destExt, ignoreCase = true)) archiveName else "$archiveName$destExt"
            val destFile = File(_currentDirectory.value, cleanName)

            val filesToCompress = req.items.map { it.file }
            _operationProgress.value = FileOperationProgress(
                title = "Compressing to ${destFile.name}",
                currentFileName = "Initializing...",
                bytesProcessed = 0L,
                totalBytes = 1L,
                percentage = 0
            )

            val res = fileManager.compressToZip(
                items = filesToCompress,
                destinationZip = destFile,
                compressionLevel = compressionLevel,
                onProgress = { curFile, written, total ->
                    val pct = if (total > 0L) ((written.toFloat() / total.toFloat()) * 100).toInt().coerceIn(0, 100) else 0
                    _operationProgress.value = FileOperationProgress(
                        title = "Compressing to ${destFile.name}",
                        currentFileName = curFile,
                        bytesProcessed = written,
                        totalBytes = total,
                        percentage = pct
                    )
                }
            )
            _operationProgress.value = null

            if (res.isSuccess) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(getApplication(), "Archive created: ${destFile.name}", Toast.LENGTH_SHORT).show()
                }
                refreshCurrentDirectory()
                exitBatchMode()
            } else {
                val ex = res.exceptionOrNull()
                withContext(Dispatchers.Main) {
                    Toast.makeText(getApplication(), "Compression failed: ${ex?.message ?: "Unknown error"}", Toast.LENGTH_LONG).show()
                }
                if (ex is AndroidSecurityBlockedException) {
                    _securityBlockedPath.value = ex.blockedPath
                }
            }
        }
    }

    fun extractArchive(item: FileItem) {
        viewModelScope.launch {
            val parent = item.file.parentFile ?: _currentDirectory.value
            var outDirName = item.file.nameWithoutExtension
            if (outDirName.isBlank()) outDirName = "extracted"
            var outDir = File(parent, outDirName)
            if (outDir.exists() && !outDir.isDirectory) {
                outDir = File(parent, "${outDirName}_extracted")
            }

            _operationProgress.value = FileOperationProgress(
                title = "Extracting ${item.name}",
                currentFileName = "Initializing...",
                bytesProcessed = 0L,
                totalBytes = 1L,
                percentage = 0
            )

            val res = fileManager.extractArchive(
                archiveFile = item.file,
                outputDir = outDir,
                onProgress = { curEntry, readBytes, totalBytes ->
                    val pct = if (totalBytes > 0L) ((readBytes.toFloat() / totalBytes.toFloat()) * 100).toInt().coerceIn(0, 100) else 0
                    _operationProgress.value = FileOperationProgress(
                        title = "Extracting ${item.name}",
                        currentFileName = curEntry,
                        bytesProcessed = readBytes,
                        totalBytes = totalBytes,
                        percentage = pct
                    )
                }
            )
            _operationProgress.value = null

            if (res.isSuccess) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(getApplication(), "Extracted to ${outDir.name}", Toast.LENGTH_SHORT).show()
                }
                refreshCurrentDirectory()
            } else {
                val ex = res.exceptionOrNull()
                withContext(Dispatchers.Main) {
                    Toast.makeText(getApplication(), "Extraction failed: ${ex?.message ?: "Unknown error"}", Toast.LENGTH_LONG).show()
                }
                if (ex is AndroidSecurityBlockedException) {
                    _securityBlockedPath.value = ex.blockedPath
                }
            }
        }
    }

    // Security Dialog dismiss
    fun dismissSecurityDialog() {
        _securityBlockedPath.value = null
    }

    // Terminal handling
    fun sendTerminalCommand(input: String) {
        viewModelScope.launch {
            val currentLines = _terminalLines.value.toMutableList()
            if (!_isWaitingForHelpPagination.value) {
                currentLines.add(TerminalLine("${terminalEngine.getPrompt(_settings.value)}$input", LineType.INPUT))
            }

            val resultLines = terminalEngine.processInput(input)
            _isWaitingForHelpPagination.value = terminalEngine.isWaitingForHelpPagination

            if (resultLines.any { it.text == "__CLEAR__" }) {
                _terminalLines.value = emptyList()
            } else {
                if (_isWaitingForHelpPagination.value && resultLines.isNotEmpty() && resultLines.first().text.contains("═")) {
                    val helpStartIndex = currentLines.indexOfLast { it.text.contains("ANDROID TOYBOX COMMANDS") }
                    if (helpStartIndex > 0) {
                        val sliceIndex = (helpStartIndex - 1).coerceAtLeast(0)
                        val trimmedLines = currentLines.take(sliceIndex).toMutableList()
                        trimmedLines.addAll(resultLines)
                        _terminalLines.value = trimmedLines
                    } else {
                        currentLines.addAll(resultLines)
                        _terminalLines.value = currentLines
                    }
                } else {
                    val singleTriggerLine = resultLines.find { it.text.startsWith("__TRIGGER_SINGLE_PERMISSION__:") }
                    val triggerPermissionsLine = resultLines.find { it.text.startsWith("__TRIGGER_PERMISSIONS__:") }

                    if (singleTriggerLine != null) {
                        val permKey = singleTriggerLine.text.substringAfter(":")
                        _requestSinglePermission.value = permKey
                    }
                    if (triggerPermissionsLine != null) {
                        val permissions = triggerPermissionsLine.text.substringAfter(":").split(",")
                        _requestUngrantedPermissions.value = permissions
                    }

                    // Remove all trigger lines from displayed output
                    val displayLines = resultLines.filterNot {
                        it.text.startsWith("__TRIGGER_SINGLE_PERMISSION__:") || it.text.startsWith("__TRIGGER_PERMISSIONS__:")
                    }
                    currentLines.addAll(displayLines)
                    _terminalLines.value = currentLines
                }
            }

            // Sync directory context if changed by cd command in terminal
            if (terminalEngine.currentDirectory != _currentDirectory.value) {
                _currentDirectory.value = terminalEngine.currentDirectory
                refreshCurrentDirectory()
            }
        }
    }

    fun clearTerminal() {
        _terminalLines.value = emptyList()
    }
}
