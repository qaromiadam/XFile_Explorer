package com.FileExplorer.XFileExplorer.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

fun createCustomDarkColorScheme(accentColor: Color = TechCyan) = darkColorScheme(
    primary = accentColor,
    onPrimary = TechBlack,
    primaryContainer = accentColor.copy(alpha = 0.2f),
    onPrimaryContainer = accentColor,
    secondary = TechBlue,
    onSecondary = Color.White,
    secondaryContainer = TechBlue.copy(alpha = 0.2f),
    onSecondaryContainer = Color.White,
    tertiary = TechViolet,
    onTertiary = Color.White,
    background = DarkBackground,
    onBackground = TextPrimaryDark,
    surface = DarkSurface,
    onSurface = TextPrimaryDark,
    surfaceVariant = DarkSurfaceBorder,
    onSurfaceVariant = TextSecondaryDark,
    outline = DarkSurfaceBorder,
    outlineVariant = DarkSurfaceElevated,
    error = TechRed,
    onError = Color.White
)

fun createCustomLightColorScheme(accentColor: Color = TechCyanDark) = lightColorScheme(
    primary = accentColor,
    onPrimary = Color.White,
    primaryContainer = accentColor.copy(alpha = 0.15f),
    onPrimaryContainer = TechBlack,
    secondary = TechBlue,
    onSecondary = Color.White,
    background = Color(0xFFF4F7FC),
    onBackground = Color(0xFF0F172A),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF0F172A),
    surfaceVariant = Color(0xFFE2E8F0),
    onSurfaceVariant = Color(0xFF475569),
    outline = Color(0xFFCBD5E1),
    error = TechRed,
    onError = Color.White
)

@Composable
fun XFileTheme(
    themeMode: com.FileExplorer.XFileExplorer.model.ThemeMode = com.FileExplorer.XFileExplorer.model.ThemeMode.DARK,
    accentColor: Color = TechCyan,
    content: @Composable () -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scheme = when (themeMode) {
        com.FileExplorer.XFileExplorer.model.ThemeMode.LIGHT -> createCustomLightColorScheme(accentColor)
        com.FileExplorer.XFileExplorer.model.ThemeMode.AMOLED -> createCustomDarkColorScheme(accentColor).copy(
            background = Color.Black,
            surface = Color(0xFF060608),
            surfaceVariant = Color(0xFF121216)
        )
        com.FileExplorer.XFileExplorer.model.ThemeMode.OLED_PITCH_BLACK -> createCustomDarkColorScheme(accentColor).copy(
            background = Color.Black,
            surface = Color.Black,
            surfaceVariant = Color(0xFF08080A),
            outline = Color(0xFF1E1E24)
        )
        com.FileExplorer.XFileExplorer.model.ThemeMode.MATERIAL_YOU -> {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
                androidx.compose.material3.dynamicDarkColorScheme(context)
            } else {
                createCustomDarkColorScheme(accentColor)
            }
        }
        com.FileExplorer.XFileExplorer.model.ThemeMode.DARK -> createCustomDarkColorScheme(accentColor)
    }

    MaterialTheme(
        colorScheme = scheme,
        typography = Typography,
        content = content
    )
}

@Composable
fun XFileTheme(
    darkTheme: Boolean = true,
    accentColor: Color = TechCyan,
    amoledMode: Boolean = false,
    content: @Composable () -> Unit
) {
    val mode = if (!darkTheme) com.FileExplorer.XFileExplorer.model.ThemeMode.LIGHT else if (amoledMode) com.FileExplorer.XFileExplorer.model.ThemeMode.AMOLED else com.FileExplorer.XFileExplorer.model.ThemeMode.DARK
    XFileTheme(themeMode = mode, accentColor = accentColor, content = content)
}

// For compatibility
@Composable
fun XFileExplorerTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    XFileTheme(darkTheme = darkTheme, content = content)
}
