package com.FileExplorer.XFileExplorer.data

import android.content.Context
import android.os.Environment
import com.FileExplorer.XFileExplorer.model.ArchiveEntryItem
import com.FileExplorer.XFileExplorer.model.FileItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.nio.charset.StandardCharsets
import java.util.zip.CRC32
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

class AndroidSecurityBlockedException(
    val blockedPath: String,
    override val message: String = EXACT_SECURITY_MESSAGE
) : SecurityException(message) {
    companion object {
        const val EXACT_SECURITY_MESSAGE =
            "This file is blocked by Android's security systems. To access it, unlock your bootloader and use another file app that allows this."
    }
}

class FileManager(val context: Context) {

    companion object {
        const val NAVIGATION_BOUNDARY_PATH = "/storage/emulated/0"

        fun isAtNavigationBoundary(file: File): Boolean {
            val path = file.absolutePath.trimEnd('/')
            val canonical = try { file.canonicalPath.trimEnd('/') } catch (_: Exception) { path }
            return path == NAVIGATION_BOUNDARY_PATH ||
                   path == "/sdcard" ||
                   canonical == NAVIGATION_BOUNDARY_PATH ||
                   path == "/" ||
                   path.isEmpty()
        }

        fun canNavigateUp(file: File): Boolean {
            if (isAtNavigationBoundary(file)) {
                return false
            }
            val path = file.absolutePath.trimEnd('/')
            val canonical = try { file.canonicalPath.trimEnd('/') } catch (_: Exception) { path }
            if (path == NAVIGATION_BOUNDARY_PATH || canonical == NAVIGATION_BOUNDARY_PATH || path == "/" || path.isEmpty()) {
                return false
            }
            val parent = file.parentFile ?: return false
            val parentPath = parent.absolutePath.trimEnd('/')
            val parentCanonical = try { parent.canonicalPath.trimEnd('/') } catch (_: Exception) { parentPath }
            if (parentPath == "/storage/emulated" || parentPath == "/storage" || parentPath == "/" || parentPath.isEmpty() ||
                parentCanonical == "/storage/emulated" || parentCanonical == "/storage" || parentCanonical == "/" || parentCanonical.isEmpty()) {
                return false
            }
            return true
        }

        fun checkExtensionChange(file: File, newName: String): Pair<String, String>? {
            if (file.isDirectory) return null
            val oldExt = file.extension.lowercase()
            val dot = newName.lastIndexOf('.')
            val newExt = if (dot != -1) newName.substring(dot + 1).lowercase() else ""
            return if (oldExt != newExt) Pair(oldExt, newExt) else null
        }

        fun isArchive(file: File): Boolean {
            val ext = file.extension.lowercase()
            return ext in listOf("zip", "7z", "tar", "gz", "tgz", "bz2", "rar")
        }

        val deviceModel: String
            get() = android.os.Build.MODEL.ifBlank { "Android Device" }

        fun getStorageLabel(settings: com.FileExplorer.XFileExplorer.model.AppSettings? = null): String {
            if (settings == null) return deviceModel
            return when (settings.storageLabelMode) {
                com.FileExplorer.XFileExplorer.model.StorageLabelMode.PHONE_MODEL -> deviceModel
                com.FileExplorer.XFileExplorer.model.StorageLabelMode.ZERO -> "0"
                com.FileExplorer.XFileExplorer.model.StorageLabelMode.CUSTOM -> settings.customStorageLabel.ifBlank { deviceModel }
            }
        }

        fun formatDisplayPath(path: String, settings: com.FileExplorer.XFileExplorer.model.AppSettings? = null): String {
            val label = getStorageLabel(settings)
            val trimmed = path.trimEnd('/')
            return when {
                trimmed == NAVIGATION_BOUNDARY_PATH || trimmed == "/sdcard" -> label
                trimmed.startsWith("$NAVIGATION_BOUNDARY_PATH/") -> label + trimmed.removePrefix(NAVIGATION_BOUNDARY_PATH)
                trimmed.startsWith("/storage/emulated/0/") -> label + trimmed.removePrefix("/storage/emulated/0")
                trimmed.isEmpty() || trimmed == "/" -> label
                else -> trimmed
            }
        }

        fun getDirectoryDisplayName(dir: File, settings: com.FileExplorer.XFileExplorer.model.AppSettings? = null): String {
            val label = getStorageLabel(settings)
            val path = dir.absolutePath.trimEnd('/')
            return if (path == NAVIGATION_BOUNDARY_PATH || path == "/sdcard" || dir.name == "0") {
                label
            } else if (path.isEmpty() || path == "/") {
                label
            } else {
                dir.name
            }
        }
    }

    val rootStorageDirectory: File
        get() {
            val primary = Environment.getExternalStorageDirectory()
            if (primary != null && primary.exists() && primary.canRead()) {
                return primary
            }
            return context.filesDir
        }

    fun getDeviceRoots(): List<File> {
        val roots = mutableListOf<File>()
        val primary = Environment.getExternalStorageDirectory()
        if (primary != null && primary.exists() && primary.canRead()) {
            roots.add(primary)
        }

        val downloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        if (downloads != null && downloads.exists() && downloads.canRead() && !roots.contains(downloads)) {
            roots.add(downloads)
        }

        val documents = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS)
        if (documents != null && documents.exists() && documents.canRead() && !roots.contains(documents)) {
            roots.add(documents)
        }

        val pictures = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
        if (pictures != null && pictures.exists() && pictures.canRead() && !roots.contains(pictures)) {
            roots.add(pictures)
        }

        return roots
            .filterNot {
                it.name.equals("files", ignoreCase = true) ||
                it.absolutePath.contains("/Android/data") ||
                it.absolutePath.contains("/Android/obb") ||
                it.absolutePath.endsWith("/files")
            }
            .distinctBy { it.absolutePath }
    }

    suspend fun listFiles(directory: File, showHidden: Boolean = true): Result<List<FileItem>> =
        withContext(Dispatchers.IO) {
            try {
                if (isSystemBlocked(directory) || !directory.canRead()) {
                    return@withContext Result.failure(AndroidSecurityBlockedException(directory.absolutePath))
                }

                if (!directory.exists()) {
                    return@withContext Result.failure(IOException("Directory does not exist: ${directory.absolutePath}"))
                }

                if (!directory.isDirectory) {
                    return@withContext Result.failure(IOException("Target is not a directory: ${directory.absolutePath}"))
                }

                val files = directory.listFiles() ?: emptyArray()

                val items = files
                    .filter { showHidden || !it.name.startsWith(".") }
                    .map { FileItem(it) }
                    .sortedWith(
                        compareBy<FileItem> { !it.isDirectory }
                            .thenBy { it.name.lowercase() }
                    )

                Result.success(items)
            } catch (se: SecurityException) {
                Result.failure(AndroidSecurityBlockedException(directory.absolutePath))
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    fun isSystemBlocked(file: File): Boolean {
        val path = file.absolutePath
        val blockedPrefixes = listOf(
            "/data/data",
            "/data/system",
            "/data/local",
            "/data/bootchart",
            "/data/misc",
            "/system/bin",
            "/sys/kernel",
            "/proc/kcore"
        )
        if (blockedPrefixes.any { path == it || path.startsWith("$it/") }) {
            return true
        }
        if (!file.canRead() && (path.startsWith("/data") || path.startsWith("/system") || path.startsWith("/vendor") || path.startsWith("/apex"))) {
            return true
        }
        return false
    }

    suspend fun createFolder(parentDir: File, name: String): Result<File> =
        withContext(Dispatchers.IO) {
            try {
                if (isSystemBlocked(parentDir) || !parentDir.canWrite()) {
                    throw AndroidSecurityBlockedException(parentDir.absolutePath)
                }
                val newFolder = File(parentDir, name)
                if (newFolder.exists()) {
                    return@withContext Result.failure(IOException("Folder already exists"))
                }
                val created = newFolder.mkdirs()
                if (created || newFolder.exists()) {
                    Result.success(newFolder)
                } else {
                    Result.failure(IOException("Failed to create folder: $name"))
                }
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun createFile(parentDir: File, name: String, content: String = ""): Result<File> =
        withContext(Dispatchers.IO) {
            try {
                if (isSystemBlocked(parentDir) || !parentDir.canWrite()) {
                    throw AndroidSecurityBlockedException(parentDir.absolutePath)
                }
                val newFile = File(parentDir, name)
                if (newFile.exists()) {
                    return@withContext Result.failure(IOException("File already exists"))
                }
                val created = newFile.createNewFile()
                if (created) {
                    if (name.endsWith(".pdf", ignoreCase = true)) {
                        createBlankPdf(newFile)
                    } else if (content.isNotEmpty()) {
                        newFile.writeText(content, StandardCharsets.UTF_8)
                    }
                    Result.success(newFile)
                } else {
                    Result.failure(IOException("Failed to create file: $name"))
                }
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    fun createBlankPdf(file: File) {
        val pdfDoc = android.graphics.pdf.PdfDocument()
        val pageInfo = android.graphics.pdf.PdfDocument.PageInfo.Builder(595, 842, 1).create() // Standard A4 (595 x 842 pt)
        val page = pdfDoc.startPage(pageInfo)
        val canvas = page.canvas
        val paint = android.graphics.Paint().apply {
            color = android.graphics.Color.WHITE
        }
        canvas.drawRect(0f, 0f, 595f, 842f, paint)
        pdfDoc.finishPage(page)
        java.io.FileOutputStream(file).use { fos ->
            pdfDoc.writeTo(fos)
        }
        pdfDoc.close()
    }

    suspend fun rename(file: File, newName: String): Result<File> =
        withContext(Dispatchers.IO) {
            try {
                if (isSystemBlocked(file) || !file.canWrite()) {
                    throw AndroidSecurityBlockedException(file.absolutePath)
                }
                val dest = File(file.parentFile, newName)
                if (dest.exists()) {
                    return@withContext Result.failure(IOException("Destination name already exists"))
                }
                val success = file.renameTo(dest)
                if (success) Result.success(dest) else Result.failure(IOException("Failed to rename file"))
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun delete(file: File): Result<Boolean> =
        withContext(Dispatchers.IO) {
            try {
                if (isSystemBlocked(file) || !file.canWrite()) {
                    throw AndroidSecurityBlockedException(file.absolutePath)
                }
                val success = file.deleteRecursively()
                if (success) Result.success(true) else Result.failure(IOException("Failed to delete ${file.name}"))
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun deleteMultiple(
        files: List<File>,
        onProgress: ((currentFileName: String, deletedCount: Int, totalCount: Int) -> Unit)? = null
    ): Result<Boolean> =
        withContext(Dispatchers.IO) {
            try {
                val total = files.size
                files.forEachIndexed { index, file ->
                    if (isSystemBlocked(file) || !file.canWrite()) {
                        throw AndroidSecurityBlockedException(file.absolutePath)
                    }
                    onProgress?.invoke(file.name, index + 1, total)
                    file.deleteRecursively()
                }
                Result.success(true)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun copy(source: File, destinationDir: File): Result<File> =
        withContext(Dispatchers.IO) {
            try {
                if (isSystemBlocked(source) || isSystemBlocked(destinationDir)) {
                    throw AndroidSecurityBlockedException(source.absolutePath)
                }
                val target = File(destinationDir, source.name)
                val finalTarget = if (target.exists()) {
                    File(destinationDir, generateUniqueCopyName(source.name, destinationDir))
                } else {
                    target
                }

                if (source.isDirectory) {
                    source.copyRecursively(finalTarget, overwrite = true)
                } else {
                    source.copyTo(finalTarget, overwrite = true)
                }
                Result.success(finalTarget)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun move(source: File, destinationDir: File): Result<File> =
        withContext(Dispatchers.IO) {
            try {
                if (isSystemBlocked(source) || isSystemBlocked(destinationDir)) {
                    throw AndroidSecurityBlockedException(source.absolutePath)
                }
                val target = File(destinationDir, source.name)
                val success = source.renameTo(target)
                if (success) {
                    Result.success(target)
                } else {
                    val copyResult = copy(source, destinationDir)
                    if (copyResult.isSuccess) {
                        source.deleteRecursively()
                        Result.success(copyResult.getOrThrow())
                    } else {
                        Result.failure(IOException("Failed to move file"))
                    }
                }
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    private fun generateUniqueCopyName(originalName: String, dir: File): String {
        val dotIndex = originalName.lastIndexOf('.')
        val base = if (dotIndex > 0) originalName.substring(0, dotIndex) else originalName
        val ext = if (dotIndex > 0) originalName.substring(dotIndex) else ""
        var count = 1
        var candidate = "$base (copy)$ext"
        while (File(dir, candidate).exists()) {
            count++
            candidate = "$base (copy $count)$ext"
        }
        return candidate
    }

    suspend fun compressToZip(
        items: List<File>,
        destinationZip: File,
        compressionLevel: Int = 60,
        onProgress: ((currentFile: String, writtenBytes: Long, totalBytes: Long) -> Unit)? = null
    ): Result<File> =
        withContext(Dispatchers.IO) {
            try {
                if (items.isEmpty()) {
                    return@withContext Result.failure(IllegalArgumentException("No files selected to compress"))
                }
                val totalBytes = items.sumOf {
                    if (it.isDirectory) com.FileExplorer.XFileExplorer.model.FileItem.calculateRecursiveSize(it) else it.length()
                }.coerceAtLeast(1L)

                destinationZip.parentFile?.mkdirs()
                if (destinationZip.exists()) {
                    destinationZip.delete()
                }

                val destCanonical = try { destinationZip.canonicalPath } catch (_: Exception) { destinationZip.absolutePath }
                var writtenBytes = 0L

                ZipOutputStream(BufferedOutputStream(FileOutputStream(destinationZip))).use { zos ->
                    val deflaterLevel = (compressionLevel * 9 / 100).coerceIn(0, 9)
                    zos.setLevel(deflaterLevel)
                    for (item in items) {
                        if (item.exists()) {
                            writtenBytes = addToZip(item, item.name, zos, destCanonical, writtenBytes, totalBytes, onProgress)
                        }
                    }
                }
                Result.success(destinationZip)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    private fun addToZip(
        file: File,
        entryName: String,
        zos: ZipOutputStream,
        destCanonicalPath: String,
        currentWritten: Long,
        totalBytes: Long,
        onProgress: ((currentFile: String, writtenBytes: Long, totalBytes: Long) -> Unit)?
    ): Long {
        var written = currentWritten
        val fileCanonical = try { file.canonicalPath } catch (_: Exception) { file.absolutePath }
        if (fileCanonical == destCanonicalPath) return written

        if (file.isDirectory) {
            val dirEntry = if (entryName.endsWith("/")) entryName else "$entryName/"
            try {
                zos.putNextEntry(ZipEntry(dirEntry))
                zos.closeEntry()
            } catch (_: Exception) {}
            onProgress?.invoke(file.name, written, totalBytes)
            file.listFiles()?.forEach { child ->
                if (child.exists()) {
                    written = addToZip(child, "$entryName/${child.name}", zos, destCanonicalPath, written, totalBytes, onProgress)
                }
            }
        } else {
            try {
                val entry = ZipEntry(entryName)
                entry.time = file.lastModified()
                zos.putNextEntry(entry)
                onProgress?.invoke(file.name, written, totalBytes)
                FileInputStream(file).use { fis ->
                    val buffer = ByteArray(8192)
                    var len: Int
                    while (fis.read(buffer).also { len = it } > 0) {
                        zos.write(buffer, 0, len)
                        written += len
                        onProgress?.invoke(file.name, written, totalBytes)
                    }
                }
                zos.closeEntry()
            } catch (_: Exception) {
                // Ignore transient unreadable file to allow remaining files to compress
            }
        }
        return written
    }

    private fun openArchiveInputStream(file: File): java.io.InputStream {
        val fis = FileInputStream(file)
        val bis = BufferedInputStream(fis)
        bis.mark(1024)
        val buffer = ByteArray(1024)
        val bytesRead = bis.read(buffer)
        bis.reset()
        if (bytesRead > 0) {
            // Check for standard ZIP signature PK\003\004 (0x50, 0x4B, 0x03, 0x04)
            for (i in 0 until bytesRead - 3) {
                if (buffer[i] == 0x50.toByte() &&
                    buffer[i + 1] == 0x4B.toByte() &&
                    buffer[i + 2] == 0x03.toByte() &&
                    buffer[i + 3] == 0x04.toByte()
                ) {
                    if (i > 0) {
                        bis.skip(i.toLong())
                    }
                    return bis
                }
            }
        }
        return bis
    }

    suspend fun extractZip(
        zipFile: File,
        outputDir: File,
        onProgress: ((currentEntry: String, readBytes: Long, totalBytes: Long) -> Unit)? = null
    ): Result<File> =
        withContext(Dispatchers.IO) {
            try {
                if (!outputDir.exists()) {
                    val created = outputDir.mkdirs()
                    if (!created && !outputDir.exists()) {
                        return@withContext Result.failure(IOException("Could not create output directory: ${outputDir.absolutePath}"))
                    }
                }
                val totalBytes = zipFile.length().coerceAtLeast(1L)
                var readBytes = 0L

                val inStream = openArchiveInputStream(zipFile)
                ZipInputStream(inStream).use { zis ->
                    var entry = zis.nextEntry
                    while (entry != null) {
                        val cleanName = entry.name.replace('\\', '/').trimStart('/')
                        if (cleanName.isNotEmpty()) {
                            onProgress?.invoke(cleanName, readBytes, totalBytes)
                            val outputFile = File(outputDir, cleanName)
                            val destCanonical = outputDir.canonicalPath.trimEnd(File.separatorChar) + File.separator
                            val outputCanonical = outputFile.canonicalPath
                            if (!outputCanonical.startsWith(destCanonical) && outputCanonical != outputDir.canonicalPath) {
                                throw SecurityException("Zip slip detected in entry: ${entry.name}")
                            }
                            if (entry.isDirectory || cleanName.endsWith('/')) {
                                outputFile.mkdirs()
                            } else {
                                outputFile.parentFile?.mkdirs()
                                FileOutputStream(outputFile).use { fos ->
                                    val buffer = ByteArray(8192)
                                    var count: Int
                                    while (zis.read(buffer).also { count = it } > 0) {
                                        fos.write(buffer, 0, count)
                                        readBytes += count
                                        onProgress?.invoke(cleanName, readBytes, totalBytes)
                                    }
                                }
                            }
                        }
                        zis.closeEntry()
                        entry = zis.nextEntry
                    }
                }
                Result.success(outputDir)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun listArchiveEntries(archiveFile: File): Result<List<ArchiveEntryItem>> =
        withContext(Dispatchers.IO) {
            try {
                val entries = mutableListOf<ArchiveEntryItem>()
                val inStream = openArchiveInputStream(archiveFile)
                ZipInputStream(inStream).use { zis ->
                    var entry = zis.nextEntry
                    while (entry != null) {
                        val cleanName = entry.name.replace('\\', '/').trimStart('/')
                        if (cleanName.isNotEmpty()) {
                            val fullPath = cleanName.trimEnd('/')
                            val slashIdx = fullPath.lastIndexOf('/')
                            val name = if (slashIdx != -1) fullPath.substring(slashIdx + 1) else fullPath
                            val parent = if (slashIdx != -1) fullPath.substring(0, slashIdx) else ""

                            entries.add(
                                ArchiveEntryItem(
                                    path = fullPath,
                                    name = name,
                                    isDirectory = entry.isDirectory || cleanName.endsWith('/'),
                                    size = if (entry.size >= 0) entry.size else 0L,
                                    compressedSize = if (entry.compressedSize >= 0) entry.compressedSize else 0L,
                                    lastModified = if (entry.time > 0) entry.time else archiveFile.lastModified(),
                                    parentPath = parent
                                )
                            )
                        }
                        zis.closeEntry()
                        entry = zis.nextEntry
                    }
                }
                Result.success(entries)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun extractArchive(
        archiveFile: File,
        outputDir: File,
        onProgress: ((currentEntry: String, readBytes: Long, totalBytes: Long) -> Unit)? = null
    ): Result<File> =
        withContext(Dispatchers.IO) {
            extractZip(archiveFile, outputDir, onProgress)
        }

    suspend fun readFileText(file: File, maxLines: Int = 2000): Result<String> =
        withContext(Dispatchers.IO) {
            try {
                if (isSystemBlocked(file)) {
                    throw AndroidSecurityBlockedException(file.absolutePath)
                }
                val sb = StringBuilder()
                var linesCount = 0
                file.bufferedReader(StandardCharsets.UTF_8).useLines { lines ->
                    for (line in lines) {
                        if (linesCount >= maxLines) {
                            sb.append("\n... [Truncated at $maxLines lines]")
                            break
                        }
                        sb.append(line).append("\n")
                        linesCount++
                    }
                }
                Result.success(sb.toString())
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun writeFileText(file: File, content: String): Result<Unit> =
        withContext(Dispatchers.IO) {
            try {
                if (isArchive(file)) {
                    return@withContext Result.failure(
                        IllegalStateException("Archives (.zip) cannot be directly edited. Extract the archive first.")
                    )
                }
                if (isSystemBlocked(file)) {
                    throw AndroidSecurityBlockedException(file.absolutePath)
                }
                file.writeText(content, StandardCharsets.UTF_8)
                Result.success(Unit)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
}
