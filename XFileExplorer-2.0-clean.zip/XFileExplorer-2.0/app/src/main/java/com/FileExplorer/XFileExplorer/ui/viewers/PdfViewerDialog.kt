package com.FileExplorer.XFileExplorer.ui.viewers

import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Brush
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.FitScreen
import androidx.compose.material.icons.filled.PanTool
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Size
import coil.compose.AsyncImage
import androidx.compose.material.icons.filled.Create
import androidx.compose.material.icons.filled.CropSquare
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FormatColorText
import androidx.compose.material.icons.filled.FormatUnderlined
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Highlight
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Note
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.StrikethroughS
import androidx.compose.material.icons.filled.ViewDay
import androidx.compose.material.icons.filled.ViewStream
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material.icons.filled.ZoomOut
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.FileExplorer.XFileExplorer.data.PdfSuiteEngine
import com.FileExplorer.XFileExplorer.model.FileItem
import com.FileExplorer.XFileExplorer.model.PageAnnotationData
import com.FileExplorer.XFileExplorer.model.PdfEditTool
import com.FileExplorer.XFileExplorer.model.PdfInkStroke
import com.FileExplorer.XFileExplorer.model.PdfScrollLayout
import com.FileExplorer.XFileExplorer.model.PdfShapeAnnotation
import com.FileExplorer.XFileExplorer.model.PdfStickyNote
import com.FileExplorer.XFileExplorer.model.PdfTextAnnotation
import com.FileExplorer.XFileExplorer.model.PdfViewMode
import com.FileExplorer.XFileExplorer.model.PdfWatermarkConfig
import com.FileExplorer.XFileExplorer.ui.theme.DarkSurface
import com.FileExplorer.XFileExplorer.ui.theme.DarkSurfaceBorder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

@Composable
fun PdfViewerDialog(
    item: FileItem,
    accent: Color,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    // Mode state: Opens in READING mode by default
    var viewMode by remember { mutableStateOf(PdfViewMode.READING) }
    var scrollLayout by remember { mutableStateOf(PdfScrollLayout.HORIZONTAL_PAGER) }

    // Core renderer state
    var pfd by remember { mutableStateOf<ParcelFileDescriptor?>(null) }
    var renderer by remember { mutableStateOf<PdfRenderer?>(null) }
    var pageCount by remember { mutableIntStateOf(0) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var zoomScale by remember { mutableFloatStateOf(1f) }
    var panOffset by remember { mutableStateOf(Offset.Zero) }
    var annotationVersion by remember { mutableIntStateOf(0) }
    var reloadTrigger by remember { mutableIntStateOf(0) }

    // Active page and rendering
    val pagerState = rememberPagerState(initialPage = 0, pageCount = { pageCount.coerceAtLeast(1) })
    val verticalListState = rememberLazyListState()
    val activePageIndex = if (scrollLayout == PdfScrollLayout.HORIZONTAL_PAGER) pagerState.currentPage else verticalListState.firstVisibleItemIndex

    // Page bitmap cache
    val pageBitmaps = remember { mutableStateMapOf<Int, Bitmap>() }

    // Search tools
    var isSearchVisible by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var searchMatchPages by remember { mutableStateOf<List<Int>>(emptyList()) }
    var currentMatchIndex by remember { mutableIntStateOf(0) }
    var isSearching by remember { mutableStateOf(false) }

    // Thumbnail drawer
    var isThumbnailDrawerOpen by remember { mutableStateOf(false) }

    // Editing & Annotations state
    var activeTool by remember { mutableStateOf(PdfEditTool.NONE) }
    var activeColor by remember { mutableStateOf(Color(0xFFFFDD00)) }
    var activeStrokeWidth by remember { mutableFloatStateOf(6f) }
    var activeOpacity by remember { mutableFloatStateOf(1f) }
    var watermarkConfig by remember { mutableStateOf<PdfWatermarkConfig?>(null) }

    // Page-specific annotations map
    val pageAnnotations = remember { mutableStateMapOf<Int, PageAnnotationData>() }
    val deletedPageIndices = remember { mutableSetOf<Int>() }
    var blankPagesAddedCount by remember { mutableIntStateOf(0) }

    // Dialog state
    var showSaveConfirmDialog by remember { mutableStateOf(false) }
    var showAddTextDialog by remember { mutableStateOf(false) }
    var textToAdd by remember { mutableStateOf("") }
    var isTextBold by remember { mutableStateOf(false) }
    var isTextItalic by remember { mutableStateOf(false) }
    var textFontSize by remember { mutableFloatStateOf(18f) }
    var pendingTextPosition by remember { mutableStateOf(Offset(50f, 100f)) }

    var showStickyNoteDialog by remember { mutableStateOf(false) }
    var stickyNoteText by remember { mutableStateOf("") }
    var pendingNotePosition by remember { mutableStateOf(Offset(60f, 120f)) }

    var showWatermarkDialog by remember { mutableStateOf(false) }
    var watermarkInputText by remember { mutableStateOf("CONFIDENTIAL") }

    // State for editing existing placed annotations
    var editingTextItem by remember { mutableStateOf<PdfTextAnnotation?>(null) }
    var editTextString by remember { mutableStateOf("") }
    var editingStickyNote by remember { mutableStateOf<PdfStickyNote?>(null) }
    var editNoteString by remember { mutableStateOf("") }

    // Temporary active in-progress drawing points
    var currentDrawPoints by remember { mutableStateOf<List<Offset>>(emptyList()) }
    var shapeStartOffset by remember { mutableStateOf<Offset?>(null) }
    var shapeCurrentOffset by remember { mutableStateOf<Offset?>(null) }

    // Image picker launcher for PDF insertion
    val imagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            val pageData = pageAnnotations.getOrPut(activePageIndex) { PageAnnotationData(activePageIndex) }
            val imgAnnot = com.FileExplorer.XFileExplorer.model.PdfImageAnnotation(
                imageUri = uri.toString(),
                position = Offset(80f, 150f)
            )
            pageData.insertedImages.add(imgAnnot)
            annotationVersion++
            Toast.makeText(context, "Image placed on page ${activePageIndex + 1}", Toast.LENGTH_SHORT).show()
        }
    }

    // Initialize PdfBox engine
    LaunchedEffect(Unit) {
        PdfSuiteEngine.ensureInitialized(context)
    }

    // Open PDF with PdfRenderer
    DisposableEffect(item.path, reloadTrigger) {
        val file = item.file
        try {
            if (file.exists() && file.canRead()) {
                val descriptor = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
                pfd = descriptor
                val pdfRenderer = PdfRenderer(descriptor)
                renderer = pdfRenderer
                pageCount = pdfRenderer.pageCount
            } else {
                errorMessage = "Cannot access PDF file: file is not readable"
            }
        } catch (e: Exception) {
            errorMessage = "Failed to load PDF: ${e.message ?: "Invalid or encrypted format"}"
        }

        onDispose {
            pageBitmaps.values.forEach { if (!it.isRecycled) it.recycle() }
            pageBitmaps.clear()
            try {
                renderer?.close()
                pfd?.close()
            } catch (_: Exception) {}
        }
    }

    // Helper to render high-res page
    fun renderPageBitmap(pageIdx: Int): Bitmap? {
        val existing = pageBitmaps[pageIdx]
        if (existing != null && !existing.isRecycled) return existing
        val pdf = renderer ?: return null
        return try {
            synchronized(pdf) {
                if (pageIdx in 0 until pdf.pageCount) {
                    val page = pdf.openPage(pageIdx)
                    val width = (page.width * 1.5f).toInt().coerceAtLeast(300)
                    val height = (page.height * 1.5f).toInt().coerceAtLeast(400)
                    val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                    bmp.eraseColor(android.graphics.Color.WHITE)
                    page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    page.close()
                    pageBitmaps[pageIdx] = bmp
                    bmp
                } else null
            }
        } catch (_: Exception) {
            null
        }
    }

    Dialog(
        onDismissRequest = {
            if (viewMode == PdfViewMode.EDITOR) {
                viewMode = PdfViewMode.READING
            } else {
                onDismiss()
            }
        },
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            decorFitsSystemWindows = false
        )
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .safeDrawingPadding()
                .padding(horizontal = 8.dp, vertical = 6.dp)
                .testTag("pdf_suite_dialog"),
            shape = RoundedCornerShape(16.dp),
            color = DarkSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // ==========================================
                // TOP NAVIGATION BAR
                // ==========================================
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = Color(0xFF0C1220),
                    border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        // Document Name & Page Counter
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFFE53935).copy(alpha = 0.2f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PictureAsPdf,
                                    contentDescription = null,
                                    tint = Color(0xFFEF5350),
                                    modifier = Modifier.size(18.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(10.dp))

                            Column {
                                Text(
                                    text = item.name.removeSuffix(".pdf").removeSuffix(".PDF"),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = Color.White,
                                    maxLines = 1
                                )
                                Text(
                                    text = if (pageCount > 0) "Page ${activePageIndex + 1} of $pageCount" else item.formattedSize,
                                    fontSize = 10.sp,
                                    color = Color(0xFF90A4CE)
                                )
                            }
                        }

                        // Top right actions: Thumbnail grid toggle and Close (X)
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            // Thumbnail Drawer Toggle
                            IconButton(
                                onClick = { isThumbnailDrawerOpen = !isThumbnailDrawerOpen },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.GridView,
                                    contentDescription = "Page Thumbnails",
                                    tint = if (isThumbnailDrawerOpen) accent else Color.White
                                )
                            }

                            // "X" exit button back to file list
                            IconButton(
                                onClick = onDismiss,
                                modifier = Modifier
                                    .size(36.dp)
                                    .testTag("pdf_close_btn")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Close PDF",
                                    tint = Color.White
                                )
                            }
                        }
                    }
                }



                // ==========================================
                // MAIN PDF VIEWPORT & INTERACTIVE CANVAS
                // ==========================================
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .background(Color(0xFF080D18))
                        .clipToBounds(),
                    contentAlignment = Alignment.Center
                ) {
                    if (errorMessage != null) {
                        Text(text = errorMessage!!, color = Color(0xFFEF5350), fontSize = 13.sp, modifier = Modifier.padding(24.dp))
                    } else if (pageCount == 0 || renderer == null) {
                        CircularProgressIndicator(color = accent, modifier = Modifier.size(36.dp))
                    } else {
                        // Display PDF either via HorizontalPager or Vertical LazyColumn
                        if (scrollLayout == PdfScrollLayout.HORIZONTAL_PAGER) {
                            HorizontalPager(
                                state = pagerState,
                                modifier = Modifier.fillMaxSize()
                            ) { pageIdx ->
                                PdfPageWithOverlay(
                                    pageIndex = pageIdx,
                                    renderPage = { renderPageBitmap(pageIdx) },
                                    zoomScale = zoomScale,
                                    panOffset = panOffset,
                                    onPanDelta = { pan -> panOffset = panOffset + pan },
                                    onZoomDelta = { zoom ->
                                        val newZ = (zoomScale * zoom).coerceIn(0.75f, 4.5f)
                                        zoomScale = newZ
                                        if (newZ <= 1f) panOffset = Offset.Zero
                                    },
                                    isEditorMode = viewMode == PdfViewMode.EDITOR,
                                    activeTool = activeTool,
                                    activeColor = activeColor,
                                    activeStrokeWidth = activeStrokeWidth,
                                    pageAnnotations = pageAnnotations,
                                    annotationVersion = annotationVersion,
                                    currentDrawPoints = currentDrawPoints,
                                    onUpdateDrawPoints = { currentDrawPoints = it },
                                    onFinishStroke = { stroke ->
                                        val pData = pageAnnotations.getOrPut(pageIdx) { PageAnnotationData(pageIdx) }
                                        pData.inkStrokes.add(stroke)
                                        currentDrawPoints = emptyList()
                                        annotationVersion++
                                    },
                                    onFinishShape = { shape ->
                                        val pData = pageAnnotations.getOrPut(pageIdx) { PageAnnotationData(pageIdx) }
                                        pData.shapes.add(shape)
                                        annotationVersion++
                                    },
                                    onMoveTextAnnotation = { textId, delta ->
                                        val pData = pageAnnotations[pageIdx]
                                        if (pData != null) {
                                            val idx = pData.textAnnotations.indexOfFirst { it.id == textId }
                                            if (idx != -1) {
                                                val old = pData.textAnnotations[idx]
                                                pData.textAnnotations[idx] = old.copy(position = old.position + delta)
                                                annotationVersion++
                                            }
                                        }
                                    },
                                    onResizeText = { textId, delta ->
                                        val pData = pageAnnotations[pageIdx]
                                        if (pData != null) {
                                            val idx = pData.textAnnotations.indexOfFirst { it.id == textId }
                                            if (idx != -1) {
                                                val old = pData.textAnnotations[idx]
                                                pData.textAnnotations[idx] = old.copy(fontSize = (old.fontSize + delta).coerceIn(10f, 60f))
                                                annotationVersion++
                                            }
                                        }
                                    },
                                    onEditText = { textId ->
                                        val pData = pageAnnotations[pageIdx]
                                        val item = pData?.textAnnotations?.firstOrNull { it.id == textId }
                                        if (item != null) {
                                            editingTextItem = item
                                            editTextString = item.text
                                        }
                                    },
                                    onDeleteTextAnnotation = { textId ->
                                        val pData = pageAnnotations[pageIdx]
                                        pData?.textAnnotations?.removeAll { it.id == textId }
                                        annotationVersion++
                                    },
                                    onMoveStickyNote = { noteId, delta ->
                                        val pData = pageAnnotations[pageIdx]
                                        if (pData != null) {
                                            val idx = pData.stickyNotes.indexOfFirst { it.id == noteId }
                                            if (idx != -1) {
                                                val old = pData.stickyNotes[idx]
                                                pData.stickyNotes[idx] = old.copy(position = old.position + delta)
                                                annotationVersion++
                                            }
                                        }
                                    },
                                    onEditStickyNote = { noteId ->
                                        val pData = pageAnnotations[pageIdx]
                                        val note = pData?.stickyNotes?.firstOrNull { it.id == noteId }
                                        if (note != null) {
                                            editingStickyNote = note
                                            editNoteString = note.text
                                        }
                                    },
                                    onDeleteStickyNote = { noteId ->
                                        val pData = pageAnnotations[pageIdx]
                                        pData?.stickyNotes?.removeAll { it.id == noteId }
                                        annotationVersion++
                                    },
                                    onMoveImage = { imgId, delta ->
                                        val pData = pageAnnotations[pageIdx]
                                        if (pData != null) {
                                            val idx = pData.insertedImages.indexOfFirst { it.id == imgId }
                                            if (idx != -1) {
                                                val old = pData.insertedImages[idx]
                                                pData.insertedImages[idx] = old.copy(position = old.position + delta)
                                                annotationVersion++
                                            }
                                        }
                                    },
                                    onResizeImage = { imgId, delta ->
                                        val pData = pageAnnotations[pageIdx]
                                        if (pData != null) {
                                            val idx = pData.insertedImages.indexOfFirst { it.id == imgId }
                                            if (idx != -1) {
                                                val old = pData.insertedImages[idx]
                                                pData.insertedImages[idx] = old.copy(
                                                    width = (old.width + delta).coerceIn(60f, 600f),
                                                    height = (old.height + delta).coerceIn(60f, 600f)
                                                )
                                                annotationVersion++
                                            }
                                        }
                                    },
                                    onSetImageSize = { imgId, newSize ->
                                        val pData = pageAnnotations[pageIdx]
                                        if (pData != null) {
                                            val idx = pData.insertedImages.indexOfFirst { it.id == imgId }
                                            if (idx != -1) {
                                                val old = pData.insertedImages[idx]
                                                pData.insertedImages[idx] = old.copy(width = newSize, height = newSize)
                                                annotationVersion++
                                            }
                                        }
                                    },
                                    onResizeImageCorner = { imgId, dragAmount ->
                                        val pData = pageAnnotations[pageIdx]
                                        if (pData != null) {
                                            val idx = pData.insertedImages.indexOfFirst { it.id == imgId }
                                            if (idx != -1) {
                                                val old = pData.insertedImages[idx]
                                                pData.insertedImages[idx] = old.copy(
                                                    width = (old.width + dragAmount.x).coerceIn(60f, 700f),
                                                    height = (old.height + dragAmount.y).coerceIn(60f, 700f)
                                                )
                                                annotationVersion++
                                            }
                                        }
                                    },
                                    onDeleteImage = { imgId ->
                                        val pData = pageAnnotations[pageIdx]
                                        pData?.insertedImages?.removeAll { it.id == imgId }
                                        annotationVersion++
                                    },
                                    onTapLocation = { tapOffset ->
                                        if (activeTool == PdfEditTool.ADD_TEXT) {
                                            pendingTextPosition = tapOffset
                                            showAddTextDialog = true
                                        } else if (activeTool == PdfEditTool.STICKY_NOTE) {
                                            pendingNotePosition = tapOffset
                                            showStickyNoteDialog = true
                                        }
                                    },
                                    watermarkConfig = watermarkConfig
                                )
                            }
                        } else {
                            // Continuous vertical scroll layout
                            LazyColumn(
                                state = verticalListState,
                                modifier = Modifier.fillMaxSize(),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                items(pageCount) { pageIdx ->
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(550.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        PdfPageWithOverlay(
                                            pageIndex = pageIdx,
                                            renderPage = { renderPageBitmap(pageIdx) },
                                            zoomScale = zoomScale,
                                            panOffset = panOffset,
                                            onPanDelta = { pan -> panOffset = panOffset + pan },
                                            onZoomDelta = { zoom ->
                                                val newZ = (zoomScale * zoom).coerceIn(0.75f, 4.5f)
                                                zoomScale = newZ
                                                if (newZ <= 1f) panOffset = Offset.Zero
                                            },
                                            isEditorMode = viewMode == PdfViewMode.EDITOR,
                                            activeTool = activeTool,
                                            activeColor = activeColor,
                                            activeStrokeWidth = activeStrokeWidth,
                                            pageAnnotations = pageAnnotations,
                                            annotationVersion = annotationVersion,
                                            currentDrawPoints = currentDrawPoints,
                                            onUpdateDrawPoints = { currentDrawPoints = it },
                                            onFinishStroke = { stroke ->
                                                val pData = pageAnnotations.getOrPut(pageIdx) { PageAnnotationData(pageIdx) }
                                                pData.inkStrokes.add(stroke)
                                                currentDrawPoints = emptyList()
                                                annotationVersion++
                                            },
                                            onFinishShape = { shape ->
                                                val pData = pageAnnotations.getOrPut(pageIdx) { PageAnnotationData(pageIdx) }
                                                pData.shapes.add(shape)
                                                annotationVersion++
                                            },
                                            onMoveTextAnnotation = { textId, delta ->
                                                val pData = pageAnnotations[pageIdx]
                                                if (pData != null) {
                                                    val idx = pData.textAnnotations.indexOfFirst { it.id == textId }
                                                    if (idx != -1) {
                                                        val old = pData.textAnnotations[idx]
                                                        pData.textAnnotations[idx] = old.copy(position = old.position + delta)
                                                        annotationVersion++
                                                    }
                                                }
                                            },
                                            onResizeText = { textId, delta ->
                                                val pData = pageAnnotations[pageIdx]
                                                if (pData != null) {
                                                    val idx = pData.textAnnotations.indexOfFirst { it.id == textId }
                                                    if (idx != -1) {
                                                        val old = pData.textAnnotations[idx]
                                                        pData.textAnnotations[idx] = old.copy(fontSize = (old.fontSize + delta).coerceIn(10f, 60f))
                                                        annotationVersion++
                                                    }
                                                }
                                            },
                                            onEditText = { textId ->
                                                val pData = pageAnnotations[pageIdx]
                                                val item = pData?.textAnnotations?.firstOrNull { it.id == textId }
                                                if (item != null) {
                                                    editingTextItem = item
                                                    editTextString = item.text
                                                }
                                            },
                                            onDeleteTextAnnotation = { textId ->
                                                val pData = pageAnnotations[pageIdx]
                                                pData?.textAnnotations?.removeAll { it.id == textId }
                                                annotationVersion++
                                            },
                                            onMoveStickyNote = { noteId, delta ->
                                                val pData = pageAnnotations[pageIdx]
                                                if (pData != null) {
                                                    val idx = pData.stickyNotes.indexOfFirst { it.id == noteId }
                                                    if (idx != -1) {
                                                        val old = pData.stickyNotes[idx]
                                                        pData.stickyNotes[idx] = old.copy(position = old.position + delta)
                                                        annotationVersion++
                                                    }
                                                }
                                            },
                                            onEditStickyNote = { noteId ->
                                                val pData = pageAnnotations[pageIdx]
                                                val note = pData?.stickyNotes?.firstOrNull { it.id == noteId }
                                                if (note != null) {
                                                    editingStickyNote = note
                                                    editNoteString = note.text
                                                }
                                            },
                                            onDeleteStickyNote = { noteId ->
                                                val pData = pageAnnotations[pageIdx]
                                                pData?.stickyNotes?.removeAll { it.id == noteId }
                                                annotationVersion++
                                            },
                                            onMoveImage = { imgId, delta ->
                                                val pData = pageAnnotations[pageIdx]
                                                if (pData != null) {
                                                    val idx = pData.insertedImages.indexOfFirst { it.id == imgId }
                                                    if (idx != -1) {
                                                        val old = pData.insertedImages[idx]
                                                        pData.insertedImages[idx] = old.copy(position = old.position + delta)
                                                        annotationVersion++
                                                    }
                                                }
                                            },
                                            onResizeImage = { imgId, delta ->
                                                val pData = pageAnnotations[pageIdx]
                                                if (pData != null) {
                                                    val idx = pData.insertedImages.indexOfFirst { it.id == imgId }
                                                    if (idx != -1) {
                                                        val old = pData.insertedImages[idx]
                                                        pData.insertedImages[idx] = old.copy(
                                                            width = (old.width + delta).coerceIn(60f, 600f),
                                                            height = (old.height + delta).coerceIn(60f, 600f)
                                                        )
                                                        annotationVersion++
                                                    }
                                                }
                                            },
                                            onSetImageSize = { imgId, newSize ->
                                                val pData = pageAnnotations[pageIdx]
                                                if (pData != null) {
                                                    val idx = pData.insertedImages.indexOfFirst { it.id == imgId }
                                                    if (idx != -1) {
                                                        val old = pData.insertedImages[idx]
                                                        pData.insertedImages[idx] = old.copy(width = newSize, height = newSize)
                                                        annotationVersion++
                                                    }
                                                }
                                            },
                                            onResizeImageCorner = { imgId, dragAmount ->
                                                val pData = pageAnnotations[pageIdx]
                                                if (pData != null) {
                                                    val idx = pData.insertedImages.indexOfFirst { it.id == imgId }
                                                    if (idx != -1) {
                                                        val old = pData.insertedImages[idx]
                                                        pData.insertedImages[idx] = old.copy(
                                                            width = (old.width + dragAmount.x).coerceIn(60f, 700f),
                                                            height = (old.height + dragAmount.y).coerceIn(60f, 700f)
                                                        )
                                                        annotationVersion++
                                                    }
                                                }
                                            },
                                            onDeleteImage = { imgId ->
                                                val pData = pageAnnotations[pageIdx]
                                                pData?.insertedImages?.removeAll { it.id == imgId }
                                                annotationVersion++
                                            },
                                            onTapLocation = { tapOffset ->
                                                if (activeTool == PdfEditTool.ADD_TEXT) {
                                                    pendingTextPosition = tapOffset
                                                    showAddTextDialog = true
                                                } else if (activeTool == PdfEditTool.STICKY_NOTE) {
                                                    pendingNotePosition = tapOffset
                                                    showStickyNoteDialog = true
                                                }
                                            },
                                            watermarkConfig = watermarkConfig
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Floating On-Screen Zoom & Pan HUD (Guaranteed visible at TopEnd)
                    Surface(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(top = 10.dp, end = 10.dp)
                            .clip(RoundedCornerShape(20.dp))
                            .border(1.dp, Color(0xFF223048), RoundedCornerShape(20.dp)),
                        color = Color(0xF00A101D),
                        shadowElevation = 8.dp
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                        ) {
                            IconButton(
                                onClick = {
                                    val newScale = (zoomScale - 0.25f).coerceAtLeast(0.5f)
                                    zoomScale = newScale
                                },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(Icons.Default.ZoomOut, contentDescription = "Zoom Out", tint = Color.White, modifier = Modifier.size(16.dp))
                            }

                            TextButton(
                                onClick = {
                                    zoomScale = 1f
                                    panOffset = Offset.Zero
                                },
                                modifier = Modifier.height(32.dp),
                                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 4.dp)
                            ) {
                                Text(
                                    text = "${(zoomScale * 100).toInt()}%",
                                    color = accent,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            IconButton(
                                onClick = {
                                    val newScale = (zoomScale + 0.25f).coerceAtMost(5f)
                                    zoomScale = newScale
                                },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(Icons.Default.ZoomIn, contentDescription = "Zoom In", tint = Color.White, modifier = Modifier.size(16.dp))
                            }

                            IconButton(
                                onClick = {
                                    zoomScale = 1f
                                    panOffset = Offset.Zero
                                },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(Icons.Default.FitScreen, contentDescription = "Reset Zoom & Pan", tint = Color(0xFF90A4CE), modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }

                // ==========================================
                // BOTTOM THUMBNAIL DRAWER (Drawer / Strip)
                // ==========================================
                AnimatedVisibility(visible = isThumbnailDrawerOpen) {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        color = Color(0xFF0A0F1D),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E2D48))
                    ) {
                        Column(modifier = Modifier.padding(8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "PAGE THUMBNAILS ($pageCount pages)",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF90A4CE)
                                )
                                IconButton(
                                    onClick = { isThumbnailDrawerOpen = false },
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.Close, contentDescription = "Close Thumbnails", tint = Color.Gray, modifier = Modifier.size(16.dp))
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            LazyRow(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                items(pageCount) { idx ->
                                    val isSelected = activePageIndex == idx
                                    Column(
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(if (isSelected) accent.copy(alpha = 0.2f) else Color(0xFF141F33))
                                            .border(if (isSelected) 2.dp else 1.dp, if (isSelected) accent else Color(0xFF223048), RoundedCornerShape(8.dp))
                                            .clickable {
                                                coroutineScope.launch {
                                                    if (scrollLayout == PdfScrollLayout.HORIZONTAL_PAGER) pagerState.scrollToPage(idx) else verticalListState.scrollToItem(idx)
                                                }
                                            }
                                            .padding(6.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(width = 54.dp, height = 72.dp)
                                                .background(Color.White),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            val thumb = pageBitmaps[idx]
                                            if (thumb != null) {
                                                Image(
                                                    bitmap = thumb.asImageBitmap(),
                                                    contentDescription = null,
                                                    modifier = Modifier.fillMaxSize()
                                                )
                                            } else {
                                                Text("${idx + 1}", color = Color.Black, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = "p. ${idx + 1}",
                                            fontSize = 10.sp,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                            color = if (isSelected) accent else Color(0xFF90A4CE)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }


            }
        }
    }

    // ==========================================
    // SAVE CONFIRMATION DIALOG (In-Place vs Save As)
    // ==========================================
    if (showSaveConfirmDialog) {
        var isSaving by remember { mutableStateOf(false) }
        var newFileName by remember { mutableStateOf("${item.file.nameWithoutExtension}_edited.pdf") }
        var saveOption by remember { mutableStateOf("overwrite") } // "overwrite" or "new_file"

        AlertDialog(
            onDismissRequest = { if (!isSaving) showSaveConfirmDialog = false },
            title = { Text("Save Document Changes", fontWeight = FontWeight.Bold, color = Color.White) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Choose how you would like to save your edits, annotations, and page modifications:",
                        fontSize = 13.sp,
                        color = Color(0xFFD6E2F5)
                    )

                    // Option 1: Overwrite original file
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (saveOption == "overwrite") accent.copy(alpha = 0.15f) else Color(0xFF141F33))
                            .border(1.dp, if (saveOption == "overwrite") accent else Color(0xFF223048), RoundedCornerShape(8.dp))
                            .clickable { saveOption = "overwrite" }
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "a) Overwrite original file (In-place)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = if (saveOption == "overwrite") accent else Color.White
                        )
                    }

                    // Option 2: Save as a new file
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (saveOption == "new_file") accent.copy(alpha = 0.15f) else Color(0xFF141F33))
                            .border(1.dp, if (saveOption == "new_file") accent else Color(0xFF223048), RoundedCornerShape(8.dp))
                            .clickable { saveOption = "new_file" }
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "b) Save as a new file",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = if (saveOption == "new_file") accent else Color.White
                        )
                    }

                    if (saveOption == "new_file") {
                        OutlinedTextField(
                            value = newFileName,
                            onValueChange = { newFileName = it },
                            label = { Text("New file name", fontSize = 11.sp) },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = accent,
                                unfocusedBorderColor = Color(0xFF223048),
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    if (isSaving) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(color = accent, modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Writing changes to PDF...", fontSize = 12.sp, color = accent)
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        isSaving = true
                        coroutineScope.launch {
                            val inPlace = saveOption == "overwrite"
                            val targetFile = if (inPlace) item.file else File(item.file.parentFile, newFileName.trim())
                            val result = PdfSuiteEngine.saveDocument(
                                context = context,
                                originalFile = item.file,
                                targetFile = targetFile,
                                inPlace = inPlace,
                                pageAnnotations = pageAnnotations,
                                watermarkConfig = watermarkConfig,
                                deletedPageIndices = deletedPageIndices,
                                blankPagesAdded = blankPagesAddedCount
                            )
                            isSaving = false
                            showSaveConfirmDialog = false
                            if (result.isSuccess) {
                                val savedFile = result.getOrNull()!!
                                Toast.makeText(context, "Successfully saved: ${savedFile.name}", Toast.LENGTH_SHORT).show()
                                pageBitmaps.values.forEach { if (!it.isRecycled) it.recycle() }
                                pageBitmaps.clear()
                                reloadTrigger++
                                annotationVersion++
                            } else {
                                Toast.makeText(context, "Save failed: ${result.exceptionOrNull()?.message}", Toast.LENGTH_LONG).show()
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = accent),
                    enabled = !isSaving
                ) {
                    Text("Confirm Save", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showSaveConfirmDialog = false }, enabled = !isSaving) {
                    Text("Cancel", color = Color(0xFF90A4CE))
                }
            },
            containerColor = DarkSurface,
            shape = RoundedCornerShape(14.dp)
        )
    }

    // ==========================================
    // TEXT INSERTION DIALOG
    // ==========================================
    if (showAddTextDialog) {
        AlertDialog(
            onDismissRequest = { showAddTextDialog = false },
            title = { Text("Insert Text Annotation", color = Color.White, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = textToAdd,
                        onValueChange = { textToAdd = it },
                        placeholder = { Text("Enter text to place...", fontSize = 12.sp) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = accent,
                            unfocusedBorderColor = Color(0xFF223048),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            TextButton(onClick = { isTextBold = !isTextBold }) {
                                Text("Bold", fontWeight = if (isTextBold) FontWeight.Bold else FontWeight.Normal, color = if (isTextBold) accent else Color.Gray)
                            }
                            TextButton(onClick = { isTextItalic = !isTextItalic }) {
                                Text("Italic", color = if (isTextItalic) accent else Color.Gray)
                            }
                        }
                        Text("Size: ${textFontSize.toInt()}sp", fontSize = 11.sp, color = Color.White)
                    }
                    Slider(
                        value = textFontSize,
                        onValueChange = { textFontSize = it },
                        valueRange = 12f..36f,
                        colors = SliderDefaults.colors(thumbColor = accent, activeTrackColor = accent)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (textToAdd.isNotBlank()) {
                            val pData = pageAnnotations.getOrPut(activePageIndex) { PageAnnotationData(activePageIndex) }
                            pData.textAnnotations.add(
                                PdfTextAnnotation(
                                    text = textToAdd.trim(),
                                    position = pendingTextPosition,
                                    fontSize = textFontSize,
                                    color = activeColor,
                                    isBold = isTextBold,
                                    isItalic = isTextItalic
                                )
                            )
                            textToAdd = ""
                            annotationVersion++
                            showAddTextDialog = false
                            Toast.makeText(context, "Text annotation added", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = accent)
                ) {
                    Text("Place Text", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddTextDialog = false }) {
                    Text("Cancel", color = Color.Gray)
                }
            },
            containerColor = DarkSurface
        )
    }

    // ==========================================
    // STICKY NOTE DIALOG
    // ==========================================
    if (showStickyNoteDialog) {
        AlertDialog(
            onDismissRequest = { showStickyNoteDialog = false },
            title = { Text("Add Sticky Note", color = Color.White, fontWeight = FontWeight.Bold) },
            text = {
                OutlinedTextField(
                    value = stickyNoteText,
                    onValueChange = { stickyNoteText = it },
                    placeholder = { Text("Write note comment...", fontSize = 12.sp) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = accent,
                        unfocusedBorderColor = Color(0xFF223048),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (stickyNoteText.isNotBlank()) {
                            val pData = pageAnnotations.getOrPut(activePageIndex) { PageAnnotationData(activePageIndex) }
                            pData.stickyNotes.add(
                                PdfStickyNote(
                                    text = stickyNoteText.trim(),
                                    position = pendingNotePosition
                                )
                            )
                            stickyNoteText = ""
                            annotationVersion++
                            showStickyNoteDialog = false
                            Toast.makeText(context, "Sticky note dropped", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = accent)
                ) {
                    Text("Pin Note", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showStickyNoteDialog = false }) {
                    Text("Cancel", color = Color.Gray)
                }
            },
            containerColor = DarkSurface
        )
    }

    // ==========================================
    // WATERMARK DIALOG
    // ==========================================
    if (showWatermarkDialog) {
        AlertDialog(
            onDismissRequest = { showWatermarkDialog = false },
            title = { Text("Apply Diagonal Watermark", color = Color.White, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = watermarkInputText,
                        onValueChange = { watermarkInputText = it },
                        label = { Text("Watermark text (e.g. DRAFT, CONFIDENTIAL)") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = accent,
                            unfocusedBorderColor = Color(0xFF223048),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (watermarkInputText.isNotBlank()) {
                            watermarkConfig = PdfWatermarkConfig(
                                text = watermarkInputText.trim(),
                                color = activeColor,
                                alpha = 0.25f
                            )
                            annotationVersion++
                            showWatermarkDialog = false
                            Toast.makeText(context, "Watermark configured for export", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = accent)
                ) {
                    Text("Apply", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showWatermarkDialog = false }) {
                    Text("Cancel", color = Color.Gray)
                }
            },
            containerColor = DarkSurface
        )
    }

    // ==========================================
    // EDIT TEXT ANNOTATION DIALOG
    // ==========================================
    if (editingTextItem != null) {
        val target = editingTextItem!!
        AlertDialog(
            onDismissRequest = { editingTextItem = null },
            title = { Text("Edit Text Annotation", color = Color.White, fontWeight = FontWeight.Bold) },
            text = {
                OutlinedTextField(
                    value = editTextString,
                    onValueChange = { editTextString = it },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = accent,
                        unfocusedBorderColor = Color(0xFF223048),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        val pData = pageAnnotations[activePageIndex]
                        if (pData != null) {
                            val idx = pData.textAnnotations.indexOfFirst { it.id == target.id }
                            if (idx != -1) {
                                pData.textAnnotations[idx] = target.copy(text = editTextString.trim())
                                annotationVersion++
                            }
                        }
                        editingTextItem = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = accent)
                ) {
                    Text("Save", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { editingTextItem = null }) {
                    Text("Cancel", color = Color.Gray)
                }
            },
            containerColor = DarkSurface
        )
    }

    // ==========================================
    // EDIT STICKY NOTE DIALOG
    // ==========================================
    if (editingStickyNote != null) {
        val targetNote = editingStickyNote!!
        AlertDialog(
            onDismissRequest = { editingStickyNote = null },
            title = { Text("Edit Sticky Note", color = Color.White, fontWeight = FontWeight.Bold) },
            text = {
                OutlinedTextField(
                    value = editNoteString,
                    onValueChange = { editNoteString = it },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = accent,
                        unfocusedBorderColor = Color(0xFF223048),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        val pData = pageAnnotations[activePageIndex]
                        if (pData != null) {
                            val idx = pData.stickyNotes.indexOfFirst { it.id == targetNote.id }
                            if (idx != -1) {
                                pData.stickyNotes[idx] = targetNote.copy(text = editNoteString.trim())
                                annotationVersion++
                            }
                        }
                        editingStickyNote = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = accent)
                ) {
                    Text("Save", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { editingStickyNote = null }) {
                    Text("Cancel", color = Color.Gray)
                }
            },
            containerColor = DarkSurface
        )
    }
}

@Composable
private fun EditorToolButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    isSelected: Boolean,
    accent: Color,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = if (isSelected) accent.copy(alpha = 0.25f) else Color(0xFF141F33),
        border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) accent else Color(0xFF223048)),
        modifier = Modifier.clickable { onClick() }
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(imageVector = icon, contentDescription = label, tint = if (isSelected) accent else Color(0xFFD6E2F5), modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text(text = label, fontSize = 11.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium, color = if (isSelected) accent else Color.White)
        }
    }
}

@Composable
private fun PdfPageWithOverlay(
    pageIndex: Int,
    renderPage: () -> Bitmap?,
    zoomScale: Float,
    panOffset: Offset,
    onPanDelta: (Offset) -> Unit,
    onZoomDelta: (Float) -> Unit,
    isEditorMode: Boolean,
    activeTool: PdfEditTool,
    activeColor: Color,
    activeStrokeWidth: Float,
    pageAnnotations: Map<Int, PageAnnotationData>,
    annotationVersion: Int,
    currentDrawPoints: List<Offset>,
    onUpdateDrawPoints: (List<Offset>) -> Unit,
    onFinishStroke: (PdfInkStroke) -> Unit,
    onFinishShape: (PdfShapeAnnotation) -> Unit,
    onMoveTextAnnotation: (String, Offset) -> Unit,
    onResizeText: (String, Float) -> Unit,
    onEditText: (String) -> Unit,
    onDeleteTextAnnotation: (String) -> Unit,
    onMoveStickyNote: (String, Offset) -> Unit,
    onEditStickyNote: (String) -> Unit,
    onDeleteStickyNote: (String) -> Unit,
    onMoveImage: (String, Offset) -> Unit,
    onResizeImage: (String, Float) -> Unit,
    onSetImageSize: (String, Float) -> Unit,
    onResizeImageCorner: (String, Offset) -> Unit,
    onDeleteImage: (String) -> Unit,
    onTapLocation: (Offset) -> Unit,
    watermarkConfig: PdfWatermarkConfig?
) {
    var pageBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var shapeDragStart by remember { mutableStateOf<Offset?>(null) }
    var shapeDragCurrent by remember { mutableStateOf<Offset?>(null) }
    val accent = Color(0xFF00E5FF)

    LaunchedEffect(pageIndex) {
        withContext(Dispatchers.IO) {
            pageBitmap = renderPage()
        }
    }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .clipToBounds()
            .pointerInput(isEditorMode, activeTool) {
                detectTransformGestures { _, pan, zoom, _ ->
                    if (zoom != 1f) {
                        onZoomDelta(zoom)
                    }
                    if (pan != Offset.Zero && (!isEditorMode || activeTool == PdfEditTool.NONE)) {
                        onPanDelta(pan)
                    }
                }
            },
        contentAlignment = Alignment.Center
    ) {
        if (pageBitmap != null) {
            val bmp = pageBitmap!!
            val pData = pageAnnotations[pageIndex]
            val pageRotation = pData?.rotationDegrees ?: 0

            val availWidth = maxWidth.value.coerceAtLeast(100f)
            val availHeight = if (maxHeight == androidx.compose.ui.unit.Dp.Infinity) 550f else maxHeight.value.coerceAtLeast(100f)
            val bmpWidth = bmp.width.toFloat()
            val bmpHeight = bmp.height.toFloat()

            val fitFactor = minOf(
                (availWidth - 24f) / bmpWidth,
                (availHeight - 24f) / bmpHeight
            ).coerceIn(0.05f, 2.5f)

            val displayWidth = (bmpWidth * fitFactor).dp
            val displayHeight = (bmpHeight * fitFactor).dp

            Box(
                modifier = Modifier
                    .graphicsLayer {
                        scaleX = zoomScale
                        scaleY = zoomScale
                        translationX = panOffset.x
                        translationY = panOffset.y
                        rotationZ = pageRotation.toFloat()
                    }
                    .size(displayWidth, displayHeight)
                    .clip(RoundedCornerShape(6.dp))
                    .border(1.dp, Color(0xFF223048), RoundedCornerShape(6.dp))
                    .background(Color.White)
                    .onSizeChanged { size ->
                        val pageData = pageAnnotations[pageIndex]
                        if (pageData != null) {
                            pageData.canvasWidth = size.width.toFloat()
                            pageData.canvasHeight = size.height.toFloat()
                        }
                    }
            ) {
                // Background rendered PDF page
                Image(
                    bitmap = bmp.asImageBitmap(),
                    contentDescription = "PDF Page ${pageIndex + 1}",
                    modifier = Modifier.fillMaxSize()
                )

                // Interactive Annotation & Drawing Canvas
                Canvas(
                    modifier = Modifier
                        .matchParentSize()
                        .then(
                            if (isEditorMode && activeTool != PdfEditTool.NONE) {
                                Modifier.pointerInput(pageIndex, activeTool, activeColor, activeStrokeWidth) {
                                    when (activeTool) {
                                        PdfEditTool.DRAW_INK, PdfEditTool.HIGHLIGHT -> {
                                            detectDragGestures(
                                                onDragStart = { offset ->
                                                    onUpdateDrawPoints(listOf(offset))
                                                },
                                                onDrag = { change, _ ->
                                                    change.consume()
                                                    onUpdateDrawPoints(currentDrawPoints + change.position)
                                                },
                                                onDragEnd = {
                                                    if (currentDrawPoints.isNotEmpty()) {
                                                        val alpha = if (activeTool == PdfEditTool.HIGHLIGHT) 0.45f else 1f
                                                        val width = if (activeTool == PdfEditTool.HIGHLIGHT) activeStrokeWidth * 2.5f else activeStrokeWidth
                                                        onFinishStroke(
                                                            PdfInkStroke(
                                                                points = currentDrawPoints,
                                                                color = activeColor,
                                                                strokeWidth = width,
                                                                alpha = alpha
                                                            )
                                                        )
                                                    }
                                                }
                                            )
                                        }
                                        PdfEditTool.SHAPE_RECTANGLE,
                                        PdfEditTool.SHAPE_CIRCLE,
                                        PdfEditTool.SHAPE_LINE,
                                        PdfEditTool.UNDERLINE,
                                        PdfEditTool.STRIKETHROUGH -> {
                                            detectDragGestures(
                                                onDragStart = { offset ->
                                                    shapeDragStart = offset
                                                    shapeDragCurrent = offset
                                                },
                                                onDrag = { change, _ ->
                                                    change.consume()
                                                    shapeDragCurrent = change.position
                                                },
                                                onDragEnd = {
                                                    val start = shapeDragStart
                                                    val end = shapeDragCurrent
                                                    if (start != null && end != null) {
                                                        onFinishShape(
                                                            PdfShapeAnnotation(
                                                                tool = activeTool,
                                                                startOffset = start,
                                                                endOffset = end,
                                                                color = activeColor,
                                                                strokeWidth = activeStrokeWidth
                                                            )
                                                        )
                                                    }
                                                    shapeDragStart = null
                                                    shapeDragCurrent = null
                                                }
                                            )
                                        }
                                        PdfEditTool.ADD_TEXT, PdfEditTool.STICKY_NOTE -> {
                                            detectTapGestures(
                                                onTap = { offset ->
                                                    onTapLocation(offset)
                                                }
                                            )
                                        }
                                        else -> {}
                                    }
                                }
                            } else Modifier
                        )
                ) {
                    // Force recomposition on annotation version change
                    @Suppress("UNUSED_VARIABLE")
                    val version = annotationVersion

                    // 1. Draw existing ink strokes
                    pData?.inkStrokes?.forEach { stroke ->
                        if (stroke.points.size > 1) {
                            val path = Path().apply {
                                moveTo(stroke.points[0].x, stroke.points[0].y)
                                for (i in 1 until stroke.points.size) {
                                    lineTo(stroke.points[i].x, stroke.points[i].y)
                                }
                            }
                            drawPath(
                                path = path,
                                color = stroke.color.copy(alpha = stroke.alpha),
                                style = Stroke(
                                    width = stroke.strokeWidth,
                                    cap = StrokeCap.Round,
                                    join = StrokeJoin.Round
                                )
                            )
                        }
                    }

                    // 2. Draw current in-progress drawing stroke
                    if (currentDrawPoints.size > 1) {
                        val path = Path().apply {
                            moveTo(currentDrawPoints[0].x, currentDrawPoints[0].y)
                            for (i in 1 until currentDrawPoints.size) {
                                lineTo(currentDrawPoints[i].x, currentDrawPoints[i].y)
                            }
                        }
                        val strokeAlpha = if (activeTool == PdfEditTool.HIGHLIGHT) 0.45f else 1f
                        val strokeW = if (activeTool == PdfEditTool.HIGHLIGHT) activeStrokeWidth * 2.5f else activeStrokeWidth
                        drawPath(
                            path = path,
                            color = activeColor.copy(alpha = strokeAlpha),
                            style = Stroke(
                                width = strokeW,
                                cap = StrokeCap.Round,
                                join = StrokeJoin.Round
                            )
                        )
                    }

                    // 3. Draw committed shapes
                    pData?.shapes?.forEach { shape ->
                        when (shape.tool) {
                            PdfEditTool.SHAPE_RECTANGLE -> {
                                val topLeft = Offset(
                                    minOf(shape.startOffset.x, shape.endOffset.x),
                                    minOf(shape.startOffset.y, shape.endOffset.y)
                                )
                                val size = Size(
                                    kotlin.math.abs(shape.endOffset.x - shape.startOffset.x),
                                    kotlin.math.abs(shape.endOffset.y - shape.startOffset.y)
                                )
                                drawRect(
                                    color = shape.color,
                                    topLeft = topLeft,
                                    size = size,
                                    style = Stroke(width = shape.strokeWidth, cap = StrokeCap.Round, join = StrokeJoin.Round)
                                )
                            }
                            PdfEditTool.SHAPE_CIRCLE -> {
                                val topLeft = Offset(
                                    minOf(shape.startOffset.x, shape.endOffset.x),
                                    minOf(shape.startOffset.y, shape.endOffset.y)
                                )
                                val size = Size(
                                    kotlin.math.abs(shape.endOffset.x - shape.startOffset.x),
                                    kotlin.math.abs(shape.endOffset.y - shape.startOffset.y)
                                )
                                drawOval(
                                    color = shape.color,
                                    topLeft = topLeft,
                                    size = size,
                                    style = Stroke(width = shape.strokeWidth)
                                )
                            }
                            PdfEditTool.SHAPE_LINE, PdfEditTool.UNDERLINE, PdfEditTool.STRIKETHROUGH -> {
                                drawLine(
                                    color = shape.color,
                                    start = shape.startOffset,
                                    end = shape.endOffset,
                                    strokeWidth = shape.strokeWidth,
                                    cap = StrokeCap.Round
                                )
                            }
                            else -> {}
                        }
                    }

                    // 4. Draw in-progress shape preview
                    val dragStart = shapeDragStart
                    val dragCurrent = shapeDragCurrent
                    if (dragStart != null && dragCurrent != null) {
                        when (activeTool) {
                            PdfEditTool.SHAPE_RECTANGLE -> {
                                val topLeft = Offset(
                                    minOf(dragStart.x, dragCurrent.x),
                                    minOf(dragStart.y, dragCurrent.y)
                                )
                                val size = Size(
                                    kotlin.math.abs(dragCurrent.x - dragStart.x),
                                    kotlin.math.abs(dragCurrent.y - dragStart.y)
                                )
                                drawRect(
                                    color = activeColor,
                                    topLeft = topLeft,
                                    size = size,
                                    style = Stroke(width = activeStrokeWidth, cap = StrokeCap.Round, join = StrokeJoin.Round)
                                )
                            }
                            PdfEditTool.SHAPE_CIRCLE -> {
                                val topLeft = Offset(
                                    minOf(dragStart.x, dragCurrent.x),
                                    minOf(dragStart.y, dragCurrent.y)
                                )
                                val size = Size(
                                    kotlin.math.abs(dragCurrent.x - dragStart.x),
                                    kotlin.math.abs(dragCurrent.y - dragStart.y)
                                )
                                drawOval(
                                    color = activeColor,
                                    topLeft = topLeft,
                                    size = size,
                                    style = Stroke(width = activeStrokeWidth)
                                )
                            }
                            PdfEditTool.SHAPE_LINE, PdfEditTool.UNDERLINE, PdfEditTool.STRIKETHROUGH -> {
                                drawLine(
                                    color = activeColor,
                                    start = dragStart,
                                    end = dragCurrent,
                                    strokeWidth = activeStrokeWidth,
                                    cap = StrokeCap.Round
                                )
                            }
                            else -> {}
                        }
                    }
                }

                // Render placed text annotations (Draggable + Resizable + Editable)
                pData?.textAnnotations?.forEach { textItem ->
                    var isSelected by remember { mutableStateOf(false) }
                    Box(
                        modifier = Modifier
                            .graphicsLayer {
                                translationX = textItem.position.x
                                translationY = textItem.position.y
                            }
                            .pointerInput(textItem.id, isEditorMode) {
                                if (isEditorMode) {
                                    detectDragGestures { change, dragAmount ->
                                        change.consume()
                                        onMoveTextAnnotation(textItem.id, dragAmount)
                                    }
                                }
                            }
                            .background(Color.White.copy(alpha = 0.95f), RoundedCornerShape(6.dp))
                            .border(
                                if (isEditorMode) 1.5.dp else 1.dp,
                                if (isEditorMode && isSelected) accent else if (isEditorMode) Color(0xFF00E5FF) else Color(0xFFD0D7DE),
                                RoundedCornerShape(6.dp)
                            )
                            .padding(horizontal = 6.dp, vertical = 4.dp)
                            .clickable { if (isEditorMode) isSelected = !isSelected }
                    ) {
                        Column {
                            if (isEditorMode && isSelected) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                                    modifier = Modifier
                                        .background(Color(0xFF0E1726), RoundedCornerShape(4.dp))
                                        .padding(horizontal = 4.dp, vertical = 2.dp)
                                ) {
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = Color(0xFF1E2D48),
                                        modifier = Modifier.clickable { onResizeText(textItem.id, -2f) }
                                    ) {
                                        Text("A-", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White, modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp))
                                    }
                                    Text("${textItem.fontSize.toInt()}sp", fontSize = 10.sp, color = accent, fontWeight = FontWeight.Bold)
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = Color(0xFF1E2D48),
                                        modifier = Modifier.clickable { onResizeText(textItem.id, 2f) }
                                    ) {
                                        Text("A+", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White, modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp))
                                    }
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = Color(0xFF1E2D48),
                                        modifier = Modifier.clickable { onEditText(textItem.id) }
                                    ) {
                                        Icon(Icons.Default.Edit, contentDescription = "Edit text", tint = Color.White, modifier = Modifier.size(14.dp).padding(2.dp))
                                    }
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = Color(0xFF882222),
                                        modifier = Modifier.clickable { onDeleteTextAnnotation(textItem.id) }
                                    ) {
                                        Icon(Icons.Default.Close, contentDescription = "Delete text", tint = Color.White, modifier = Modifier.size(14.dp).padding(2.dp))
                                    }
                                }
                                Spacer(modifier = Modifier.height(2.dp))
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = textItem.text,
                                    fontSize = textItem.fontSize.sp,
                                    fontWeight = if (textItem.isBold) FontWeight.Bold else FontWeight.Normal,
                                    fontStyle = if (textItem.isItalic) FontStyle.Italic else FontStyle.Normal,
                                    color = textItem.color
                                )
                                if (isEditorMode && !isSelected) {
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "Delete Text",
                                        tint = Color(0xFFD32F2F),
                                        modifier = Modifier
                                            .size(13.dp)
                                            .clickable { onDeleteTextAnnotation(textItem.id) }
                                    )
                                }
                            }
                        }
                    }
                }

                // Render sticky notes markers (Draggable + Editable)
                pData?.stickyNotes?.forEach { note ->
                    Box(
                        modifier = Modifier
                            .graphicsLayer {
                                translationX = note.position.x
                                translationY = note.position.y
                            }
                            .pointerInput(note.id, isEditorMode) {
                                if (isEditorMode) {
                                    detectDragGestures { change, dragAmount ->
                                        change.consume()
                                        onMoveStickyNote(note.id, dragAmount)
                                    }
                                }
                            }
                            .clip(RoundedCornerShape(6.dp))
                            .background(note.color)
                            .border(1.5.dp, Color(0xFFC69C00), RoundedCornerShape(6.dp))
                            .padding(6.dp)
                            .clickable { if (isEditorMode) onEditStickyNote(note.id) }
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(imageVector = Icons.Default.Note, contentDescription = null, tint = Color.Black, modifier = Modifier.size(12.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Note (drag to move)", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                                if (isEditorMode) {
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "Delete Note",
                                        tint = Color.Black,
                                        modifier = Modifier
                                            .size(12.dp)
                                            .clickable { onDeleteStickyNote(note.id) }
                                    )
                                }
                            }
                            Text(text = note.text, fontSize = 11.sp, color = Color.Black)
                        }
                    }
                }

                // Render placed images (Draggable + Resizable + Size Selector)
                pData?.insertedImages?.forEach { img ->
                    Box(
                        modifier = Modifier
                            .graphicsLayer {
                                translationX = img.position.x
                                translationY = img.position.y
                            }
                            .pointerInput(img.id, isEditorMode) {
                                if (isEditorMode) {
                                    detectDragGestures { change, dragAmount ->
                                        change.consume()
                                        onMoveImage(img.id, dragAmount)
                                    }
                                }
                            }
                    ) {
                        Column {
                            if (isEditorMode) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                                    modifier = Modifier
                                        .background(Color(0xEE0A101D), RoundedCornerShape(6.dp))
                                        .padding(horizontal = 4.dp, vertical = 2.dp)
                                ) {
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = Color(0xFF1E2D48),
                                        modifier = Modifier.clickable { onResizeImage(img.id, -20f) }
                                    ) {
                                        Text("-", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White, modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp))
                                    }
                                    Text("${img.width.toInt()}px", fontSize = 9.sp, color = accent, fontWeight = FontWeight.Bold)
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = Color(0xFF1E2D48),
                                        modifier = Modifier.clickable { onResizeImage(img.id, 20f) }
                                    ) {
                                        Text("+", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White, modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp))
                                    }
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = Color(0xFF141F33),
                                        modifier = Modifier.clickable { onSetImageSize(img.id, 120f) }
                                    ) {
                                        Text("120", fontSize = 9.sp, color = Color(0xFF90A4CE), modifier = Modifier.padding(horizontal = 3.dp, vertical = 1.dp))
                                    }
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = Color(0xFF141F33),
                                        modifier = Modifier.clickable { onSetImageSize(img.id, 200f) }
                                    ) {
                                        Text("200", fontSize = 9.sp, color = Color(0xFF90A4CE), modifier = Modifier.padding(horizontal = 3.dp, vertical = 1.dp))
                                    }
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = Color(0xFF882222),
                                        modifier = Modifier.clickable { onDeleteImage(img.id) }
                                    ) {
                                        Icon(Icons.Default.Close, contentDescription = "Delete", tint = Color.White, modifier = Modifier.size(13.dp).padding(1.dp))
                                    }
                                }
                                Spacer(modifier = Modifier.height(2.dp))
                            }

                            Box(
                                modifier = Modifier
                                    .size(width = img.width.dp, height = img.height.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .border(if (isEditorMode) 2.dp else 1.dp, if (isEditorMode) accent else Color.Transparent, RoundedCornerShape(8.dp))
                            ) {
                                AsyncImage(
                                    model = img.imageUri,
                                    contentDescription = "Inserted Image",
                                    modifier = Modifier.fillMaxSize()
                                )

                                if (isEditorMode) {
                                    // Corner resize drag handle at bottom-right corner
                                    Box(
                                        modifier = Modifier
                                            .align(Alignment.BottomEnd)
                                            .size(26.dp)
                                            .background(accent, RoundedCornerShape(topStart = 8.dp))
                                            .pointerInput(img.id) {
                                                detectDragGestures { change, dragAmount ->
                                                    change.consume()
                                                    onResizeImageCorner(img.id, dragAmount)
                                                }
                                            },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.CropSquare,
                                            contentDescription = "Corner resize handle",
                                            tint = Color.Black,
                                            modifier = Modifier.size(14.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Render live watermark if set
                watermarkConfig?.let { wm ->
                    Box(
                        modifier = Modifier
                            .matchParentSize()
                            .graphicsLayer(rotationZ = wm.rotationAngle),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = wm.text,
                            fontSize = 38.sp,
                            fontWeight = FontWeight.Black,
                            color = wm.color.copy(alpha = wm.alpha),
                            letterSpacing = 4.sp
                        )
                    }
                }
            }
        } else {
            CircularProgressIndicator(color = Color(0xFF00E5FF), modifier = Modifier.size(28.dp))
        }
    }
}
