package com.FileExplorer.XFileExplorer.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.ColorLens
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Rule
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.Wallpaper
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.FileExplorer.XFileExplorer.data.FileManager
import com.FileExplorer.XFileExplorer.model.AccentPalette
import com.FileExplorer.XFileExplorer.model.AppSettings
import com.FileExplorer.XFileExplorer.model.AvailableAccents
import com.FileExplorer.XFileExplorer.model.BackgroundEngineMode
import com.FileExplorer.XFileExplorer.model.StorageLabelMode
import com.FileExplorer.XFileExplorer.model.ThemeMode
import com.FileExplorer.XFileExplorer.ui.components.CornerHamburgerButton
import com.FileExplorer.XFileExplorer.ui.theme.DarkSurface
import com.FileExplorer.XFileExplorer.ui.theme.DarkSurfaceBorder
import com.FileExplorer.XFileExplorer.ui.theme.DarkSurfaceElevated

/**
 * Requirement 3 & 5: The Customization Hub
 * Theming engine, custom background engine, and file design toggles.
 * Note: All custom file extension bindings and hubs are completely removed per Requirement 5.
 */
@Composable
fun SettingsScreen(
    settings: AppSettings,
    onUpdateSettings: (AppSettings) -> Unit,
    onOpenHamburger: () -> Unit
) {
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            onUpdateSettings(
                settings.copy(
                    customWallpaperUri = uri.toString(),
                    backgroundEngineMode = BackgroundEngineMode.CUSTOM_WALLPAPER
                )
            )
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
    ) {
        // Top Bar
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = DarkSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                CornerHamburgerButton(
                    onClick = onOpenHamburger,
                    accent = settings.currentAccent
                )

                Spacer(modifier = Modifier.width(10.dp))

                Icon(
                    imageVector = Icons.Default.Palette,
                    contentDescription = null,
                    tint = settings.currentAccent,
                    modifier = Modifier.size(22.dp)
                )

                Spacer(modifier = Modifier.width(8.dp))

                Column {
                    Text(
                        text = "The Customization Hub",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = "Theming engine & custom background layer",
                        fontSize = 11.sp,
                        color = Color(0xFF90A4CE)
                    )
                }
            }
        }

        // Settings Body
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Section 1: Theming & Accent Colors
            SettingsCard(title = "Theming & Accent Engine", icon = Icons.Default.ColorLens, accent = settings.currentAccent) {
                Text(
                    text = "Accent Color Palette",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    AvailableAccents.forEach { palette ->
                        AccentColorCircle(
                            palette = palette,
                            isSelected = settings.accentIndex == palette.id,
                            onSelect = { onUpdateSettings(settings.copy(accentIndex = palette.id)) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))
                HorizontalDivider(color = DarkSurfaceBorder)
                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = "Color Theme Mode",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Spacer(modifier = Modifier.height(8.dp))

                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ThemeModeButton(
                            label = "Dark Modern",
                            isSelected = settings.themeMode == ThemeMode.DARK,
                            accent = settings.currentAccent,
                            onClick = { onUpdateSettings(settings.copy(themeMode = ThemeMode.DARK)) },
                            modifier = Modifier.weight(1f)
                        )
                        ThemeModeButton(
                            label = "AMOLED Dark",
                            isSelected = settings.themeMode == ThemeMode.AMOLED,
                            accent = settings.currentAccent,
                            onClick = { onUpdateSettings(settings.copy(themeMode = ThemeMode.AMOLED)) },
                            modifier = Modifier.weight(1f)
                        )
                        ThemeModeButton(
                            label = "OLED Pitch Black",
                            isSelected = settings.themeMode == ThemeMode.OLED_PITCH_BLACK,
                            accent = settings.currentAccent,
                            onClick = { onUpdateSettings(settings.copy(themeMode = ThemeMode.OLED_PITCH_BLACK)) },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ThemeModeButton(
                            label = "Material You Dynamic",
                            isSelected = settings.themeMode == ThemeMode.MATERIAL_YOU,
                            accent = settings.currentAccent,
                            onClick = { onUpdateSettings(settings.copy(themeMode = ThemeMode.MATERIAL_YOU)) },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }

            // Section 2: Custom Background Engine
            SettingsCard(title = "Custom Background Engine", icon = Icons.Default.Wallpaper, accent = settings.currentAccent) {
                Text(
                    text = "Active Background Layer",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Spacer(modifier = Modifier.height(8.dp))

                val backgroundModes = listOf(
                    BackgroundEngineMode.DEFAULT_GRADIENT to "Default Tech Gradient",
                    BackgroundEngineMode.LIVE_MATRIX to "Live Digital Matrix Rain",
                    BackgroundEngineMode.LIVE_CYBER_GRID to "Live Cyberpunk Grid",
                    BackgroundEngineMode.LIVE_STARFIELD to "Live Starfield Canvas",
                    BackgroundEngineMode.CUSTOM_WALLPAPER to "Custom Wallpaper Image"
                )

                backgroundModes.forEach { (mode, label) ->
                    val isSelected = settings.backgroundEngineMode == mode
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSelected) settings.currentAccent.copy(alpha = 0.15f) else Color.Transparent)
                            .border(1.dp, if (isSelected) settings.currentAccent else DarkSurfaceBorder, RoundedCornerShape(8.dp))
                            .clickable { onUpdateSettings(settings.copy(backgroundEngineMode = mode)) }
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = label,
                            fontSize = 13.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) settings.currentAccent else Color.White
                        )
                        if (isSelected) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .background(settings.currentAccent, CircleShape)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Custom wallpaper file picker button
                Button(
                    onClick = {
                        photoPickerLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceElevated),
                    border = androidx.compose.foundation.BorderStroke(1.dp, settings.currentAccent),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Image,
                        contentDescription = null,
                        tint = settings.currentAccent
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (settings.customWallpaperUri.isNullOrEmpty()) "Pick Custom Wallpaper Image" else "Change Custom Wallpaper Image",
                        color = settings.currentAccent,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = "File Card Transparency: ${(settings.cardOpacity * 100).toInt()}%",
                    fontSize = 12.sp,
                    color = Color(0xFF90A4CE)
                )
                Slider(
                    value = settings.cardOpacity,
                    onValueChange = { onUpdateSettings(settings.copy(cardOpacity = it)) },
                    valueRange = 0.3f..1.0f,
                    colors = SliderDefaults.colors(
                        thumbColor = settings.currentAccent,
                        activeTrackColor = settings.currentAccent
                    )
                )

                Text(
                    text = "Background Wallpaper Opacity: ${(settings.backgroundOpacity * 100).toInt()}%",
                    fontSize = 12.sp,
                    color = Color(0xFF90A4CE)
                )
                Slider(
                    value = settings.backgroundOpacity,
                    onValueChange = { onUpdateSettings(settings.copy(backgroundOpacity = it)) },
                    valueRange = 0.2f..1.0f,
                    colors = SliderDefaults.colors(
                        thumbColor = settings.currentAccent,
                        activeTrackColor = settings.currentAccent
                    )
                )
            }

            // Section 3: Archival Engine & Default Compression Intensity
            SettingsCard(title = "True Archival Engine", icon = Icons.Default.Archive, accent = settings.currentAccent) {
                Text(
                    text = "Default Compression Intensity: ${settings.compressionLevel} / 100",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Controls Deflater compression ratio for .zip archives",
                    fontSize = 11.sp,
                    color = Color(0xFF90A4CE)
                )

                Slider(
                    value = settings.compressionLevel.toFloat(),
                    onValueChange = { onUpdateSettings(settings.copy(compressionLevel = it.toInt())) },
                    valueRange = 0f..100f,
                    colors = SliderDefaults.colors(
                        thumbColor = settings.currentAccent,
                        activeTrackColor = settings.currentAccent
                    )
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("0 (Store/None)", fontSize = 10.sp, color = Color(0xFF5F759E))
                    Text("60 (Balanced)", fontSize = 10.sp, color = Color(0xFF5F759E))
                    Text("100 (Maximum)", fontSize = 10.sp, color = Color(0xFF5F759E))
                }
            }

            // Section 4: Custom File Icons
            SettingsCard(title = "Custom File Icon Badges", icon = Icons.Default.Rule, accent = settings.currentAccent) {
                SettingsToggleRow(
                    title = "Image Thumbnail Previews",
                    subtitle = "Render miniature preview of actual image content on icon",
                    checked = settings.showImageThumbnails,
                    accent = settings.currentAccent,
                    onCheckedChange = { onUpdateSettings(settings.copy(showImageThumbnails = it)) }
                )

                HorizontalDivider(color = DarkSurfaceBorder, modifier = Modifier.padding(vertical = 10.dp))

                SettingsToggleRow(
                    title = "Stylized Android Mascot for APKs",
                    subtitle = "Extract actual package icon or show stylized Android robot",
                    checked = settings.useStylizedApkMascot,
                    accent = settings.currentAccent,
                    onCheckedChange = { onUpdateSettings(settings.copy(useStylizedApkMascot = it)) }
                )

                HorizontalDivider(color = DarkSurfaceBorder, modifier = Modifier.padding(vertical = 10.dp))

                SettingsToggleRow(
                    title = "Distinct Custom Archive Badge",
                    subtitle = "Unique icon for .zip (zipper) archives",
                    checked = settings.useCustomArchiveIcons,
                    accent = settings.currentAccent,
                    onCheckedChange = { onUpdateSettings(settings.copy(useCustomArchiveIcons = it)) }
                )
            }

            // Section 5: Filesystem & Display Preferences
            SettingsCard(title = "Filesystem & Visibility", icon = Icons.Default.Visibility, accent = settings.currentAccent) {
                SettingsToggleRow(
                    title = "Show Hidden System Files",
                    subtitle = "Display files and folders starting with dot (.)",
                    checked = settings.showHiddenFiles,
                    accent = settings.currentAccent,
                    onCheckedChange = { onUpdateSettings(settings.copy(showHiddenFiles = it)) }
                )
            }

            // Section 6: Storage Display Name Configuration (Requirement 2)
            SettingsCard(
                title = "Storage Display Label",
                icon = Icons.Default.Storage,
                accent = settings.currentAccent
            ) {
                var customInputText by remember(settings.customStorageLabel) {
                    mutableStateOf(settings.customStorageLabel)
                }

                Text(
                    text = "Controls how primary storage is labeled in path headers and navigation.",
                    fontSize = 12.sp,
                    color = Color(0xFF90A4CE)
                )
                Spacer(modifier = Modifier.height(10.dp))

                // Option 1: Phone Model (Default)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { onUpdateSettings(settings.copy(storageLabelMode = StorageLabelMode.PHONE_MODEL)) }
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = settings.storageLabelMode == StorageLabelMode.PHONE_MODEL,
                        onClick = { onUpdateSettings(settings.copy(storageLabelMode = StorageLabelMode.PHONE_MODEL)) },
                        colors = RadioButtonDefaults.colors(selectedColor = settings.currentAccent)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Column {
                        Text(
                            text = "Phone Model (Default)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = Color.White
                        )
                        Text(
                            text = "Use actual device hardware model (${FileManager.deviceModel})",
                            fontSize = 11.sp,
                            color = Color(0xFF8FA3CD)
                        )
                    }
                }

                // Option 2: 0
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { onUpdateSettings(settings.copy(storageLabelMode = StorageLabelMode.ZERO)) }
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = settings.storageLabelMode == StorageLabelMode.ZERO,
                        onClick = { onUpdateSettings(settings.copy(storageLabelMode = StorageLabelMode.ZERO)) },
                        colors = RadioButtonDefaults.colors(selectedColor = settings.currentAccent)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Column {
                        Text(
                            text = "0",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = Color.White
                        )
                        Text(
                            text = "Standard Android storage alias (/storage/emulated/0)",
                            fontSize = 11.sp,
                            color = Color(0xFF8FA3CD)
                        )
                    }
                }

                // Option 3: Custom
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { onUpdateSettings(settings.copy(storageLabelMode = StorageLabelMode.CUSTOM)) }
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = settings.storageLabelMode == StorageLabelMode.CUSTOM,
                        onClick = { onUpdateSettings(settings.copy(storageLabelMode = StorageLabelMode.CUSTOM)) },
                        colors = RadioButtonDefaults.colors(selectedColor = settings.currentAccent)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Column {
                        Text(
                            text = "Custom",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = Color.White
                        )
                        Text(
                            text = "Specify a personalized storage name",
                            fontSize = 11.sp,
                            color = Color(0xFF8FA3CD)
                        )
                    }
                }

                if (settings.storageLabelMode == StorageLabelMode.CUSTOM) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = customInputText,
                            onValueChange = { customInputText = it },
                            placeholder = { Text("e.g. Internal Storage, Main Phone", fontSize = 12.sp, color = Color.Gray) },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = settings.currentAccent,
                                unfocusedBorderColor = Color(0xFF223048),
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("custom_storage_input")
                        )

                        Button(
                            onClick = {
                                onUpdateSettings(
                                    settings.copy(
                                        storageLabelMode = StorageLabelMode.CUSTOM,
                                        customStorageLabel = customInputText.trim()
                                    )
                                )
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = settings.currentAccent),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("custom_storage_ok_btn")
                        ) {
                            Text("OK", color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // Section 6B: Hardware & Battery Telemetry
            val context = androidx.compose.ui.platform.LocalContext.current
            val batteryManager = remember { context.getSystemService(android.content.Context.BATTERY_SERVICE) as android.os.BatteryManager }
            val batteryPct = batteryManager.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY).coerceIn(0, 100)
            val isCharging = batteryManager.isCharging
            val batteryStatusIntent = remember {
                context.registerReceiver(null, android.content.IntentFilter(android.content.Intent.ACTION_BATTERY_CHANGED))
            }
            val rawTemp = batteryStatusIntent?.getIntExtra(android.os.BatteryManager.EXTRA_TEMPERATURE, 280) ?: 280
            val tempCelsius = rawTemp / 10.0f
            val (indicatorLabel, indicatorColor) = when {
                tempCelsius < 35.0f -> Pair("Cool", Color(0xFF00FF66))
                tempCelsius <= 40.0f -> Pair("Warm", Color(0xFFFFB000))
                else -> Pair("Hot", Color(0xFFFF3366))
            }

            SettingsCard(
                title = "Hardware & Battery Telemetry",
                icon = Icons.Default.BatteryChargingFull,
                accent = settings.currentAccent
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Battery Status",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = Color.White
                        )
                        Text(
                            text = if (isCharging) "Charging (Power connected)" else "Discharging (On battery power)",
                            fontSize = 11.sp,
                            color = Color(0xFF90A4CE)
                        )
                    }
                    Text(
                        text = "$batteryPct%",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = settings.currentAccent
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                LinearProgressIndicator(
                    progress = { batteryPct / 100f },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp)),
                    color = settings.currentAccent,
                    trackColor = Color(0xFF162032),
                    strokeCap = StrokeCap.Round
                )

                Spacer(modifier = Modifier.height(14.dp))
                HorizontalDivider(color = DarkSurfaceBorder)
                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Storage / System Heat Monitor",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = Color.White
                        )
                        Text(
                            text = "Internal device battery temperature",
                            fontSize = 11.sp,
                            color = Color(0xFF90A4CE)
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "${String.format(java.util.Locale.US, "%.1f", tempCelsius)}°C",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = indicatorColor.copy(alpha = 0.15f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, indicatorColor.copy(alpha = 0.5f))
                        ) {
                            Text(
                                text = indicatorLabel,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = indicatorColor,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            }

            // Section 7: About & System Information
            SettingsCard(
                title = "About XFile Explorer",
                icon = Icons.Default.Rule,
                accent = settings.currentAccent
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "XFile Explorer",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "Advanced Systems Architecture & Document Studio",
                            fontSize = 11.sp,
                            color = Color(0xFF90A4CE)
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = settings.currentAccent.copy(alpha = 0.2f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, settings.currentAccent)
                    ) {
                        Text(
                            text = "v2.0",
                            fontWeight = FontWeight.Black,
                            fontSize = 12.sp,
                            color = settings.currentAccent,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                HorizontalDivider(color = DarkSurfaceBorder)
                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "Release: Version 2.0 (Build 2) • Android Toybox & Native PDF Suite",
                    fontSize = 11.sp,
                    color = Color(0xFF7E97C2)
                )
            }

            Spacer(
                modifier = Modifier
                    .height(30.dp)
                    .navigationBarsPadding()
            )
        }
    }
}

@Composable
private fun SettingsCard(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    accent: Color,
    content: @Composable () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = DarkSurface,
        shape = RoundedCornerShape(14.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = accent,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
            Spacer(modifier = Modifier.height(14.dp))
            content()
        }
    }
}

@Composable
private fun AccentColorCircle(
    palette: AccentPalette,
    isSelected: Boolean,
    onSelect: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(40.dp)
            .clip(CircleShape)
            .background(palette.color)
            .border(
                width = if (isSelected) 3.dp else 1.dp,
                color = if (isSelected) Color.White else Color.Transparent,
                shape = CircleShape
            )
            .clickable(onClick = onSelect),
        contentAlignment = Alignment.Center
    ) {
        if (isSelected) {
            Box(
                modifier = Modifier
                    .size(10.dp)
                    .background(Color.White, CircleShape)
            )
        }
    }
}

@Composable
private fun ThemeModeButton(
    label: String,
    isSelected: Boolean,
    accent: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (isSelected) accent.copy(alpha = 0.2f) else DarkSurfaceElevated)
            .border(1.dp, if (isSelected) accent else DarkSurfaceBorder, RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
            color = if (isSelected) accent else Color(0xFFD6E2F5)
        )
    }
}

@Composable
private fun SettingsToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    accent: Color,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            Text(
                text = subtitle,
                fontSize = 11.sp,
                color = Color(0xFF90A4CE)
            )
        }

        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.Black,
                checkedTrackColor = accent,
                uncheckedTrackColor = DarkSurfaceElevated
            )
        )
    }
}
