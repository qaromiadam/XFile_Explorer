package com.FileExplorer.XFileExplorer.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.BatteryFull
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.SdCard
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.FileExplorer.XFileExplorer.model.AppSettings
import com.FileExplorer.XFileExplorer.ui.theme.DarkSurface
import com.FileExplorer.XFileExplorer.ui.theme.DarkSurfaceBorder
import com.FileExplorer.XFileExplorer.ui.theme.DarkSurfaceElevated
import com.FileExplorer.XFileExplorer.ui.theme.TechCyan
import java.io.File

enum class ScreenDestination {
    EXPLORER,
    TERMINAL,
    APPS,
    SETTINGS
}

@Composable
fun CornerHamburgerButton(
    onClick: () -> Unit,
    accent: Color,
    modifier: Modifier = Modifier
) {
    IconButton(
        onClick = onClick,
        modifier = modifier
            .size(48.dp)
            .testTag("corner_hamburger_trigger")
            .background(DarkSurfaceElevated.copy(alpha = 0.8f), CircleShape)
            .border(1.dp, accent.copy(alpha = 0.35f), CircleShape)
    ) {
        Icon(
            imageVector = Icons.Default.Menu,
            contentDescription = "Open Navigation Menu",
            tint = accent,
            modifier = Modifier.size(24.dp)
        )
    }
}

/**
 * Requirement 2: Corner Navigation Menu (Hamburger Panel)
 * Expands an overlay panel providing direct access to Settings and Terminal.
 * Includes a back arrow inside the panel that instantly collapses/resizes it back down.
 */
@Composable
fun CornerNavigationOverlay(
    isExpanded: Boolean,
    onCollapse: () -> Unit,
    currentDestination: ScreenDestination,
    onNavigate: (ScreenDestination) -> Unit,
    settings: AppSettings,
    deviceRoots: List<File>,
    onSelectRoot: (File) -> Unit,
    activeDirectory: File
) {
    AnimatedVisibility(
        visible = isExpanded,
        enter = fadeIn(),
        exit = fadeOut()
    ) {
        // Scrim background
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.65f))
                .clickable { onCollapse() }
        )
    }

    AnimatedVisibility(
        visible = isExpanded,
        enter = slideInHorizontally { -it },
        exit = slideOutHorizontally { -it }
    ) {
        Box(
            modifier = Modifier
                .fillMaxHeight()
                .width(320.dp)
                .background(DarkSurface)
                .border(width = 1.dp, color = DarkSurfaceBorder, shape = RoundedCornerShape(topEnd = 16.dp, bottomEnd = 16.dp))
                .statusBarsPadding()
                .navigationBarsPadding()
                .testTag("navigation_panel_drawer")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                // Top Header with Branding and Collapse Control (Back Arrow)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // Sharp geometric XL monogram badge
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(settings.currentAccent.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
                                .border(1.5.dp, settings.currentAccent, RoundedCornerShape(8.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "XL",
                                fontWeight = FontWeight.Black,
                                fontSize = 16.sp,
                                color = settings.currentAccent
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column {
                            Text(
                                text = "XFile Explorer",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = "Advanced Systems Architecture",
                                fontSize = 10.sp,
                                color = Color(0xFF90A4CE)
                            )
                        }
                    }

                    // Requirement 2: Back arrow inside panel that instantly collapses it
                    IconButton(
                        onClick = onCollapse,
                        modifier = Modifier
                            .size(44.dp)
                            .testTag("panel_collapse_button")
                            .background(DarkSurfaceElevated, CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Collapse Menu",
                            tint = settings.currentAccent
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))
                HorizontalDivider(color = DarkSurfaceBorder)
                Spacer(modifier = Modifier.height(16.dp))

                // Core Navigation Targets: Terminal, Settings, Explorer
                Text(
                    text = "MAIN CONSOLES",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF5F759E),
                    letterSpacing = 1.sp
                )

                Spacer(modifier = Modifier.height(8.dp))

                NavigationMenuItem(
                    icon = Icons.Default.Folder,
                    label = "File Explorer",
                    subtitle = "Modular storage browser",
                    selected = currentDestination == ScreenDestination.EXPLORER,
                    accent = settings.currentAccent,
                    testTag = "nav_item_explorer",
                    onClick = {
                        onNavigate(ScreenDestination.EXPLORER)
                        onCollapse()
                    }
                )

                Spacer(modifier = Modifier.height(6.dp))

                NavigationMenuItem(
                    icon = Icons.Default.Terminal,
                    label = "Integrated Terminal",
                    subtitle = "Termux-like shell & apt",
                    selected = currentDestination == ScreenDestination.TERMINAL,
                    accent = settings.currentAccent,
                    testTag = "nav_item_terminal",
                    onClick = {
                        onNavigate(ScreenDestination.TERMINAL)
                        onCollapse()
                    }
                )

                Spacer(modifier = Modifier.height(6.dp))

                NavigationMenuItem(
                    icon = Icons.Default.Apps,
                    label = "Apps",
                    subtitle = "Application manager & info",
                    selected = currentDestination == ScreenDestination.APPS,
                    accent = settings.currentAccent,
                    testTag = "nav_item_apps",
                    onClick = {
                        onNavigate(ScreenDestination.APPS)
                        onCollapse()
                    }
                )

                Spacer(modifier = Modifier.height(6.dp))

                NavigationMenuItem(
                    icon = Icons.Default.Palette,
                    label = "Customization Hub",
                    subtitle = "Theming, backgrounds & icon rules",
                    selected = currentDestination == ScreenDestination.SETTINGS,
                    accent = settings.currentAccent,
                    testTag = "nav_item_settings",
                    onClick = {
                        onNavigate(ScreenDestination.SETTINGS)
                        onCollapse()
                    }
                )

                Spacer(modifier = Modifier.height(20.dp))
                HorizontalDivider(color = DarkSurfaceBorder)
                Spacer(modifier = Modifier.height(16.dp))

                // Storage Bookmarks
                Text(
                    text = "STORAGE DIRECTORIES",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF5F759E),
                    letterSpacing = 1.sp
                )

                Spacer(modifier = Modifier.height(8.dp))

                deviceRoots.forEach { root ->
                    val isCurrent = activeDirectory.absolutePath == root.absolutePath ||
                            activeDirectory.absolutePath.startsWith(root.absolutePath)
                    val icon = when {
                        root.name.equals("Download", true) -> Icons.Default.Download
                        root.name.equals("Pictures", true) -> Icons.Default.Image
                        root.absolutePath == "/" -> Icons.Default.Security
                        else -> Icons.Default.SdCard
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (isCurrent) settings.currentAccent.copy(alpha = 0.12f) else Color.Transparent)
                            .clickable {
                                onSelectRoot(root)
                                onNavigate(ScreenDestination.EXPLORER)
                                onCollapse()
                            }
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = null,
                            tint = if (isCurrent) settings.currentAccent else Color(0xFF90A4CE),
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            val displayName = if (root.absolutePath == "/") {
                                "Root File System (/)"
                            } else if (root.name == "0" || root.absolutePath.trimEnd('/') == com.FileExplorer.XFileExplorer.data.FileManager.NAVIGATION_BOUNDARY_PATH) {
                                "${com.FileExplorer.XFileExplorer.data.FileManager.getStorageLabel(settings)} (Internal)"
                            } else {
                                root.name
                            }
                            val (totalSpace, freeSpace) = try {
                                val stat = android.os.StatFs(root.absolutePath)
                                val total = stat.blockCountLong * stat.blockSizeLong
                                val free = stat.availableBlocksLong * stat.blockSizeLong
                                if (total > 0L) Pair(total, free) else Pair(root.totalSpace, root.freeSpace)
                            } catch (_: Exception) {
                                Pair(root.totalSpace, root.freeSpace)
                            }
                            val capacityLabel = if (totalSpace > 0L) {
                                val freeStr = com.FileExplorer.XFileExplorer.model.FileItem.formatBytes(freeSpace)
                                val totalStr = com.FileExplorer.XFileExplorer.model.FileItem.formatBytes(totalSpace)
                                "$freeStr free of $totalStr"
                            } else {
                                com.FileExplorer.XFileExplorer.data.FileManager.formatDisplayPath(root.absolutePath, settings)
                            }
                            Text(
                                text = displayName,
                                fontSize = 13.sp,
                                fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Medium,
                                color = if (isCurrent) Color.White else Color(0xFFD6E2F5)
                            )
                            Text(
                                text = capacityLabel,
                                fontSize = 10.sp,
                                color = if (isCurrent) settings.currentAccent else Color(0xFF6F85AE),
                                maxLines = 1
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                }

                Spacer(modifier = Modifier.weight(1f, fill = false))
                Spacer(modifier = Modifier.height(24.dp))

                // Storage Telemetry Card
                StorageTelemetryWidget(directory = activeDirectory, accent = settings.currentAccent)
                
                // Battery Monitor
                BatteryMonitorWidget(accent = settings.currentAccent)
            }
        }
    }
}

@Composable
private fun NavigationMenuItem(
    icon: ImageVector,
    label: String,
    subtitle: String,
    selected: Boolean,
    accent: Color,
    testTag: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .testTag(testTag)
            .clip(RoundedCornerShape(12.dp))
            .background(if (selected) accent.copy(alpha = 0.16f) else DarkSurfaceElevated)
            .border(
                1.dp,
                if (selected) accent else DarkSurfaceBorder,
                RoundedCornerShape(12.dp)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .background(if (selected) accent else DarkSurfaceBorder, RoundedCornerShape(8.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (selected) Color.Black else Color.White,
                modifier = Modifier.size(20.dp)
            )
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column {
            Text(
                text = label,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = if (selected) accent else Color.White
            )
            Text(
                text = subtitle,
                fontSize = 11.sp,
                color = Color(0xFF90A4CE)
            )
        }
    }
}

@Composable
private fun StorageTelemetryWidget(directory: File, accent: Color) {
    val (total, free) = androidx.compose.runtime.remember(directory.absolutePath) {
        try {
            // Use StatFs on active directory or primary internal data directory
            val targetPath = if (directory.exists() && directory.canRead()) directory.path else android.os.Environment.getDataDirectory().path
            val statFs = android.os.StatFs(targetPath)
            val blockSize = statFs.blockSizeLong
            val totalBlocks = statFs.blockCountLong
            val availBlocks = statFs.availableBlocksLong
            val t = totalBlocks * blockSize
            val f = availBlocks * blockSize
            if (t > 0L) {
                Pair(t, f)
            } else {
                val dataStat = android.os.StatFs(android.os.Environment.getDataDirectory().path)
                Pair(dataStat.blockCountLong * dataStat.blockSizeLong, dataStat.availableBlocksLong * dataStat.blockSizeLong)
            }
        } catch (_: Exception) {
            try {
                val dataStat = android.os.StatFs(android.os.Environment.getDataDirectory().path)
                Pair(dataStat.blockCountLong * dataStat.blockSizeLong, dataStat.availableBlocksLong * dataStat.blockSizeLong)
            } catch (_: Exception) {
                Pair(1024L * 1024L * 1024L * 64L, 1024L * 1024L * 1024L * 32L)
            }
        }
    }
    val used = (total - free).coerceAtLeast(0L)
    val progress = if (total > 0) (used.toFloat() / total.toFloat()).coerceIn(0f, 1f) else 0f
    val usedGb = String.format(java.util.Locale.US, "%.1f GB", used / (1024.0 * 1024.0 * 1024.0))
    val totalGb = String.format(java.util.Locale.US, "%.1f GB", total / (1024.0 * 1024.0 * 1024.0))

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(DarkSurfaceElevated, RoundedCornerShape(12.dp))
            .border(1.dp, DarkSurfaceBorder, RoundedCornerShape(12.dp))
            .padding(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Memory,
                    contentDescription = null,
                    tint = accent,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Storage Telemetry",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
            Text(
                text = "${(progress * 100).toInt()}%",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = accent
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp)),
            color = accent,
            trackColor = DarkSurfaceBorder,
            strokeCap = StrokeCap.Round
        )

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = "Used: $usedGb", fontSize = 11.sp, color = Color(0xFF90A4CE))
            Text(text = "Total: $totalGb", fontSize = 11.sp, color = Color(0xFF90A4CE))
        }
    }
}

@Composable
private fun BatteryMonitorWidget(accent: Color) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val (batteryPct, isCharging, tempCelsius) = remember {
        try {
            val batteryStatusIntent = context.registerReceiver(
                null,
                android.content.IntentFilter(android.content.Intent.ACTION_BATTERY_CHANGED)
            )
            val level = batteryStatusIntent?.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = batteryStatusIntent?.getIntExtra(android.os.BatteryManager.EXTRA_SCALE, -1) ?: -1
            val pct = if (level >= 0 && scale > 0) {
                ((level.toFloat() / scale.toFloat()) * 100f).toInt().coerceIn(0, 100)
            } else {
                val bm = context.getSystemService(android.content.Context.BATTERY_SERVICE) as? android.os.BatteryManager
                val prop = bm?.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: 50
                if (prop in 1..100) prop else 100
            }

            val status = batteryStatusIntent?.getIntExtra(android.os.BatteryManager.EXTRA_STATUS, -1) ?: -1
            val charging = status == android.os.BatteryManager.BATTERY_STATUS_CHARGING ||
                    status == android.os.BatteryManager.BATTERY_STATUS_FULL

            val rawTemp = batteryStatusIntent?.getIntExtra(android.os.BatteryManager.EXTRA_TEMPERATURE, 280) ?: 280
            val temp = (rawTemp / 10.0f).coerceIn(15.0f, 65.0f)
            Triple(pct, charging, temp)
        } catch (_: Exception) {
            Triple(100, false, 28.0f)
        }
    }

    val (indicatorLabel, indicatorColor) = when {
        tempCelsius < 35.0f -> Pair("Cool", Color(0xFF00FF66))
        tempCelsius <= 40.0f -> Pair("Warm", Color(0xFFFFB000))
        else -> Pair("Hot", Color(0xFFFF3366))
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 16.dp)
            .background(DarkSurfaceElevated, RoundedCornerShape(12.dp))
            .border(1.dp, DarkSurfaceBorder, RoundedCornerShape(12.dp))
            .padding(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = if (isCharging) Icons.Default.BatteryChargingFull else Icons.Default.BatteryFull,
                    contentDescription = null,
                    tint = accent,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Battery & Thermal",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
            Text(
                text = "$batteryPct% ${if (isCharging) "⚡" else ""}",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = accent
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Temp: ${String.format(java.util.Locale.US, "%.1f", tempCelsius)}°C",
                fontSize = 11.sp,
                color = Color(0xFF90A4CE)
            )
            Surface(
                shape = RoundedCornerShape(4.dp),
                color = indicatorColor.copy(alpha = 0.15f),
                border = androidx.compose.foundation.BorderStroke(1.dp, indicatorColor.copy(alpha = 0.5f))
            ) {
                Text(
                    text = indicatorLabel,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = indicatorColor,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }
        }
    }
}
