package com.FileExplorer.XFileExplorer.data

import android.content.Context
import android.graphics.Bitmap
import com.FileExplorer.XFileExplorer.model.PageAnnotationData
import com.FileExplorer.XFileExplorer.model.PdfWatermarkConfig
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.font.PDType1Font
import com.tom_roush.pdfbox.pdmodel.graphics.state.PDExtendedGraphicsState
import com.tom_roush.pdfbox.text.PDFTextStripper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException

object PdfSuiteEngine {

    private var isInitialized = false

    fun ensureInitialized(context: Context) {
        if (!isInitialized) {
            try {
                PDFBoxResourceLoader.init(context.applicationContext)
                isInitialized = true
            } catch (_: Exception) {}
        }
    }

    /**
     * Performs text search across all pages of the PDF file.
     * Returns a list of 0-based page indices where the search query appears.
     */
    suspend fun searchInDocument(
        file: File,
        query: String
    ): List<Int> = withContext(Dispatchers.IO) {
        if (!file.exists() || query.isBlank()) return@withContext emptyList()
        val matchingPages = mutableListOf<Int>()
        var doc: PDDocument? = null
        try {
            doc = PDDocument.load(file)
            val stripper = PDFTextStripper()
            val totalPages = doc.numberOfPages
            for (p in 1..totalPages) {
                stripper.startPage = p
                stripper.endPage = p
                val pageText = stripper.getText(doc)
                if (pageText.contains(query, ignoreCase = true)) {
                    matchingPages.add(p - 1)
                }
            }
        } catch (_: Exception) {
        } finally {
            try { doc?.close() } catch (_: Exception) {}
        }
        matchingPages
    }

    /**
     * Saves the PDF document with all page rotations, watermarks, text, and annotations.
     * If [inPlace] is true, safely overwrites the original file via an atomic temp swap.
     */
    suspend fun saveDocument(
        context: Context,
        originalFile: File,
        targetFile: File,
        inPlace: Boolean,
        pageAnnotations: Map<Int, PageAnnotationData>,
        watermarkConfig: PdfWatermarkConfig?,
        deletedPageIndices: Set<Int> = emptySet(),
        blankPagesAdded: Int = 0
    ): Result<File> = withContext(Dispatchers.IO) {
        try {
            if (!originalFile.exists()) {
                return@withContext Result.failure(IOException("Original PDF file does not exist"))
            }

            val doc = PDDocument.load(originalFile)
            val totalInitialPages = doc.numberOfPages

            // 1. Delete pages in reverse order so indices remain consistent
            val sortedDeletions = deletedPageIndices.filter { it in 0 until totalInitialPages }.sortedDescending()
            for (delIdx in sortedDeletions) {
                if (doc.numberOfPages > 1) {
                    doc.removePage(delIdx)
                }
            }

            // 2. Add blank pages if requested
            for (i in 0 until blankPagesAdded) {
                doc.addPage(PDPage())
            }

            // 3. Apply page annotations, rotations, text additions, and watermarks
            val currentPagesCount = doc.numberOfPages
            for (pageIdx in 0 until currentPagesCount) {
                val page = doc.getPage(pageIdx)
                val annotations = pageAnnotations[pageIdx]
                val mediaBox = page.mediaBox

                // Calculate display-to-PDF coordinate scale factors
                val scaleX = if (annotations != null && annotations.canvasWidth > 0f) {
                    mediaBox.width / annotations.canvasWidth
                } else {
                    mediaBox.width / 600f
                }
                val scaleY = if (annotations != null && annotations.canvasHeight > 0f) {
                    mediaBox.height / annotations.canvasHeight
                } else {
                    mediaBox.height / 800f
                }
                val avgScale = (scaleX + scaleY) / 2f

                // Apply rotation
                if (annotations != null && annotations.rotationDegrees != 0) {
                    val currentRot = page.rotation
                    page.rotation = (currentRot + annotations.rotationDegrees) % 360
                }

                // Render watermark if present
                if (watermarkConfig != null && watermarkConfig.text.isNotBlank()) {
                    try {
                        val contentStream = PDPageContentStream(doc, page, PDPageContentStream.AppendMode.APPEND, true, true)
                        val gState = PDExtendedGraphicsState().apply {
                            nonStrokingAlphaConstant = watermarkConfig.alpha
                        }
                        contentStream.setGraphicsStateParameters(gState)
                        contentStream.beginText()
                        contentStream.setFont(PDType1Font.HELVETICA_BOLD, watermarkConfig.fontSize)
                        contentStream.setNonStrokingColor(
                            watermarkConfig.color.red,
                            watermarkConfig.color.green,
                            watermarkConfig.color.blue
                        )
                        val midX = mediaBox.width / 4f
                        val midY = mediaBox.height / 2f
                        val cosVal = Math.cos(Math.toRadians(45.0))
                        val sinVal = Math.sin(Math.toRadians(45.0))
                        contentStream.setTextMatrix(
                            cosVal,
                            sinVal,
                            -sinVal,
                            cosVal,
                            midX.toDouble(),
                            midY.toDouble()
                        )
                        contentStream.showText(watermarkConfig.text)
                        contentStream.endText()
                        contentStream.close()
                    } catch (_: Exception) {}
                }

                // Render ink strokes and highlights on the page
                if (annotations != null && annotations.inkStrokes.isNotEmpty()) {
                    try {
                        val contentStream = PDPageContentStream(doc, page, PDPageContentStream.AppendMode.APPEND, true, true)
                        for (stroke in annotations.inkStrokes) {
                            if (stroke.points.size > 1) {
                                val gState = PDExtendedGraphicsState().apply {
                                    strokingAlphaConstant = stroke.alpha
                                    nonStrokingAlphaConstant = stroke.alpha
                                }
                                contentStream.setGraphicsStateParameters(gState)
                                contentStream.setStrokingColor(stroke.color.red, stroke.color.green, stroke.color.blue)
                                contentStream.setLineWidth((stroke.strokeWidth * avgScale).coerceIn(1f, 40f))
                                contentStream.setLineCapStyle(1) // Round cap
                                contentStream.setLineJoinStyle(1) // Round join
                                val p0 = stroke.points[0]
                                contentStream.moveTo(p0.x * scaleX, mediaBox.height - (p0.y * scaleY))
                                for (i in 1 until stroke.points.size) {
                                    val pt = stroke.points[i]
                                    contentStream.lineTo(pt.x * scaleX, mediaBox.height - (pt.y * scaleY))
                                }
                                contentStream.stroke()
                            }
                        }
                        contentStream.close()
                    } catch (_: Exception) {}
                }

                // Render shapes on the page (Rectangle, Circle/Oval, Line, Underline, Strike)
                if (annotations != null && annotations.shapes.isNotEmpty()) {
                    try {
                        val contentStream = PDPageContentStream(doc, page, PDPageContentStream.AppendMode.APPEND, true, true)
                        for (shape in annotations.shapes) {
                            contentStream.setStrokingColor(shape.color.red, shape.color.green, shape.color.blue)
                            contentStream.setLineWidth((shape.strokeWidth * avgScale).coerceIn(1f, 30f))
                            contentStream.setLineCapStyle(1)
                            contentStream.setLineJoinStyle(1)
                            val startX = shape.startOffset.x * scaleX
                            val startY = mediaBox.height - (shape.startOffset.y * scaleY)
                            val endX = shape.endOffset.x * scaleX
                            val endY = mediaBox.height - (shape.endOffset.y * scaleY)
                            when (shape.tool) {
                                com.FileExplorer.XFileExplorer.model.PdfEditTool.SHAPE_LINE,
                                com.FileExplorer.XFileExplorer.model.PdfEditTool.UNDERLINE,
                                com.FileExplorer.XFileExplorer.model.PdfEditTool.STRIKETHROUGH -> {
                                    contentStream.moveTo(startX, startY)
                                    contentStream.lineTo(endX, endY)
                                    contentStream.stroke()
                                }
                                com.FileExplorer.XFileExplorer.model.PdfEditTool.SHAPE_RECTANGLE -> {
                                    val minX = Math.min(startX, endX)
                                    val minY = Math.min(startY, endY)
                                    val w = Math.abs(endX - startX)
                                    val h = Math.abs(endY - startY)
                                    contentStream.addRect(minX, minY, w, h)
                                    contentStream.stroke()
                                }
                                com.FileExplorer.XFileExplorer.model.PdfEditTool.SHAPE_CIRCLE -> {
                                    val minX = Math.min(startX, endX)
                                    val minY = Math.min(startY, endY)
                                    val w = Math.abs(endX - startX)
                                    val h = Math.abs(endY - startY)
                                    val rx = w / 2f
                                    val ry = h / 2f
                                    val cx = minX + rx
                                    val cy = minY + ry
                                    val kx = 0.55228475f * rx
                                    val ky = 0.55228475f * ry
                                    contentStream.moveTo(cx - rx, cy)
                                    contentStream.curveTo(cx - rx, cy + ky, cx - kx, cy + ry, cx, cy + ry)
                                    contentStream.curveTo(cx + kx, cy + ry, cx + rx, cy + ky, cx + rx, cy)
                                    contentStream.curveTo(cx + rx, cy - ky, cx + kx, cy - ry, cx, cy - ry)
                                    contentStream.curveTo(cx - kx, cy - ry, cx - rx, cy - ky, cx - rx, cy)
                                    contentStream.stroke()
                                }
                                else -> {}
                            }
                        }
                        contentStream.close()
                    } catch (_: Exception) {}
                }

                // Render text annotations on the page
                if (annotations != null && annotations.textAnnotations.isNotEmpty()) {
                    try {
                        val contentStream = PDPageContentStream(doc, page, PDPageContentStream.AppendMode.APPEND, true, true)
                        for (textItem in annotations.textAnnotations) {
                            contentStream.beginText()
                            val font = if (textItem.isBold) PDType1Font.HELVETICA_BOLD else if (textItem.isItalic) PDType1Font.HELVETICA_OBLIQUE else PDType1Font.HELVETICA
                            val fontSizePdf = (textItem.fontSize * avgScale).coerceIn(8f, 72f)
                            contentStream.setFont(font, fontSizePdf)
                            contentStream.setNonStrokingColor(
                                textItem.color.red,
                                textItem.color.green,
                                textItem.color.blue
                            )
                            val pdfX = (textItem.position.x * scaleX).coerceIn(4f, mediaBox.width - 20f)
                            val pdfY = (mediaBox.height - (textItem.position.y * scaleY) - fontSizePdf).coerceIn(4f, mediaBox.height - 20f)
                            contentStream.newLineAtOffset(pdfX, pdfY)
                            contentStream.showText(textItem.text)
                            contentStream.endText()
                        }
                        contentStream.close()
                    } catch (_: Exception) {}
                }

                // Render sticky notes on the page
                if (annotations != null && annotations.stickyNotes.isNotEmpty()) {
                    try {
                        val contentStream = PDPageContentStream(doc, page, PDPageContentStream.AppendMode.APPEND, true, true)
                        for (note in annotations.stickyNotes) {
                            val noteW = 120f * scaleX
                            val noteH = 45f * scaleY
                            val pdfX = (note.position.x * scaleX).coerceIn(4f, mediaBox.width - noteW - 4f)
                            val pdfY = (mediaBox.height - (note.position.y * scaleY) - noteH).coerceIn(4f, mediaBox.height - noteH - 4f)

                            contentStream.setNonStrokingColor(1f, 0.88f, 0.35f)
                            contentStream.setStrokingColor(0.78f, 0.6f, 0f)
                            contentStream.setLineWidth(1f)
                            contentStream.addRect(pdfX, pdfY, noteW, noteH)
                            contentStream.fillAndStroke()

                            contentStream.beginText()
                            contentStream.setFont(PDType1Font.HELVETICA_BOLD, (8f * avgScale).coerceIn(7f, 13f))
                            contentStream.setNonStrokingColor(0f, 0f, 0f)
                            contentStream.newLineAtOffset(pdfX + 4f, pdfY + noteH - 12f)
                            val maxChars = 24
                            val displayText = if (note.text.length > maxChars) note.text.take(maxChars - 3) + "..." else note.text
                            contentStream.showText("Note: $displayText")
                            contentStream.endText()
                        }
                        contentStream.close()
                    } catch (_: Exception) {}
                }

                // Render inserted images on the page
                if (annotations != null && annotations.insertedImages.isNotEmpty()) {
                    try {
                        val contentStream = PDPageContentStream(doc, page, PDPageContentStream.AppendMode.APPEND, true, true)
                        for (img in annotations.insertedImages) {
                            try {
                                val uri = android.net.Uri.parse(img.imageUri)
                                val bmp: Bitmap? = if (uri.scheme == "file") {
                                    android.graphics.BitmapFactory.decodeFile(uri.path)
                                } else {
                                    context.contentResolver.openInputStream(uri)?.use { stream ->
                                        android.graphics.BitmapFactory.decodeStream(stream)
                                    }
                                }
                                if (bmp != null) {
                                    val pdImg = com.tom_roush.pdfbox.pdmodel.graphics.image.JPEGFactory.createFromImage(doc, bmp)
                                    val pdfW = (img.width * scaleX).coerceAtLeast(20f)
                                    val pdfH = (img.height * scaleY).coerceAtLeast(20f)
                                    val pdfX = (img.position.x * scaleX).coerceIn(0f, mediaBox.width - pdfW)
                                    val pdfY = (mediaBox.height - (img.position.y * scaleY) - pdfH).coerceIn(0f, mediaBox.height - pdfH)
                                    contentStream.drawImage(pdImg, pdfX, pdfY, pdfW, pdfH)
                                }
                            } catch (_: Exception) {}
                        }
                        contentStream.close()
                    } catch (_: Exception) {}
                }
            }

            val finalDestination = if (inPlace) {
                val tempFile = File(originalFile.parentFile, ".${originalFile.name}.tmp_${System.currentTimeMillis()}")
                doc.save(tempFile)
                doc.close()
                if (tempFile.exists()) {
                    if (originalFile.delete()) {
                        tempFile.renameTo(originalFile)
                    } else {
                        tempFile.copyTo(originalFile, overwrite = true)
                        tempFile.delete()
                    }
                }
                originalFile
            } else {
                val destFile = if (targetFile.extension.equals("pdf", ignoreCase = true)) {
                    targetFile
                } else {
                    File(targetFile.parentFile, "${targetFile.name}.pdf")
                }
                doc.save(destFile)
                doc.close()
                destFile
            }

            Result.success(finalDestination)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
