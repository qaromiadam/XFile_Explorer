package com.FileExplorer.XFileExplorer.model

import androidx.compose.ui.graphics.Color
import com.FileExplorer.XFileExplorer.ui.theme.TechAmber
import com.FileExplorer.XFileExplorer.ui.theme.TechBlue
import com.FileExplorer.XFileExplorer.ui.theme.TechCyan
import com.FileExplorer.XFileExplorer.ui.theme.TechEmerald
import com.FileExplorer.XFileExplorer.ui.theme.TechMagenta
import com.FileExplorer.XFileExplorer.ui.theme.TechViolet

enum class ThemeMode {
    DARK,
    AMOLED,
    LIGHT,
    MATERIAL_YOU,
    OLED_PITCH_BLACK
}

enum class BackgroundEngineMode {
    DEFAULT_GRADIENT,
    LIVE_MATRIX,
    LIVE_CYBER_GRID,
    LIVE_STARFIELD,
    CUSTOM_WALLPAPER
}

enum class StorageLabelMode {
    PHONE_MODEL,
    ZERO,
    CUSTOM
}

data class AccentPalette(
    val id: Int,
    val name: String,
    val color: Color
)

val AvailableAccents = listOf(
    AccentPalette(0, "Cyan Pulse", TechCyan),
    AccentPalette(1, "Matrix Green", TechEmerald),
    AccentPalette(2, "Electric Blue", TechBlue),
    AccentPalette(3, "Cyber Magenta", TechMagenta),
    AccentPalette(4, "Solar Amber", TechAmber),
    AccentPalette(5, "Quantum Violet", TechViolet),
    AccentPalette(6, "Cyberpunk Neon", Color(0xFF00E5FF)),
    AccentPalette(7, "Tokyo Night", Color(0xFF7AA2F7)),
    AccentPalette(8, "Retro Amber", Color(0xFFFFB000)),
    AccentPalette(9, "Electric Lime", Color(0xFF76FF03)),
    AccentPalette(10, "Hyper Pink", Color(0xFFFF1744)),
    AccentPalette(11, "Vivid Purple", Color(0xFFD500F9)),
    AccentPalette(12, "Solar Flare", Color(0xFFFF9100))
)

data class AppSettings(
    val themeMode: ThemeMode = ThemeMode.DARK,
    val accentIndex: Int = 0,
    val backgroundEngineMode: BackgroundEngineMode = BackgroundEngineMode.DEFAULT_GRADIENT,
    val customWallpaperUri: String? = null,
    val backgroundOpacity: Float = 0.85f,
    val backgroundBlur: Float = 0f,
    val cardOpacity: Float = 0.82f,
    val showImageThumbnails: Boolean = true,
    val useStylizedApkMascot: Boolean = true,
    val useCustomArchiveIcons: Boolean = true,
    val showHiddenFiles: Boolean = true,
    val sortBy: SortBy = SortBy.DATE,
    val sortAscending: Boolean = false,
    val compressionLevel: Int = 60, // 0 (None) to 100 (Full compression)
    val storageLabelMode: StorageLabelMode = StorageLabelMode.PHONE_MODEL,
    val customStorageLabel: String = ""
) {
    val currentAccent: Color
        get() = AvailableAccents.getOrElse(accentIndex) { AvailableAccents[0] }.color
}

enum class SortBy {
    NAME,
    SIZE,
    DATE,
    TYPE
}
