package com.FileExplorer.XFileExplorer.ui.components

import android.net.Uri
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.FileExplorer.XFileExplorer.model.AppSettings
import com.FileExplorer.XFileExplorer.model.BackgroundEngineMode
import com.FileExplorer.XFileExplorer.ui.theme.DarkBackground
import com.FileExplorer.XFileExplorer.ui.theme.DarkSurface
import kotlin.random.Random

/**
 * Requirement 9: Custom Background Engine
 * Renders custom backgrounds (image wallpapers or dynamic live canvas layers)
 * behind the transparent file list cards.
 */
@Composable
fun CustomBackground(
    settings: AppSettings,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    val bgBaseColor = when (settings.themeMode) {
        com.FileExplorer.XFileExplorer.model.ThemeMode.LIGHT -> Color(0xFFF1F5F9)
        com.FileExplorer.XFileExplorer.model.ThemeMode.OLED_PITCH_BLACK -> Color.Black
        com.FileExplorer.XFileExplorer.model.ThemeMode.AMOLED -> Color(0xFF040608)
        else -> DarkBackground
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(bgBaseColor)
    ) {
        when (settings.backgroundEngineMode) {
            BackgroundEngineMode.DEFAULT_GRADIENT -> {
                val gradientColors = when (settings.themeMode) {
                    com.FileExplorer.XFileExplorer.model.ThemeMode.LIGHT -> listOf(
                        Color(0xFFFFFFFF),
                        Color(0xFFF1F5F9),
                        Color(0xFFE2E8F0)
                    )
                    com.FileExplorer.XFileExplorer.model.ThemeMode.OLED_PITCH_BLACK -> listOf(
                        Color.Black,
                        Color.Black,
                        Color.Black
                    )
                    com.FileExplorer.XFileExplorer.model.ThemeMode.AMOLED -> listOf(
                        Color.Black,
                        Color(0xFF070B12),
                        Color.Black
                    )
                    else -> listOf(
                        Color(0xFF070B14),
                        Color(0xFF0F172A),
                        Color(0xFF04060B)
                    )
                }
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(colors = gradientColors)
                        )
                )
            }

            BackgroundEngineMode.LIVE_MATRIX -> {
                LiveMatrixCanvas(accent = settings.currentAccent)
            }

            BackgroundEngineMode.LIVE_CYBER_GRID -> {
                LiveCyberGridCanvas(accent = settings.currentAccent)
            }

            BackgroundEngineMode.LIVE_STARFIELD -> {
                LiveStarfieldCanvas()
            }

            BackgroundEngineMode.CUSTOM_WALLPAPER -> {
                // Aesthetic base cyber layer is always rendered underneath so the screen never appears blank
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.radialGradient(
                                colors = listOf(
                                    settings.currentAccent.copy(alpha = 0.4f),
                                    Color(0xFF0A1120),
                                    Color(0xFF03060B)
                                )
                            )
                        )
                )

                if (!settings.customWallpaperUri.isNullOrEmpty()) {
                    val context = LocalContext.current
                    AsyncImage(
                        model = ImageRequest.Builder(context)
                            .data(Uri.parse(settings.customWallpaperUri))
                            .crossfade(true)
                            .build(),
                        contentDescription = "Custom Wallpaper",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize(),
                        alpha = settings.backgroundOpacity.coerceIn(0.3f, 1f)
                    )
                }
            }
        }

        // Adaptive contrast scrim
        val scrimAlpha = (1f - settings.backgroundOpacity.coerceIn(0.2f, 0.9f)).coerceIn(0.1f, 0.5f)
        val scrimColor = if (settings.themeMode == com.FileExplorer.XFileExplorer.model.ThemeMode.LIGHT) {
            Color.White.copy(alpha = scrimAlpha * 0.4f)
        } else {
            Color.Black.copy(alpha = scrimAlpha)
        }
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(scrimColor)
        )

        content()
    }
}

@Composable
fun LiveMatrixCanvas(accent: Color) {
    val transition = rememberInfiniteTransition(label = "matrix_anim")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1200f,
        animationSpec = infiniteRepeatable(
            animation = tween(12000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "matrix_phase"
    )

    Canvas(modifier = Modifier.fillMaxSize()) {
        val columnWidth = 28f
        val columns = (size.width / columnWidth).toInt()

        for (col in 0 until columns) {
            val speed = 0.7f + (col % 5) * 0.35f
            val yOffset = ((phase * speed + col * 85f) % (size.height + 400f)) - 200f
            val x = col * columnWidth

            for (row in 0..14) {
                val y = yOffset - (row * 22f)
                if (y in -20f..size.height + 20f) {
                    val alpha = (1f - (row / 15f)).coerceIn(0.1f, 0.9f)
                    val color = if (row == 0) Color.White else accent.copy(alpha = alpha)
                    drawCircle(
                        color = color,
                        radius = if (row == 0) 3.5f else 2.2f,
                        center = Offset(x, y)
                    )
                }
            }
        }
    }
}

@Composable
fun LiveCyberGridCanvas(accent: Color) {
    val transition = rememberInfiniteTransition(label = "grid_anim")
    val offsetY by transition.animateFloat(
        initialValue = 0f,
        targetValue = 60f,
        animationSpec = infiniteRepeatable(
            animation = tween(2500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "grid_offset"
    )

    Canvas(modifier = Modifier.fillMaxSize()) {
        val gridSpacing = 48f
        // Vertical grid lines
        var x = 0f
        while (x < size.width) {
            drawLine(
                color = accent.copy(alpha = 0.22f),
                start = Offset(x, 0f),
                end = Offset(x, size.height),
                strokeWidth = 1.2f
            )
            x += gridSpacing
        }
        // Animated horizontal grid lines
        var y = offsetY
        while (y < size.height) {
            drawLine(
                color = accent.copy(alpha = 0.25f),
                start = Offset(0f, y),
                end = Offset(size.width, y),
                strokeWidth = 1.5f
            )
            y += gridSpacing
        }
    }
}

@Composable
fun LiveStarfieldCanvas() {
    val transition = rememberInfiniteTransition(label = "star_anim")
    val starPhase by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1000f,
        animationSpec = infiniteRepeatable(
            animation = tween(15000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "stars"
    )

    val baseStars = remember {
        val rand = Random(42)
        List(85) {
            Triple(rand.nextFloat(), rand.nextFloat(), rand.nextFloat() * 2.5f + 1f)
        }
    }

    Canvas(modifier = Modifier.fillMaxSize()) {
        baseStars.forEachIndexed { idx, (relX, relY, radius) ->
            val speed = 0.4f + (idx % 4) * 0.2f
            val currentY = ((relY * size.height + starPhase * speed) % size.height)
            val currentX = relX * size.width
            drawCircle(
                color = Color.White.copy(alpha = 0.65f),
                radius = radius,
                center = Offset(currentX, currentY)
            )
        }
    }
}
