package com.FileExplorer.XFileExplorer.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.Checklist
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DriveFileRenameOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.SelectAll
import androidx.compose.material.icons.filled.Unarchive
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.FileExplorer.XFileExplorer.model.FileItem
import com.FileExplorer.XFileExplorer.ui.theme.DarkSurface
import com.FileExplorer.XFileExplorer.ui.theme.DarkSurfaceBorder
import com.FileExplorer.XFileExplorer.ui.theme.DarkSurfaceElevated
import com.FileExplorer.XFileExplorer.ui.theme.TechAmber
import com.FileExplorer.XFileExplorer.ui.theme.TechCyan
import com.FileExplorer.XFileExplorer.ui.theme.TechRed
import com.FileExplorer.XFileExplorer.ui.theme.TechViolet

/**
 * Requirement 6: Single Item Context Menu triggered by long-press.
 * Contains: View, Copy, Cut, Remove, Compress to .zip/.7z, Rename, Info,
 * and the crucial "Select Multiple" trigger.
 */
@Composable
fun FileItemContextMenu(
    item: FileItem,
    accent: Color,
    onDismiss: () -> Unit,
    onView: () -> Unit,
    onCopy: () -> Unit,
    onCut: () -> Unit,
    onDelete: () -> Unit,
    onRename: () -> Unit,
    onCompressZip: () -> Unit,
    onSelectMultiple: () -> Unit,
    onShowDetails: () -> Unit,
    onExtract: () -> Unit = {}
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("file_context_menu")
                .border(1.dp, DarkSurfaceBorder, RoundedCornerShape(18.dp)),
            shape = RoundedCornerShape(18.dp),
            color = DarkSurface,
            tonalElevation = 6.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                // Header with file details
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .background(accent.copy(alpha = 0.15f), RoundedCornerShape(10.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (item.isDirectory) "DIR" else item.extension.uppercase().take(3),
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = accent
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = item.name,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            maxLines = 1
                        )
                        Text(
                            text = "${item.formattedSize} • ${item.formattedDate}",
                            fontSize = 11.sp,
                            color = Color(0xFF90A4CE)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))
                HorizontalDivider(color = DarkSurfaceBorder)
                Spacer(modifier = Modifier.height(8.dp))

                // Requirement 6: "Select Multiple Trigger: Inside that same pop-up action menu, include a 'Select Multiple' option"
                ContextActionRow(
                    icon = Icons.Default.Checklist,
                    title = "Select Multiple",
                    subtitle = "Shift to batch operations mode",
                    iconColor = accent,
                    testTag = "context_select_multiple",
                    isHighlighted = true,
                    onClick = {
                        onDismiss()
                        onSelectMultiple()
                    }
                )

                HorizontalDivider(
                    color = DarkSurfaceBorder.copy(alpha = 0.5f),
                    modifier = Modifier.padding(vertical = 4.dp)
                )

                if (!item.isDirectory) {
                    if (com.FileExplorer.XFileExplorer.data.FileManager.isArchive(item.file)) {
                        ContextActionRow(
                            icon = Icons.Default.Unarchive,
                            title = "Extract Archive",
                            subtitle = "Unpack all contents to folder",
                            iconColor = TechCyan,
                            testTag = "context_extract",
                            onClick = {
                                onDismiss()
                                onExtract()
                            }
                        )
                    }

                    ContextActionRow(
                        icon = Icons.Default.Visibility,
                        title = if (com.FileExplorer.XFileExplorer.data.FileManager.isArchive(item.file)) "Browse Archive Hierarchy" else "View / Open",
                        subtitle = if (com.FileExplorer.XFileExplorer.data.FileManager.isArchive(item.file)) "Explore files inside archive" else "Open with built-in viewer",
                        iconColor = TechCyan,
                        testTag = "context_view",
                        onClick = {
                            onDismiss()
                            onView()
                        }
                    )
                }

                ContextActionRow(
                    icon = Icons.Default.ContentCopy,
                    title = "Copy",
                    subtitle = "Copy item to clipboard buffer",
                    iconColor = Color(0xFF64B5F6),
                    testTag = "context_copy",
                    onClick = {
                        onDismiss()
                        onCopy()
                    }
                )

                ContextActionRow(
                    icon = Icons.Default.ContentCut,
                    title = "Cut (Move)",
                    subtitle = "Move item to destination",
                    iconColor = TechAmber,
                    testTag = "context_cut",
                    onClick = {
                        onDismiss()
                        onCut()
                    }
                )

                ContextActionRow(
                    icon = Icons.Default.DriveFileRenameOutline,
                    title = "Rename",
                    subtitle = "Change name or extension",
                    iconColor = Color(0xFF81C784),
                    testTag = "context_rename",
                    onClick = {
                        onDismiss()
                        onRename()
                    }
                )

                ContextActionRow(
                    icon = Icons.Default.Archive,
                    title = "Compress to .zip",
                    subtitle = "Create standard zip archive",
                    iconColor = TechAmber,
                    testTag = "context_compress_zip",
                    onClick = {
                        onDismiss()
                        onCompressZip()
                    }
                )

                ContextActionRow(
                    icon = Icons.Default.Info,
                    title = "Properties / Details",
                    subtitle = "Permissions and file specs",
                    iconColor = Color(0xFF90A4CE),
                    testTag = "context_details",
                    onClick = {
                        onDismiss()
                        onShowDetails()
                    }
                )

                ContextActionRow(
                    icon = Icons.Default.Delete,
                    title = "Remove (Delete)",
                    subtitle = "Permanently delete item",
                    iconColor = TechRed,
                    testTag = "context_remove",
                    onClick = {
                        onDismiss()
                        onDelete()
                    }
                )
            }
        }
    }
}

@Composable
private fun ContextActionRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    iconColor: Color,
    testTag: String,
    isHighlighted: Boolean = false,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .testTag(testTag)
            .clip(RoundedCornerShape(10.dp))
            .background(if (isHighlighted) iconColor.copy(alpha = 0.12f) else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(34.dp)
                .background(iconColor.copy(alpha = 0.18f), RoundedCornerShape(8.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = iconColor,
                modifier = Modifier.size(18.dp)
            )
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column {
            Text(
                text = title,
                fontSize = 13.sp,
                fontWeight = if (isHighlighted) FontWeight.Bold else FontWeight.Medium,
                color = if (isHighlighted) iconColor else Color.White
            )
            Text(
                text = subtitle,
                fontSize = 10.sp,
                color = Color(0xFF8FA3CD)
            )
        }
    }
}

/**
 * Requirement 6: Batch Operations Toolbar
 * Appears when "Select Multiple" is active
 */
@Composable
fun BatchSelectionToolbar(
    selectedCount: Int,
    totalCount: Int,
    accent: Color,
    onSelectAll: () -> Unit,
    onDeselectAll: () -> Unit,
    onBatchDelete: () -> Unit,
    onBatchCopy: () -> Unit,
    onBatchCut: () -> Unit,
    onBatchZip: () -> Unit,
    onCancelBatch: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("batch_selection_toolbar"),
        color = DarkSurfaceElevated,
        tonalElevation = 8.dp,
        border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onCancelBatch,
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("batch_close_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close Selection Mode",
                            tint = Color.White
                        )
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    Text(
                        text = "$selectedCount selected",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = accent
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = if (selectedCount == totalCount) onDeselectAll else onSelectAll,
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("batch_select_all_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.SelectAll,
                            contentDescription = "Select or Deselect All",
                            tint = Color.White
                        )
                    }

                    IconButton(
                        onClick = onBatchCopy,
                        enabled = selectedCount > 0,
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("batch_copy_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = "Batch Copy",
                            tint = if (selectedCount > 0) Color(0xFF64B5F6) else Color.Gray
                        )
                    }

                    IconButton(
                        onClick = onBatchCut,
                        enabled = selectedCount > 0,
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("batch_cut_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.ContentCut,
                            contentDescription = "Batch Cut",
                            tint = if (selectedCount > 0) TechAmber else Color.Gray
                        )
                    }

                    IconButton(
                        onClick = onBatchZip,
                        enabled = selectedCount > 0,
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("batch_zip_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Archive,
                            contentDescription = "Batch Zip",
                            tint = if (selectedCount > 0) TechAmber else Color.Gray
                        )
                    }

                    IconButton(
                        onClick = onBatchDelete,
                        enabled = selectedCount > 0,
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("batch_delete_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Batch Delete",
                            tint = if (selectedCount > 0) TechRed else Color.Gray
                        )
                    }
                }
            }
        }
    }
}
