package com.FileExplorer.XFileExplorer.data

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File

class FileWatcher(
    private val scope: CoroutineScope,
    private val pollIntervalMs: Long = 5000L,
    private val onDirectoryChanged: suspend () -> Unit
) {
    private var watchingJob: Job? = null
    private var currentWatchedDirectory: File? = null
    private var lastObservedSignature: Long = 0L

    fun startWatching(directory: File) {
        if (currentWatchedDirectory?.absolutePath == directory.absolutePath && watchingJob?.isActive == true) {
            return
        }

        stopWatching()
        currentWatchedDirectory = directory
        lastObservedSignature = computeDirectorySignature(directory)

        // Only poll if directory exists, is accessible, and is a valid directory
        if (!directory.exists() || !directory.isDirectory || !directory.canRead()) {
            return
        }

        watchingJob = scope.launch(Dispatchers.IO) {
            while (isActive) {
                delay(pollIntervalMs)
                val target = currentWatchedDirectory ?: break
                if (target.exists() && target.isDirectory && target.canRead()) {
                    val currentSignature = computeDirectorySignature(target)
                    if (currentSignature != 0L && currentSignature != lastObservedSignature) {
                        lastObservedSignature = currentSignature
                        onDirectoryChanged()
                    }
                }
            }
        }
    }

    fun stopWatching() {
        watchingJob?.cancel()
        watchingJob = null
    }

    fun forceSync() {
        currentWatchedDirectory?.let {
            lastObservedSignature = 0L
        }
    }

    private fun computeDirectorySignature(directory: File): Long {
        return try {
            if (!directory.exists() || !directory.isDirectory || !directory.canRead()) {
                0L
            } else {
                directory.lastModified()
            }
        } catch (_: Exception) {
            0L
        }
    }
}
