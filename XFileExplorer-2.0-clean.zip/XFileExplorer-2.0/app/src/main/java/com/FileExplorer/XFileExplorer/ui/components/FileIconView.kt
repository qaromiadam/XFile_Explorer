package com.FileExplorer.XFileExplorer.ui.components

import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.FileExplorer.XFileExplorer.model.AppSettings
import com.FileExplorer.XFileExplorer.model.FileItem
import com.FileExplorer.XFileExplorer.model.FileType
import com.FileExplorer.XFileExplorer.ui.theme.TechAmber
import com.FileExplorer.XFileExplorer.ui.theme.TechBlue
import com.FileExplorer.XFileExplorer.ui.theme.TechCyan
import com.FileExplorer.XFileExplorer.ui.theme.TechEmerald
import com.FileExplorer.XFileExplorer.ui.theme.TechMagenta
import com.FileExplorer.XFileExplorer.ui.theme.TechRed
import com.FileExplorer.XFileExplorer.ui.theme.TechViolet

@Composable
fun FileIconView(
    item: FileItem,
    settings: AppSettings,
    modifier: Modifier = Modifier,
    sizeDp: Int = 44
) {
    Box(
        modifier = modifier.size(sizeDp.dp),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .clip(RoundedCornerShape(10.dp)),
            contentAlignment = Alignment.Center
        ) {
            when {
                item.isDirectory -> {
                    FolderIcon(item = item, accent = settings.currentAccent)
                }

                item.type == FileType.IMAGE && settings.showImageThumbnails -> {
                    ImageThumbnailIcon(item = item)
                }

                item.type == FileType.APK && settings.useStylizedApkMascot -> {
                    ApkIcon(item = item)
                }

                item.type == FileType.ARCHIVE_ZIP && settings.useCustomArchiveIcons -> {
                    ZipArchiveIcon()
                }

                else -> {
                    StandardCategoryIcon(item = item)
                }
            }
        }

        // Requirement 2: Small type-specific icon inside circular container on bottom-right corner
        if (!item.isDirectory) {
            TypeBadgeOverlay(
                type = item.type,
                accent = settings.currentAccent,
                modifier = Modifier.align(Alignment.BottomEnd)
            )
        }
    }
}

@Composable
private fun TypeBadgeOverlay(
    type: FileType,
    accent: Color,
    modifier: Modifier = Modifier
) {
    val (badgeIcon, badgeColor) = when (type) {
        FileType.IMAGE -> Icons.Default.Image to TechEmerald
        FileType.VIDEO -> Icons.Default.Movie to TechViolet
        FileType.AUDIO -> Icons.Default.Audiotrack to TechMagenta
        FileType.APK -> Icons.Default.Android to Color(0xFF3DDC84)
        FileType.ARCHIVE_ZIP, FileType.ARCHIVE_OTHER -> Icons.Default.Archive to TechAmber
        FileType.CODE -> Icons.Default.Code to TechCyan
        FileType.DOCUMENT -> Icons.Default.Description to TechBlue
        FileType.TEXT -> Icons.Default.Description to Color(0xFF81D4FA)
        else -> Icons.Default.InsertDriveFile to Color(0xFF90A4CE)
    }

    Box(
        modifier = modifier
            .offset(x = 2.dp, y = 2.dp)
            .size(16.dp)
            .clip(CircleShape)
            .background(Color(0xFF070B14))
            .border(1.dp, Color(0xFF1E293B), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = badgeIcon,
            contentDescription = null,
            tint = badgeColor,
            modifier = Modifier.size(9.dp)
        )
    }
}

@Composable
private fun FolderIcon(item: FileItem, accent: Color) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(accent.copy(alpha = 0.15f), RoundedCornerShape(10.dp))
            .border(1.dp, accent.copy(alpha = 0.35f), RoundedCornerShape(10.dp)),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = Icons.Default.Folder,
            contentDescription = "Folder",
            tint = accent,
            modifier = Modifier.size(26.dp)
        )
    }
}

@Composable
private fun ImageThumbnailIcon(item: FileItem) {
    val context = LocalContext.current
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF161F33), RoundedCornerShape(10.dp))
            .border(1.dp, TechCyan.copy(alpha = 0.4f), RoundedCornerShape(10.dp)),
        contentAlignment = Alignment.Center
    ) {
        AsyncImage(
            model = ImageRequest.Builder(context)
                .data(item.file)
                .crossfade(true)
                .build(),
            contentDescription = "Thumbnail for ${item.name}",
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .fillMaxSize()
                .clip(RoundedCornerShape(10.dp))
        )

    }
}

@Composable
private fun ApkIcon(item: FileItem) {
    val context = LocalContext.current
    val apkIconDrawable: Drawable? = remember(item.file.absolutePath) {
        try {
            val pm = context.packageManager
            val info = pm.getPackageArchiveInfo(item.file.absolutePath, 0)
            val appInfo = info?.applicationInfo
            if (appInfo != null) {
                appInfo.sourceDir = item.file.absolutePath
                appInfo.publicSourceDir = item.file.absolutePath
                appInfo.loadIcon(pm)
            } else null
        } catch (_: Exception) {
            null
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F2417), RoundedCornerShape(10.dp))
            .border(1.dp, TechEmerald.copy(alpha = 0.5f), RoundedCornerShape(10.dp)),
        contentAlignment = Alignment.Center
    ) {
        if (apkIconDrawable != null) {
            AsyncImage(
                model = apkIconDrawable,
                contentDescription = "APK Icon",
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .size(28.dp)
                    .clip(RoundedCornerShape(6.dp))
            )
        } else {
            StylizedApkMascotCanvas()
        }
    }
}

@Composable
private fun StylizedApkMascotCanvas() {
    Canvas(modifier = Modifier.size(28.dp)) {
        val green = Color(0xFF3DDC84)
        val w = size.width
        val h = size.height

        // Head (semi-circle dome)
        val headPath = Path().apply {
            arcTo(
                rect = androidx.compose.ui.geometry.Rect(
                    offset = Offset(w * 0.2f, h * 0.22f),
                    size = Size(w * 0.6f, h * 0.45f)
                ),
                startAngleDegrees = 180f,
                sweepAngleDegrees = 180f,
                forceMoveTo = true
            )
            close()
        }
        drawPath(headPath, color = green)

        // Antennae
        drawLine(
            color = green,
            start = Offset(w * 0.32f, h * 0.26f),
            end = Offset(w * 0.22f, h * 0.12f),
            strokeWidth = 2.2f
        )
        drawLine(
            color = green,
            start = Offset(w * 0.68f, h * 0.26f),
            end = Offset(w * 0.78f, h * 0.12f),
            strokeWidth = 2.2f
        )

        // Eyes
        drawCircle(
            color = Color.Black,
            radius = 1.8f,
            center = Offset(w * 0.38f, h * 0.35f)
        )
        drawCircle(
            color = Color.Black,
            radius = 1.8f,
            center = Offset(w * 0.62f, h * 0.35f)
        )

        // Body
        drawRoundRect(
            color = green,
            topLeft = Offset(w * 0.2f, h * 0.48f),
            size = Size(w * 0.6f, h * 0.38f),
            cornerRadius = CornerRadius(4f, 4f)
        )

        // Left Arm
        drawRoundRect(
            color = green,
            topLeft = Offset(w * 0.08f, h * 0.49f),
            size = Size(w * 0.09f, h * 0.28f),
            cornerRadius = CornerRadius(3f, 3f)
        )
        // Right Arm
        drawRoundRect(
            color = green,
            topLeft = Offset(w * 0.83f, h * 0.49f),
            size = Size(w * 0.09f, h * 0.28f),
            cornerRadius = CornerRadius(3f, 3f)
        )
    }
}

@Composable
private fun ZipArchiveIcon() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF261D10), RoundedCornerShape(10.dp))
            .border(1.dp, TechAmber.copy(alpha = 0.5f), RoundedCornerShape(10.dp)),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize().padding(6.dp)) {
            val amber = TechAmber
            for (i in 0..4) {
                val y = size.height * (0.25f + i * 0.12f)
                val x = if (i % 2 == 0) size.width * 0.44f else size.width * 0.56f
                drawRect(
                    color = amber,
                    topLeft = Offset(x - 3f, y - 2f),
                    size = Size(6f, 4f)
                )
            }
            drawRoundRect(
                color = amber.copy(alpha = 0.4f),
                style = Stroke(width = 1.5f),
                cornerRadius = CornerRadius(6f, 6f)
            )
        }
    }
}

@Composable
private fun StandardCategoryIcon(item: FileItem) {
    val ext = item.extension
    val (iconColor, iconVector) = when (item.type) {
        FileType.IMAGE -> TechEmerald to Icons.Default.Image
        FileType.APK -> Color(0xFF3DDC84) to Icons.Default.Android
        FileType.ARCHIVE_ZIP, FileType.ARCHIVE_OTHER -> TechAmber to Icons.Default.Archive
        FileType.CODE -> {
            val c = when (ext) {
                "kt", "kts" -> TechViolet
                "py" -> TechAmber
                "js", "ts" -> Color(0xFFFFD600)
                "sh", "bash" -> TechCyan
                "html", "css" -> TechMagenta
                else -> TechCyan
            }
            c to Icons.Default.Code
        }
        FileType.VIDEO -> TechRed to Icons.Default.Movie
        FileType.AUDIO -> TechMagenta to Icons.Default.Audiotrack
        FileType.DOCUMENT -> TechBlue to Icons.Default.Description
        FileType.TEXT -> Color(0xFF90A4CE) to Icons.Default.Description
        else -> Color(0xFF8899AC) to Icons.Default.InsertDriveFile
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(iconColor.copy(alpha = 0.12f), RoundedCornerShape(10.dp))
            .border(1.dp, iconColor.copy(alpha = 0.3f), RoundedCornerShape(10.dp)),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = iconVector,
            contentDescription = item.extension,
            tint = iconColor,
            modifier = Modifier.size(24.dp)
        )
    }
}
