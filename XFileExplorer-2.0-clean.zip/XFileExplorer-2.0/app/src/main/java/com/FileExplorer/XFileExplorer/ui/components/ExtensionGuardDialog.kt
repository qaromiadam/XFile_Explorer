package com.FileExplorer.XFileExplorer.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.FileExplorer.XFileExplorer.ui.theme.DarkSurface
import com.FileExplorer.XFileExplorer.ui.theme.TechAmber

/**
 * Requirement 7: Extension Change Guard Dialog
 * Intercepts file extension changes during rename operations.
 * Displays exact text: "You can't change [from_extension] to [to_extension]"
 * Includes an "OK" button that dismisses and cancels the operation.
 */
@Composable
fun ExtensionGuardDialog(
    fromExtension: String,
    toExtension: String,
    onDismiss: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .testTag("extension_guard_dialog")
                .border(1.dp, TechAmber.copy(alpha = 0.6f), RoundedCornerShape(18.dp)),
            shape = RoundedCornerShape(18.dp),
            color = DarkSurface,
            tonalElevation = 8.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(22.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(54.dp)
                        .background(TechAmber.copy(alpha = 0.15f), CircleShape)
                        .border(1.5.dp, TechAmber, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = "Warning",
                        tint = TechAmber,
                        modifier = Modifier.size(28.dp)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "File Extension Protected",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )

                Spacer(modifier = Modifier.height(14.dp))

                // EXACT REQUIRED STRING: "You can't change [from_extension] to [to_extension]"
                val fromStr = if (fromExtension.isEmpty()) "(none)" else fromExtension
                val toStr = if (toExtension.isEmpty()) "(none)" else toExtension
                val warningText = "You can't change $fromStr to $toStr"

                Text(
                    text = warningText,
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color(0xFFD6E2F5),
                    lineHeight = 22.sp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF0B111E), RoundedCornerShape(10.dp))
                        .padding(14.dp)
                        .testTag("extension_guard_message")
                )

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = onDismiss,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("extension_guard_ok_btn"),
                    colors = ButtonDefaults.buttonColors(containerColor = TechAmber),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(
                        text = "OK",
                        fontWeight = FontWeight.Bold,
                        color = Color.Black
                    )
                }
            }
        }
    }
}
