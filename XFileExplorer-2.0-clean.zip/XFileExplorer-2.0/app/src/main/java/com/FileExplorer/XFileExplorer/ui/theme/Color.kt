package com.FileExplorer.XFileExplorer.ui.theme

import androidx.compose.ui.graphics.Color

// XFile Explorer Dark Identity
val TechBlack = Color(0xFF070B13)
val DarkBackground = Color(0xFF0B111E)
val DarkSurface = Color(0xFF111A2E)
val DarkSurfaceElevated = Color(0xFF17233D)
val DarkSurfaceBorder = Color(0xFF223254)

val TechCyan = Color(0xFF00E5FF)
val TechCyanDark = Color(0xFF00B0FF)
val TechBlue = Color(0xFF2979FF)
val TechViolet = Color(0xFF7C4DFF)
val TechEmerald = Color(0xFF00E676)
val TechAmber = Color(0xFFFFB300)
val TechRed = Color(0xFFFF3D71)
val TechMagenta = Color(0xFFFF007F)

val TextPrimaryDark = Color(0xFFF0F4FF)
val TextSecondaryDark = Color(0xFF90A4CE)
val TextTertiaryDark = Color(0xFF5F759E)

// Terminal specific
val TerminalBlack = Color(0xFF05080E)
val TerminalGreen = Color(0xFF00FF66)
val TerminalCyan = Color(0xFF00F0FF)
val TerminalYellow = Color(0xFFFFDD00)
val TerminalRed = Color(0xFFFF4466)
