package com.FileExplorer.XFileExplorer.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.FileExplorer.XFileExplorer.model.FileItem
import com.FileExplorer.XFileExplorer.ui.MainViewModel
import com.FileExplorer.XFileExplorer.ui.FileOperationProgress
import com.FileExplorer.XFileExplorer.ui.theme.DarkSurface
import com.FileExplorer.XFileExplorer.ui.theme.DarkSurfaceBorder

@Composable
fun FileOperationProgressDialog(
    progress: FileOperationProgress,
    accent: Color,
    onDismiss: (() -> Unit)? = null
) {
    Dialog(
        onDismissRequest = { onDismiss?.invoke() },
        properties = DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .testTag("file_operation_progress_dialog"),
            shape = RoundedCornerShape(16.dp),
            color = DarkSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                // Header with title and percentage
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = progress.title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = Color.White
                    )
                    Text(
                        text = "${progress.percentage}%",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = accent
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Progress Indicator
                val progressFraction = (progress.percentage / 100f).coerceIn(0f, 1f)
                LinearProgressIndicator(
                    progress = { progressFraction },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp)),
                    color = accent,
                    trackColor = Color(0xFF162032),
                    strokeCap = StrokeCap.Round
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Current file name
                if (progress.currentFileName.isNotBlank()) {
                    Text(
                        text = "File: ${progress.currentFileName}",
                        fontSize = 12.sp,
                        color = Color(0xFFD6E2F5),
                        maxLines = 1
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                }

                // Bytes processed / total bytes
                val processedStr = FileItem.formatBytes(progress.bytesProcessed)
                val totalStr = FileItem.formatBytes(progress.totalBytes)
                Text(
                    text = "Processed: $processedStr / $totalStr",
                    fontSize = 11.sp,
                    color = Color(0xFF90A4CE)
                )
            }
        }
    }
}
