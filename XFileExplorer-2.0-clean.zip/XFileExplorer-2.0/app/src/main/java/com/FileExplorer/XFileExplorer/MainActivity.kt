package com.FileExplorer.XFileExplorer

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.FileExplorer.XFileExplorer.model.FileItem
import com.FileExplorer.XFileExplorer.model.ThemeMode
import com.FileExplorer.XFileExplorer.ui.MainViewModel
import com.FileExplorer.XFileExplorer.ui.components.CornerNavigationOverlay
import com.FileExplorer.XFileExplorer.ui.components.CreateItemDialog
import com.FileExplorer.XFileExplorer.ui.components.CustomBackground
import com.FileExplorer.XFileExplorer.ui.components.DeleteConfirmDialog
import com.FileExplorer.XFileExplorer.ui.components.ExtensionGuardDialog
import com.FileExplorer.XFileExplorer.ui.components.CompressDialog
import com.FileExplorer.XFileExplorer.ui.components.FileItemContextMenu
import com.FileExplorer.XFileExplorer.ui.components.FilePropertiesDialog
import com.FileExplorer.XFileExplorer.ui.components.RenameDialog
import com.FileExplorer.XFileExplorer.ui.components.ScreenDestination
import com.FileExplorer.XFileExplorer.ui.components.SecurityShieldDialog
import com.FileExplorer.XFileExplorer.ui.screens.AppsScreen
import com.FileExplorer.XFileExplorer.ui.screens.ExplorerScreen
import com.FileExplorer.XFileExplorer.ui.screens.SettingsScreen
import com.FileExplorer.XFileExplorer.ui.screens.TerminalScreen
import com.FileExplorer.XFileExplorer.ui.theme.DarkSurfaceElevated
import com.FileExplorer.XFileExplorer.ui.theme.TechAmber
import com.FileExplorer.XFileExplorer.ui.theme.TechCyan
import com.FileExplorer.XFileExplorer.ui.theme.XFileTheme
import com.FileExplorer.XFileExplorer.ui.viewers.ArchiveViewerDialog
import com.FileExplorer.XFileExplorer.ui.viewers.AudioPlayerDialog
import com.FileExplorer.XFileExplorer.ui.viewers.FileReaderDialog
import com.FileExplorer.XFileExplorer.ui.viewers.ImageViewerDialog
import com.FileExplorer.XFileExplorer.ui.viewers.VideoPlayerDialog

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val viewModel: MainViewModel = viewModel()
            val settings by viewModel.settings.collectAsState()

            XFileTheme(
                themeMode = settings.themeMode,
                accentColor = settings.currentAccent
            ) {
                MainAppContent(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun MainAppContent(viewModel: MainViewModel) {
    val context = LocalContext.current
    val settings by viewModel.settings.collectAsState()
    val currentDir by viewModel.currentDirectory.collectAsState()
    val files by viewModel.files.collectAsState()
    val isLoading by viewModel.isLoading.collectAsState()
    val currentDestination by viewModel.currentDestination.collectAsState()
    val isHamburgerOpen by viewModel.isHamburgerOpen.collectAsState()
    val selectedPaths by viewModel.selectedFilePaths.collectAsState()
    val isBatchMode by viewModel.isBatchMode.collectAsState()
    val clipboardFiles by viewModel.clipboardFiles.collectAsState()
    val isClipboardCut by viewModel.isClipboardCut.collectAsState()
    val deviceRoots by viewModel.deviceRoots.collectAsState()

    // Dialog states
    val contextMenuItem by viewModel.contextMenuItem.collectAsState()
    val activeImageViewerItem by viewModel.activeImageViewerItem.collectAsState()
    val activeFileReaderItem by viewModel.activeFileReaderItem.collectAsState()
    val activeVideoPlayerItem by viewModel.activeVideoPlayerItem.collectAsState()
    val activeAudioPlayerItem by viewModel.activeAudioPlayerItem.collectAsState()
    val activeArchiveViewerItem by viewModel.activeArchiveViewerItem.collectAsState()
    val activePdfViewerItem by viewModel.activePdfViewerItem.collectAsState()
    val extensionGuardWarning by viewModel.extensionGuardWarning.collectAsState()
    val compressDialogState by viewModel.compressDialogState.collectAsState()
    val showCreateDialog by viewModel.showCreateDialog.collectAsState()
    val showRenameItem by viewModel.showRenameItem.collectAsState()
    val showPropertiesItem by viewModel.showPropertiesItem.collectAsState()
    val showDeleteConfirmItems by viewModel.showDeleteConfirmItems.collectAsState()
    val securityBlockedPath by viewModel.securityBlockedPath.collectAsState()

    // Terminal states
    val terminalLines by viewModel.terminalLines.collectAsState()
    val isWaitingForHelpPagination by viewModel.isWaitingForHelpPagination.collectAsState()

    // Storage permission state & request launcher
    var hasStoragePermission by remember { mutableStateOf(checkStoragePermission(context)) }

    val requestSinglePermission by viewModel.requestSinglePermission.collectAsState()
    val requestUngrantedPermissions by viewModel.requestUngrantedPermissions.collectAsState()
    val operationProgress by viewModel.operationProgress.collectAsState()

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) {
        hasStoragePermission = checkStoragePermission(context)
        if (hasStoragePermission) {
            viewModel.refreshRoots()
            viewModel.refreshCurrentDirectory()
        }
    }

    val singlePermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) {
        hasStoragePermission = checkStoragePermission(context)
        if (hasStoragePermission) {
            viewModel.refreshRoots()
            viewModel.refreshCurrentDirectory()
        }
    }

    val manageStorageLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) {
        hasStoragePermission = checkStoragePermission(context)
        if (hasStoragePermission) {
            viewModel.refreshRoots()
            viewModel.refreshCurrentDirectory()
        }
    }

    // Terminal requested single permission
    LaunchedEffect(requestSinglePermission) {
        val perm = requestSinglePermission ?: return@LaunchedEffect
        viewModel.onSinglePermissionHandled()
        when (perm) {
            "manage_external_storage" -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    try {
                        val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION).apply {
                            data = Uri.parse("package:${context.packageName}")
                        }
                        manageStorageLauncher.launch(intent)
                    } catch (_: Exception) {
                        val fallback = Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)
                        manageStorageLauncher.launch(fallback)
                    }
                } else {
                    permissionLauncher.launch(
                        arrayOf(
                            Manifest.permission.READ_EXTERNAL_STORAGE,
                            Manifest.permission.WRITE_EXTERNAL_STORAGE
                        )
                    )
                }
            }
            "read_storage" -> {
                if (Build.VERSION.SDK_INT <= 32) {
                    singlePermissionLauncher.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
                } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    try {
                        val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION).apply {
                            data = Uri.parse("package:${context.packageName}")
                        }
                        manageStorageLauncher.launch(intent)
                    } catch (_: Exception) {
                        val fallback = Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)
                        manageStorageLauncher.launch(fallback)
                    }
                }
            }
            "write_storage" -> {
                if (Build.VERSION.SDK_INT <= 29) {
                    singlePermissionLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    try {
                        val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION).apply {
                            data = Uri.parse("package:${context.packageName}")
                        }
                        manageStorageLauncher.launch(intent)
                    } catch (_: Exception) {
                        val fallback = Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)
                        manageStorageLauncher.launch(fallback)
                    }
                }
            }
            "install_packages", "request_install_packages" -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    try {
                        val intent = Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES).apply {
                            data = Uri.parse("package:${context.packageName}")
                        }
                        manageStorageLauncher.launch(intent)
                    } catch (_: Exception) {
                        val fallback = Intent(Settings.ACTION_SECURITY_SETTINGS)
                        manageStorageLauncher.launch(fallback)
                    }
                }
            }
        }
    }

    // Terminal requested ungranted permissions batch
    LaunchedEffect(requestUngrantedPermissions) {
        val ungranted = requestUngrantedPermissions ?: return@LaunchedEffect
        viewModel.clearPermissionRequest()
        if (ungranted.isNotEmpty()) {
            val hasManage = ungranted.contains(Manifest.permission.MANAGE_EXTERNAL_STORAGE)
            if (hasManage && Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                try {
                    val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION).apply {
                        data = Uri.parse("package:${context.packageName}")
                    }
                    manageStorageLauncher.launch(intent)
                } catch (_: Exception) {
                    val fallback = Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)
                    manageStorageLauncher.launch(fallback)
                }
            } else {
                val runtimeOnly = ungranted.filter {
                    it != Manifest.permission.MANAGE_EXTERNAL_STORAGE && it != Manifest.permission.DUMP
                }
                if (runtimeOnly.isNotEmpty()) {
                    permissionLauncher.launch(runtimeOnly.toTypedArray())
                }
            }
        }
    }

    LaunchedEffect(Unit) {
        if (!hasStoragePermission && Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            permissionLauncher.launch(
                arrayOf(
                    Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE
                )
            )
        }
    }

    // Predictive Back Handling
    BackHandler(enabled = true) {
        when {
            securityBlockedPath != null -> viewModel.dismissSecurityDialog()
            extensionGuardWarning != null -> viewModel.dismissExtensionGuard()
            compressDialogState != null -> viewModel.dismissCompressDialog()
            activeImageViewerItem != null -> viewModel.closeImageViewer()
            activeFileReaderItem != null -> viewModel.closeFileReader()
            activePdfViewerItem != null -> viewModel.closePdfViewer()
            activeVideoPlayerItem != null -> viewModel.closeVideoPlayer()
            activeAudioPlayerItem != null -> viewModel.closeAudioPlayer()
            showCreateDialog -> viewModel.closeCreateDialog()
            showRenameItem != null -> viewModel.closeRenameDialog()
            showPropertiesItem != null -> viewModel.closePropertiesDialog()
            showDeleteConfirmItems != null -> viewModel.closeDeleteConfirm()
            contextMenuItem != null -> viewModel.dismissContextMenu()
            isHamburgerOpen -> viewModel.closeHamburger()
            isBatchMode -> viewModel.exitBatchMode()
            currentDestination != ScreenDestination.EXPLORER -> viewModel.navigateTo(ScreenDestination.EXPLORER)
            com.FileExplorer.XFileExplorer.data.FileManager.canNavigateUp(currentDir) && currentDir.parentFile != null -> {
                viewModel.loadDirectory(currentDir.parentFile!!)
            }
        }
    }

    CustomBackground(settings = settings) {
        Box(modifier = Modifier.fillMaxSize()) {
            // Main Content Area
            Column(modifier = Modifier.fillMaxSize()) {
                // Storage permission banner if not granted
                if (!hasStoragePermission) {
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .statusBarsPadding()
                            .padding(8.dp),
                        shape = RoundedCornerShape(10.dp),
                        color = Color(0xFF2A1C0A)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Security,
                                contentDescription = null,
                                tint = TechAmber
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Full storage access recommended for root/system access.",
                                fontSize = 11.sp,
                                color = Color.White,
                                modifier = Modifier.weight(1f)
                            )
                            Button(
                                onClick = {
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                                        try {
                                            val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION).apply {
                                                data = Uri.parse("package:${context.packageName}")
                                            }
                                            manageStorageLauncher.launch(intent)
                                        } catch (_: Exception) {
                                            val intent = Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)
                                            manageStorageLauncher.launch(intent)
                                        }
                                    } else {
                                        permissionLauncher.launch(
                                            arrayOf(
                                                Manifest.permission.READ_EXTERNAL_STORAGE,
                                                Manifest.permission.WRITE_EXTERNAL_STORAGE
                                            )
                                        )
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = TechAmber),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text("Grant", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                // Crossfade between main screens
                Crossfade(
                    targetState = currentDestination,
                    label = "screen_crossfade",
                    modifier = Modifier.weight(1f)
                ) { destination ->
                    when (destination) {
                        ScreenDestination.EXPLORER -> {
                            ExplorerScreen(
                                currentDirectory = currentDir,
                                files = files,
                                isLoading = isLoading,
                                settings = settings,
                                selectedFilePaths = selectedPaths,
                                isBatchMode = isBatchMode,
                                clipboardFiles = clipboardFiles,
                                isClipboardCut = isClipboardCut,
                                onOpenHamburger = { viewModel.openHamburger() },
                                onNavigateDirectory = { viewModel.loadDirectory(it) },
                                onFileClick = { viewModel.onFileClicked(it) },
                                onFileLongClick = { viewModel.onFileLongClicked(it) },
                                onToggleSelectFile = { viewModel.toggleFileSelection(it) },
                                onSelectAll = { viewModel.selectAllFiles() },
                                onDeselectAll = { viewModel.deselectAllFiles() },
                                onBatchDelete = {
                                    val itemsToDelete = files.filter { selectedPaths.contains(it.path) }
                                    viewModel.confirmDelete(itemsToDelete)
                                },
                                onBatchCopy = {
                                    val itemsToCopy = files.filter { selectedPaths.contains(it.path) }
                                    viewModel.copyToClipboard(itemsToCopy, isCut = false)
                                },
                                onBatchCut = {
                                    val itemsToCut = files.filter { selectedPaths.contains(it.path) }
                                    viewModel.copyToClipboard(itemsToCut, isCut = true)
                                },
                                onBatchZip = {
                                    val itemsToZip = files.filter { selectedPaths.contains(it.path) }
                                    viewModel.openCompressDialog(itemsToZip)
                                },
                                onCancelBatch = { viewModel.exitBatchMode() },
                                onPasteClipboard = { viewModel.pasteClipboard() },
                                onRefresh = { viewModel.refreshCurrentDirectory() },
                                onOpenCreateDialog = { viewModel.openCreateDialog() },
                                onSortChange = { sortBy, asc -> viewModel.sortFiles(sortBy, asc) }
                            )
                        }

                        ScreenDestination.TERMINAL -> {
                            TerminalScreen(
                                lines = terminalLines,
                                prompt = viewModel.terminalEngine.getPrompt(settings),
                                isWaitingForHelpPagination = isWaitingForHelpPagination,
                                settings = settings,
                                onSendCommand = { viewModel.sendTerminalCommand(it) },
                                onClear = { viewModel.clearTerminal() },
                                onOpenHamburger = { viewModel.openHamburger() }
                            )
                        }

                        ScreenDestination.APPS -> {
                            AppsScreen(
                                settings = settings,
                                onOpenHamburger = { viewModel.openHamburger() }
                            )
                        }

                        ScreenDestination.SETTINGS -> {
                            SettingsScreen(
                                settings = settings,
                                onUpdateSettings = { viewModel.updateSettings(it) },
                                onOpenHamburger = { viewModel.openHamburger() }
                            )
                        }
                    }
                }
            }

            // Corner Navigation Overlay Drawer
            CornerNavigationOverlay(
                isExpanded = isHamburgerOpen,
                onCollapse = { viewModel.closeHamburger() },
                currentDestination = currentDestination,
                onNavigate = { viewModel.navigateTo(it) },
                settings = settings,
                deviceRoots = deviceRoots,
                onSelectRoot = { viewModel.loadDirectory(it) },
                activeDirectory = currentDir
            )

            // Context Menu (Long-press)
            contextMenuItem?.let { item ->
                FileItemContextMenu(
                    item = item,
                    accent = settings.currentAccent,
                    onDismiss = { viewModel.dismissContextMenu() },
                    onView = { viewModel.openFileViewer(item) },
                    onCopy = { viewModel.copyToClipboard(listOf(item), isCut = false) },
                    onCut = { viewModel.copyToClipboard(listOf(item), isCut = true) },
                    onDelete = { viewModel.confirmDelete(listOf(item)) },
                    onRename = { viewModel.openRenameDialog(item) },
                    onCompressZip = { viewModel.openCompressDialog(listOf(item)) },
                    onSelectMultiple = { viewModel.enterBatchMode(item) },
                    onShowDetails = { viewModel.openPropertiesDialog(item) },
                    onExtract = { viewModel.extractArchive(item) }
                )
            }

            // Built-in Readers
            activeImageViewerItem?.let { item ->
                ImageViewerDialog(
                    item = item,
                    accent = settings.currentAccent,
                    onDismiss = { viewModel.closeImageViewer() }
                )
            }

            activeFileReaderItem?.let { item ->
                FileReaderDialog(
                    item = item,
                    fileManager = viewModel.fileManager,
                    accent = settings.currentAccent,
                    onDismiss = { viewModel.closeFileReader() },
                    onFileSaved = { viewModel.refreshCurrentDirectory() }
                )
            }

            activeVideoPlayerItem?.let { item ->
                VideoPlayerDialog(
                    item = item,
                    accent = settings.currentAccent,
                    onDismiss = { viewModel.closeVideoPlayer() }
                )
            }

            activeAudioPlayerItem?.let { item ->
                AudioPlayerDialog(
                    item = item,
                    accent = settings.currentAccent,
                    onDismiss = { viewModel.closeAudioPlayer() }
                )
            }

            activeArchiveViewerItem?.let { item ->
                ArchiveViewerDialog(
                    item = item,
                    fileManager = viewModel.fileManager,
                    accent = settings.currentAccent,
                    onDismiss = { viewModel.closeArchiveViewer() },
                    onExtractArchive = {
                        viewModel.extractArchive(it)
                        viewModel.closeArchiveViewer()
                    }
                )
            }

            activePdfViewerItem?.let { item ->
                com.FileExplorer.XFileExplorer.ui.viewers.PdfViewerDialog(
                    item = item,
                    accent = settings.currentAccent,
                    onDismiss = { viewModel.closePdfViewer() }
                )
            }

            // Extension Change Guard Dialog (Requirement 7)
            extensionGuardWarning?.let { (fromExt, toExt) ->
                ExtensionGuardDialog(
                    fromExtension = fromExt,
                    toExtension = toExt,
                    onDismiss = { viewModel.dismissExtensionGuard() }
                )
            }

            // Compression Dialog with Compression Intensity Slider (Requirement 6)
            compressDialogState?.let { req ->
                CompressDialog(
                    defaultName = req.defaultName,
                    accent = settings.currentAccent,
                    initialCompressionLevel = settings.compressionLevel,
                    onDismiss = { viewModel.dismissCompressDialog() },
                    onConfirm = { archiveName, level ->
                        viewModel.executeCompression(archiveName, level)
                    }
                )
            }

            // Dialogs
            if (showCreateDialog) {
                CreateItemDialog(
                    accent = settings.currentAccent,
                    onDismiss = { viewModel.closeCreateDialog() },
                    onCreateFolder = { viewModel.createFolder(it) },
                    onCreateFile = { viewModel.createFile(it) }
                )
            }

            showRenameItem?.let { item ->
                RenameDialog(
                    initialName = item.name,
                    accent = settings.currentAccent,
                    onDismiss = { viewModel.closeRenameDialog() },
                    onRename = { viewModel.renameItem(item, it) }
                )
            }

            showPropertiesItem?.let { item ->
                FilePropertiesDialog(
                    item = item,
                    accent = settings.currentAccent,
                    onDismiss = { viewModel.closePropertiesDialog() }
                )
            }

            showDeleteConfirmItems?.let { items ->
                DeleteConfirmDialog(
                    itemNames = items.map { it.name },
                    onDismiss = { viewModel.closeDeleteConfirm() },
                    onConfirm = { viewModel.executeDelete(items) }
                )
            }

            // Requirement: File Operation Progress Popup
            operationProgress?.let { prog ->
                com.FileExplorer.XFileExplorer.ui.components.FileOperationProgressDialog(
                    progress = prog,
                    accent = settings.currentAccent
                )
            }

            // Requirement 8: Security Exception Handler Dialog
            // Displays exact required message word-for-word!
            securityBlockedPath?.let { path ->
                SecurityShieldDialog(
                    filePath = path,
                    onDismiss = { viewModel.dismissSecurityDialog() }
                )
            }
        }
    }
}

private fun checkStoragePermission(context: android.content.Context): Boolean {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        Environment.isExternalStorageManager()
    } else {
        context.checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) ==
                android.content.pm.PackageManager.PERMISSION_GRANTED
    }
}
