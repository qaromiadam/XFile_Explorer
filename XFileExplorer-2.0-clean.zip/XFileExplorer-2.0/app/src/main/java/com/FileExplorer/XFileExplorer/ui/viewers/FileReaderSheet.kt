package com.FileExplorer.XFileExplorer.ui.viewers

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.FileExplorer.XFileExplorer.data.FileManager
import com.FileExplorer.XFileExplorer.model.FileItem
import com.FileExplorer.XFileExplorer.ui.theme.DarkBackground
import com.FileExplorer.XFileExplorer.ui.theme.DarkSurface
import com.FileExplorer.XFileExplorer.ui.theme.DarkSurfaceBorder
import com.FileExplorer.XFileExplorer.ui.theme.DarkSurfaceElevated
import com.FileExplorer.XFileExplorer.ui.theme.TechCyan
import com.FileExplorer.XFileExplorer.ui.theme.TechEmerald
import kotlinx.coroutines.launch

/**
 * Requirement 5: Built-in File Reader (Text & Code Viewer/Editor)
 */
@Composable
fun FileReaderDialog(
    item: FileItem,
    fileManager: FileManager,
    accent: Color,
    onDismiss: () -> Unit,
    onFileSaved: () -> Unit
) {
    var contentText by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(true) }
    var isEditing by remember { mutableStateOf(false) }
    var isSaving by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val clipboardManager = LocalClipboardManager.current

    val isArchive = FileManager.isArchive(item.file)

    LaunchedEffect(item.path) {
        if (isArchive) {
            errorMessage = "Archives (.zip) cannot be directly edited. Extract the archive first."
            isLoading = false
            return@LaunchedEffect
        }
        isLoading = true
        val result = fileManager.readFileText(item.file)
        if (result.isSuccess) {
            contentText = result.getOrThrow()
        } else {
            errorMessage = result.exceptionOrNull()?.message ?: "Failed to read file"
        }
        isLoading = false
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .testTag("file_reader_screen"),
            color = DarkBackground
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Header Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(DarkSurface)
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier
                                .size(38.dp)
                                .background(DarkSurfaceElevated, CircleShape)
                                .testTag("file_reader_close_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Close",
                                tint = Color.White
                            )
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        Column {
                            Text(
                                text = item.name,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                maxLines = 1
                            )
                            Text(
                                text = "${item.extension.uppercase()} • ${item.formattedSize} • ${if (isEditing) "EDIT MODE" else "READ ONLY"}",
                                fontSize = 11.sp,
                                color = if (isEditing) TechEmerald else Color(0xFF90A4CE),
                                fontWeight = if (isEditing) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // Copy button
                        IconButton(
                            onClick = { clipboardManager.setText(AnnotatedString(contentText)) },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.ContentCopy,
                                contentDescription = "Copy content",
                                tint = Color(0xFF90A4CE)
                            )
                        }

                        // Edit / View toggle
                        if (!isArchive) {
                            IconButton(
                                onClick = { isEditing = !isEditing },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Edit,
                                    contentDescription = "Toggle Edit",
                                    tint = if (isEditing) TechEmerald else Color.White
                                )
                            }
                        }

                        // Save Button
                        if (isEditing) {
                            IconButton(
                                onClick = {
                                    scope.launch {
                                        isSaving = true
                                        val saveRes = fileManager.writeFileText(item.file, contentText)
                                        isSaving = false
                                        if (saveRes.isSuccess) {
                                            isEditing = false
                                            onFileSaved()
                                        } else {
                                            errorMessage = saveRes.exceptionOrNull()?.message
                                        }
                                    }
                                },
                                modifier = Modifier
                                    .size(36.dp)
                                    .testTag("file_reader_save_btn")
                            ) {
                                if (isSaving) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(18.dp),
                                        strokeWidth = 2.dp,
                                        color = TechEmerald
                                    )
                                } else {
                                    Icon(
                                        imageVector = Icons.Default.Save,
                                        contentDescription = "Save file",
                                        tint = TechEmerald
                                    )
                                }
                            }
                        }
                    }
                }

                HorizontalDivider(color = DarkSurfaceBorder)

                // Error message banner if any
                if (errorMessage != null) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFF331414))
                            .padding(10.dp)
                    ) {
                        Text(
                            text = errorMessage ?: "",
                            color = Color(0xFFFF6B6B),
                            fontSize = 12.sp
                        )
                    }
                }

                if (isLoading) {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(color = accent)
                    }
                } else {
                    val lines = contentText.lines()
                    val verticalScroll = rememberScrollState()
                    val horizontalScroll = rememberScrollState()

                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(top = 4.dp)
                    ) {
                        // Line numbers column
                        Column(
                            modifier = Modifier
                                .fillMaxHeight()
                                .width(46.dp)
                                .background(DarkSurface.copy(alpha = 0.5f))
                                .verticalScroll(verticalScroll)
                                .padding(vertical = 8.dp),
                            horizontalAlignment = Alignment.End
                        ) {
                            lines.indices.forEach { idx ->
                                Text(
                                    text = "${idx + 1} ",
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 12.sp,
                                    color = Color(0xFF5F759E),
                                    lineHeight = 18.sp
                                )
                            }
                        }

                        // Content column
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .verticalScroll(verticalScroll)
                                .horizontalScroll(horizontalScroll)
                                .padding(horizontal = 12.dp, vertical = 8.dp)
                        ) {
                            if (isEditing) {
                                BasicTextField(
                                    value = contentText,
                                    onValueChange = { contentText = it },
                                    textStyle = TextStyle(
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 12.sp,
                                        color = Color(0xFFE2E8F0),
                                        lineHeight = 18.sp
                                    ),
                                    cursorBrush = SolidColor(TechCyan),
                                    modifier = Modifier.fillMaxSize()
                                )
                            } else {
                                Text(
                                    text = contentText,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 12.sp,
                                    color = Color(0xFFE2E8F0),
                                    lineHeight = 18.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
