package com.FileExplorer.XFileExplorer.model

import androidx.compose.ui.graphics.Color
import com.FileExplorer.XFileExplorer.ui.theme.TerminalCyan
import com.FileExplorer.XFileExplorer.ui.theme.TerminalGreen
import com.FileExplorer.XFileExplorer.ui.theme.TerminalRed
import com.FileExplorer.XFileExplorer.ui.theme.TerminalYellow
import com.FileExplorer.XFileExplorer.ui.theme.TextPrimaryDark

enum class LineType {
    INPUT,
    OUTPUT,
    SUCCESS,
    ERROR,
    WARNING,
    INFO,
    SYSTEM
}

data class TerminalLine(
    val text: String,
    val type: LineType = LineType.OUTPUT
) {
    val displayColor: Color
        get() = when (type) {
            LineType.INPUT -> TerminalCyan
            LineType.OUTPUT -> TextPrimaryDark
            LineType.SUCCESS -> TerminalGreen
            LineType.ERROR -> TerminalRed
            LineType.WARNING -> TerminalYellow
            LineType.INFO -> TerminalCyan
            LineType.SYSTEM -> Color(0xFF64B5F6)
        }
}

data class HelpCommandInfo(
    val name: String,
    val syntax: String,
    val description: String
)

data class HelpPaginationSession(
    val currentPage: Int = 0,
    val pageSize: Int = 10,
    val totalCommands: List<HelpCommandInfo>
) {
    val totalPages: Int = if (totalCommands.isEmpty()) 1 else (totalCommands.size + pageSize - 1) / pageSize

    fun getCurrentPageItems(): List<HelpCommandInfo> {
        val start = currentPage * pageSize
        val end = minOf(start + pageSize, totalCommands.size)
        return if (start in totalCommands.indices) totalCommands.subList(start, end) else emptyList()
    }
}

data class AppPermissionInfo(
    val key: String,
    val manifestName: String,
    val isGranted: Boolean,
    val isApplicable: Boolean = true,
    val ungrantedReason: String = "",
    val isInstallTime: Boolean = false
)
