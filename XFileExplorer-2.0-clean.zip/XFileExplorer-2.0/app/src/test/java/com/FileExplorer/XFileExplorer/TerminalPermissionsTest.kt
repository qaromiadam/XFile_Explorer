package com.FileExplorer.XFileExplorer

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.FileExplorer.XFileExplorer.data.FileManager
import com.FileExplorer.XFileExplorer.data.TerminalEngine
import com.FileExplorer.XFileExplorer.model.AppPermissionInfo
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class TerminalPermissionsTest {

    private lateinit var fileManager: FileManager
    private lateinit var tempDir: File

    @Before
    fun setUp() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        fileManager = FileManager(context)
        tempDir = File(context.filesDir, "perm_test").apply { mkdirs() }
    }

    @Test
    fun testPermissionsCommand_reportsAllStatusesWithoutPopups() = runBlocking {
        val permissions = listOf(
            AppPermissionInfo("internet", "android.permission.INTERNET", isGranted = true, isInstallTime = true),
            AppPermissionInfo("network_state", "android.permission.ACCESS_NETWORK_STATE", isGranted = true, isInstallTime = true),
            AppPermissionInfo("read_storage", "android.permission.READ_EXTERNAL_STORAGE", isGranted = true),
            AppPermissionInfo("write_storage", "android.permission.WRITE_EXTERNAL_STORAGE", isGranted = false, ungrantedReason = "Required for saving files"),
            AppPermissionInfo("manage_external_storage", "android.permission.MANAGE_EXTERNAL_STORAGE", isGranted = false, ungrantedReason = "All files access"),
            AppPermissionInfo("dump", "android.permission.DUMP", isGranted = false, ungrantedReason = "Diagnostic dumps")
        )

        val engine = TerminalEngine(
            fileManager = fileManager,
            initialDirectory = tempDir,
            permissionProvider = { permissions }
        )

        val output = engine.processInput("permissions")

        // Must report without triggering popups
        assertFalse(output.any { it.text.startsWith("__TRIGGER_PERMISSIONS__:") })
        assertFalse(output.any { it.text.startsWith("__TRIGGER_SINGLE_PERMISSION__:") })

        // Check text hints and syntax guidelines
        assertTrue(output.any { it.text.contains("Permissions NOT granted yet:") })
        assertTrue(output.any { it.text.contains("Permissions already granted:") })
        assertTrue(output.any { it.text.contains("Type: grant permission <name> to make the app ask for it") })
        assertTrue(output.any { it.text.contains("Accepted names: internet, network_state, read_storage, write_storage, manage_external_storage, dump") })
    }

    @Test
    fun testPermissionsCommand_whenAllGranted() = runBlocking {
        val permissions = listOf(
            AppPermissionInfo("internet", "android.permission.INTERNET", isGranted = true),
            AppPermissionInfo("network_state", "android.permission.ACCESS_NETWORK_STATE", isGranted = true),
            AppPermissionInfo("read_storage", "android.permission.READ_EXTERNAL_STORAGE", isGranted = true),
            AppPermissionInfo("write_storage", "android.permission.WRITE_EXTERNAL_STORAGE", isGranted = true),
            AppPermissionInfo("manage_external_storage", "android.permission.MANAGE_EXTERNAL_STORAGE", isGranted = true),
            AppPermissionInfo("dump", "android.permission.DUMP", isGranted = true)
        )

        val engine = TerminalEngine(
            fileManager = fileManager,
            initialDirectory = tempDir,
            permissionProvider = { permissions }
        )

        val output = engine.processInput("permissions")
        assertTrue(output.any { it.text == "All required permissions are already granted." })
    }

    @Test
    fun testGrantPermission_triggersSinglePermissionRoute() = runBlocking {
        val permissions = listOf(
            AppPermissionInfo("manage_external_storage", "android.permission.MANAGE_EXTERNAL_STORAGE", isGranted = false),
            AppPermissionInfo("read_storage", "android.permission.READ_EXTERNAL_STORAGE", isGranted = false)
        )

        val engine = TerminalEngine(
            fileManager = fileManager,
            initialDirectory = tempDir,
            permissionProvider = { permissions }
        )

        val output = engine.processInput("grant permission manage_external_storage")
        assertTrue(output.any { it.text == "__TRIGGER_SINGLE_PERMISSION__:manage_external_storage" })
    }

    @Test
    fun testGrantPermission_alreadyGrantedReportsProperMessage() = runBlocking {
        val permissions = listOf(
            AppPermissionInfo("internet", "android.permission.INTERNET", isGranted = true),
            AppPermissionInfo("read_storage", "android.permission.READ_EXTERNAL_STORAGE", isGranted = true)
        )

        val engine = TerminalEngine(
            fileManager = fileManager,
            initialDirectory = tempDir,
            permissionProvider = { permissions }
        )

        val output = engine.processInput("grant permission read_storage")
        assertTrue(output.any { it.text == "Permission already granted. Grant another one." })
    }

    @Test
    fun testGrantPermissionDump_reportsAdbCommandWhenNotGranted() = runBlocking {
        val permissions = listOf(
            AppPermissionInfo("dump", "android.permission.DUMP", isGranted = false)
        )

        val engine = TerminalEngine(
            fileManager = fileManager,
            initialDirectory = tempDir,
            permissionProvider = { permissions }
        )

        val output = engine.processInput("grant permission dump")
        assertTrue(output.any { it.text.contains("This cannot be granted using Android permission giver") })
        assertTrue(output.any { it.text.contains("adb shell pm grant com.FileExplorer.XFileExplorer android.permission.DUMP") })
    }

    @Test
    fun testGrantPermission_unknownPermissionName() = runBlocking {
        val engine = TerminalEngine(
            fileManager = fileManager,
            initialDirectory = tempDir,
            permissionProvider = { emptyList() }
        )

        val output = engine.processInput("grant permission invalid_perm")
        assertTrue(output.any { it.text.contains("Unknown permission name 'invalid_perm'") })
        assertTrue(output.any { it.text.contains("Accepted names: internet, network_state, read_storage, write_storage, manage_external_storage, dump") })
    }
}
