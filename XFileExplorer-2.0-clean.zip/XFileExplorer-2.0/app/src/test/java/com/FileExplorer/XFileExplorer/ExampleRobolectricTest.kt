package com.FileExplorer.XFileExplorer

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.FileExplorer.XFileExplorer.data.AndroidSecurityBlockedException
import com.FileExplorer.XFileExplorer.data.FileManager
import com.FileExplorer.XFileExplorer.data.TerminalEngine
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun testAppNameStringMatches() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("XFile Explorer", appName)
    }

    @Test
    fun testSecurityExceptionExactMessage() {
        val exactExpected =
            "This file is blocked by Android's security systems. To access it, unlock your bootloader and use another file app that allows this."
        val exception = AndroidSecurityBlockedException("/system/bin/su")
        assertEquals(exactExpected, exception.message)
    }

    @Test
    fun testTerminalHelpPaginationAndQuietExit() {
        runBlocking {
            val context = ApplicationProvider.getApplicationContext<Context>()
            val fileManager = FileManager(context)
            val tempDir = File(context.filesDir, "term_test").apply { mkdirs() }
            val terminal = TerminalEngine(fileManager, tempDir)

            // Step 1: Type 'help'
            val helpLines = terminal.processInput("help")
            assertTrue("Terminal must be in help pagination mode", terminal.isWaitingForHelpPagination)

            // Count commands printed (lines starting with '• ')
            val commandBulletLines = helpLines.filter { it.text.startsWith("• ") }
            assertEquals("Page 1 must display exactly 10 commands", 10, commandBulletLines.size)
            assertTrue("Must indicate Page 1", helpLines.any { it.text.contains("Page 1") })

            // Step 2: Type 'n' for next page
            val nextLines = terminal.processInput("n")
            assertTrue("Still in pagination mode on page 2", terminal.isWaitingForHelpPagination)
            val nextBulletLines = nextLines.filter { it.text.startsWith("• ") }
            assertEquals("Page 2 must display exactly 10 commands", 10, nextBulletLines.size)
            assertTrue("Must indicate Page 2", nextLines.any { it.text.contains("Page 2") })

            // Step 3: Type 'p' for previous page
            val prevLines = terminal.processInput("p")
            assertTrue("Still in pagination mode on page 1", terminal.isWaitingForHelpPagination)
            val prevBulletLines = prevLines.filter { it.text.startsWith("• ") }
            assertEquals("Page 1 must display exactly 10 commands", 10, prevBulletLines.size)

            // Step 4: Type anything else (or invalid key) -> quietly exit with no errors
            val exitLines = terminal.processInput("xyz")
            assertFalse("Must exit pagination mode quietly without errors", terminal.isWaitingForHelpPagination)
            assertTrue("Must act like nothing happened and output empty lines", exitLines.isEmpty())

            tempDir.deleteRecursively()
        }
    }

    @Test
    fun testNavigationBoundaryRestriction() {
        val boundaryFile = File("/storage/emulated/0")
        assertFalse("Cannot navigate up from navigation boundary", FileManager.canNavigateUp(boundaryFile))
        assertTrue("Is at navigation boundary", FileManager.isAtNavigationBoundary(boundaryFile))

        val boundaryTrailingSlash = File("/storage/emulated/0/")
        assertFalse("Cannot navigate up with trailing slash", FileManager.canNavigateUp(boundaryTrailingSlash))

        val subDir = File("/storage/emulated/0/Download")
        assertTrue("Can navigate up from sub-directory", FileManager.canNavigateUp(subDir))
    }

    @Test
    fun testExtensionChangeGuardDetection() {
        val testFile = File("/storage/emulated/0/document.txt")
        val change = FileManager.checkExtensionChange(testFile, "document.pdf")
        assertTrue("Extension change should be detected", change != null)
        assertEquals("txt", change?.first)
        assertEquals("pdf", change?.second)

        val sameExt = FileManager.checkExtensionChange(testFile, "renamed.txt")
        assertTrue("Same extension should not trigger change", sameExt == null)
    }

    @Test
    fun testAccurateRecursiveSizeCalculation() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val tempDir = File(context.filesDir, "size_test_${System.currentTimeMillis()}").apply { mkdirs() }
        val f1 = File(tempDir, "file1.bin").apply { writeBytes(ByteArray(1024)) }
        val subDir = File(tempDir, "nested").apply { mkdirs() }
        val f2 = File(subDir, "file2.bin").apply { writeBytes(ByteArray(2048)) }

        val calculated = com.FileExplorer.XFileExplorer.model.FileItem.calculateRecursiveSize(tempDir)
        assertEquals(3072L, calculated)

        tempDir.deleteRecursively()
    }

    @Test
    fun testPersistentPreferencesStorage() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val prefsManager = com.FileExplorer.XFileExplorer.data.PreferencesManager(context)

        val customSettings = com.FileExplorer.XFileExplorer.model.AppSettings(
            themeMode = com.FileExplorer.XFileExplorer.model.ThemeMode.AMOLED,
            accentIndex = 3,
            backgroundOpacity = 0.5f,
            showHiddenFiles = false,
            compressionLevel = 90
        )
        prefsManager.saveSettings(customSettings)

        val loaded = prefsManager.loadSettings()
        assertEquals(com.FileExplorer.XFileExplorer.model.ThemeMode.AMOLED, loaded.themeMode)
        assertEquals(3, loaded.accentIndex)
        assertEquals(0.5f, loaded.backgroundOpacity, 0.01f)
        assertFalse(loaded.showHiddenFiles)
        assertEquals(90, loaded.compressionLevel)
    }

    @Test
    fun testToyboxCommandExecution() {
        runBlocking {
            val context = ApplicationProvider.getApplicationContext<Context>()
            val fileManager = FileManager(context)
            val terminal = TerminalEngine(fileManager, context.filesDir)

            val archOutput = terminal.processInput("arch")
            assertTrue("arch command should return architecture string", archOutput.isNotEmpty())

            val calOutput = terminal.processInput("cal")
            assertTrue("cal command should output calendar table", calOutput.any { it.text.contains("Su Mo Tu We Th Fr Sa") })

            val base64Output = terminal.processInput("base64 hello")
            assertTrue("base64 command should encode text", base64Output.isNotEmpty())

            val acpiOutput = terminal.processInput("acpi")
            assertTrue("acpi command should return battery info", acpiOutput.any { it.text.contains("Battery") })
        }
    }

    @Test
    fun testZipExtraction() {
        runBlocking {
            val context = ApplicationProvider.getApplicationContext<Context>()
            val fileManager = FileManager(context)
            val testDir = File(context.cacheDir, "archive_test_${System.currentTimeMillis()}")
            testDir.mkdirs()

            val srcFile = File(testDir, "sample.txt")
            srcFile.writeText("XFile Archive Extraction Test Payload")

            // Test ZIP compression & extraction
            val zipArchive = File(testDir, "test_archive.zip")
            val zipCompressRes = fileManager.compressToZip(listOf(srcFile), zipArchive)
            assertTrue("Zip compression should succeed", zipCompressRes.isSuccess)

            val zipOutDir = File(testDir, "zip_extracted")
            val zipExtractRes = fileManager.extractArchive(zipArchive, zipOutDir)
            assertTrue("Zip extraction should succeed", zipExtractRes.isSuccess)
            val extractedZipFile = File(zipOutDir, "sample.txt")
            assertTrue("Extracted file from zip should exist", extractedZipFile.exists())
            assertEquals("XFile Archive Extraction Test Payload", extractedZipFile.readText())

            testDir.deleteRecursively()
        }
    }
}
